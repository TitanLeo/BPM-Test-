# BPM Support Portal Phase 1 Plan

## Build scope
- Create a single React/TypeScript app named BPM Support Portal for internal Business Support Management.
- Use generated data hooks for the updated data model, including the POS-DATA Dataverse table that carries POS operational incident columns.
- Provide a Microsoft Fluent-inspired enterprise interface with dark navy collapsible desktop sidebar, white content area, blue accents, rounded cards, KPI dashboards, tables, filters, charts, and responsive mobile drawer navigation.

## Navigation
- Dashboard
- Modules
- ADID
- SAP
- CRMS
- OS
- ZPIRS
- FIS Treasury
- CCTV
- POS
- Hardware
- MMS
- PhilCom
- OSD Helpdesk
- Reports
- Document Monitoring
- Settings

## Role behavior
- Roles: Superadmin, Manager, Officer, Technician, Requestor.
- Settings is visible and accessible only for Superadmin.
- Phase 1 uses mock role state, with a clear path to replace it with real identity/security later.

## Pages and features
- Dashboard: executive KPIs, status and throughput charts, operational records table, module/status/date-range filters.
- Module pages: shared module template for ADID, SAP, CRMS, OS, ZPIRS, FIS Treasury, CCTV, Hardware, MMS, and PhilCom with summary content.
- POS module: Fluent service-desk workspace connected to the generated POS-DATA Dataverse table with status KPIs, live filtering, sorting, empty/loading states, and functional Add/Edit/Delete Ticket dialogs using the full generated issue-category choice set.
- Reports: overview KPIs and report cards only.
- Document Monitoring: document KPIs and a simple document status table.
- Settings: read-only user role, module access, and system configuration.

## Data entities
- Tickets
- Operational Records
- Modules
- Reports
- Documents
- Users
- Roles
- System Configuration
- POS-DATA Dataverse table for POS operational incidents, terminals, causes, resolutions, support assignment, ticket age, and manual/processed transaction flags

## Future-ready areas
- Keep Operational Support Records, users, roles, access, and audit features on generated Dataverse hooks as those screens transition away from mock presentation data.
- Reserve extension points for Power Automate workflows, SharePoint documents, Microsoft Teams notifications, Power BI embeds, approvals, notifications, and audit trail.

## What stays out of Phase 1
- No additional Dataverse schema changes beyond the user-updated model.
- POS records use the generated POS-DATA Dataverse hooks; Add/Edit/Delete operate against current POS-DATA field mappings and invalidate live queries.
- No login/logout or account-management UI.
- No editing inside Settings.