import { useEffect } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { Provider as JotaiProvider } from 'jotai';
import { initialize } from '@microsoft/power-apps/app';

import Layout from '@/pages/_layout';
import { queryClient } from '@/lib/query-client';
import { Toaster } from '@/components/ui/sonner';
import ErrorBoundary from '@/components/system/error-boundary';

import HomePage from '@/pages/index';
import ModulesPage from '@/pages/modules';
import ModuleDetailPage from '@/pages/module-detail';
import HelpdeskPage from '@/pages/helpdesk';
import ReportsPage from '@/pages/reports';
import DocumentsPage from '@/pages/documents';
import SettingsOverviewPage from '@/pages/settings-overview';
import SettingsPage from '@/pages/settings';
import SystemSettingsPage from '@/pages/system-settings';

import AuthenticationPage from '@/pages/authentication';
import AccessDeniedPage from '@/pages/access-denied';
import NotFoundPage from '@/pages/not-found';

function App() {
  useEffect(() => {
    try {
      void initialize();
    } catch (error: unknown) {
      console.warn('Power Apps initialization skipped; running with local mock data.', error);
    }
  }, []);
  return (
    <QueryClientProvider client={queryClient}>
      <ErrorBoundary resetQueryCache>
        <JotaiProvider>
          <Toaster richColors />
          <Router>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<HomePage />} />
                <Route path="dashboard" element={<HomePage />} />
                <Route path="modules" element={<ModulesPage />} />

                <Route path="modules/:moduleId" element={<ModuleDetailPage />} />
                <Route path="helpdesk" element={<HelpdeskPage />} />
                <Route path="authentication" element={<AuthenticationPage />} />
                <Route path="access-denied" element={<AccessDeniedPage unregistered />} />
                <Route path="reports" element={<ReportsPage />} />
                <Route path="documents" element={<DocumentsPage />} />
                <Route path="settings" element={<SettingsOverviewPage />} />
                <Route path="settings/system" element={<SystemSettingsPage />} />
                <Route path="settings/user-account-management" element={<SettingsPage />} />
                <Route path="*" element={<NotFoundPage />} />
              </Route>
            </Routes>
          </Router>
        </JotaiProvider>
      </ErrorBoundary>
    </QueryClientProvider>
  );
}

export default App;
