import { Paperclip, UserRound } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import type { OperationalRecord, Priority, Status } from '@/lib/mock-data';

type TicketDetailDrawerProps = {
  ticket: OperationalRecord & { summary?: string; created?: string; sla?: string; title?: string; branch?: string; category?: string; description?: string; resolution?: string; attachments?: string; ticketId?: string; dateCreated?: string };
  children: React.ReactNode;
};

function statusBadgeClass(status: Status | string): string {
  if (status === 'Needs Attention' || status === 'Waiting') return 'bg-accent text-accent-foreground border-transparent shadow-sm ring-1 ring-accent';
  if (status === 'In Progress' || status === 'Open') return 'bg-primary text-primary-foreground border-transparent shadow-sm ring-1 ring-primary';
  if (status === 'Resolved' || status === 'Verified') return 'bg-success text-success-foreground border-transparent shadow-sm ring-1 ring-success';
  if (status === 'Closed') return 'bg-sidebar text-sidebar-foreground border-transparent shadow-sm ring-1 ring-sidebar';
  return 'bg-secondary text-secondary-foreground border-transparent shadow-sm ring-1 ring-secondary';
}

function priorityBadgeClass(priority: Priority | string): string {
  if (priority === 'Critical') return 'bg-destructive text-destructive-foreground border-transparent shadow-sm ring-1 ring-destructive';
  if (priority === 'High') return 'bg-accent text-accent-foreground border-transparent shadow-sm ring-1 ring-accent';
  if (priority === 'Normal' || priority === 'Medium') return 'bg-primary text-primary-foreground border-transparent shadow-sm ring-1 ring-primary';
  return 'bg-secondary text-secondary-foreground border-transparent shadow-sm ring-1 ring-secondary';
}

export function TicketDetailDrawer({ ticket, children }: TicketDetailDrawerProps) {
  const ticketNumber = ticket.ticketNo ?? ticket.ticketId ?? 'Ticket';
  const title = ticket.summary ?? ticket.title ?? `${ticket.module} support request`;
  const branch = ticket.branch ?? ticket.branchId;
  const created = ticket.created ?? ticket.dateCreated ?? ticket.modifiedDate;

  return (
    <Sheet>
      <SheetTrigger asChild>{children}</SheetTrigger>
      <SheetContent side="right" className="w-full overflow-y-auto bg-card text-card-foreground sm:max-w-xl">
        <SheetHeader>
          <SheetTitle>{ticketNumber}</SheetTitle>
          <SheetDescription>{title}</SheetDescription>
        </SheetHeader>
        <div className="mt-6 space-y-5">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${statusBadgeClass(ticket.status)}`}>{ticket.status}</Badge>
            <Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${priorityBadgeClass(ticket.priority)}`}>{ticket.priority}</Badge>
            {ticket.sla && <Badge variant="secondary" className="rounded-full bg-secondary text-secondary-foreground">SLA {ticket.sla}</Badge>}
          </div>
          <div className="rounded-2xl border border-card-outline bg-background p-4 text-foreground">
            <div className="mb-2 flex items-center justify-between text-sm font-medium"><span>Progress</span><span>{ticket.progress}%</span></div>
            <Progress value={ticket.progress} />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { label: 'Module', value: ticket.module ?? ticket.category },
              { label: 'Requestor', value: ticket.requestor ?? ticket.createdBy },
              { label: 'Assigned to', value: ticket.assignedTo },
              { label: 'Due / created', value: `${ticket.dueDate ?? created}` },
              { label: 'Branch', value: branch },
              { label: 'Last modified', value: ticket.modifiedDate ?? created },
            ].map((item: { label: string; value: string | undefined }) => (
              <div key={item.label} className="rounded-2xl border border-card-outline bg-background p-4 text-foreground">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{item.label}</p>
                <p className="mt-1 text-sm font-semibold">{item.value ?? 'Not specified'}</p>
              </div>
            ))}
          </div>
          <div className="rounded-2xl border border-card-outline bg-background p-4 text-foreground">
            <p className="text-sm font-semibold">Details</p>
            <p className="mt-2 text-sm text-muted-foreground">{ticket.description ?? `${title} is assigned to ${ticket.assignedTo} for ${ticket.module ?? ticket.category} follow-up.`}</p>
            <p className="mt-4 text-sm font-semibold">Resolution notes</p>
            <p className="mt-2 text-sm text-muted-foreground">{ticket.resolution ?? 'Resolution notes will be captured as the support team updates this ticket.'}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button><UserRound className="h-4 w-4" />Assign owner</Button>
            <Button variant="outline"><Paperclip className="h-4 w-4" />{ticket.attachments ?? 'View attachments'}</Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
