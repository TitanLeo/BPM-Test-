import { Bell, MapPin } from 'lucide-react';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import type { PortalUser } from '@/lib/auth-access';

type UserProfilePanelProps = {
  user: PortalUser;
  compact?: boolean;
};

function initials(name: string): string {
  return name
    .split(' ')
    .filter((part: string) => part.length > 0)
    .map((part: string) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
}

export function UserProfilePanel({ user, compact = false }: UserProfilePanelProps) {
  if (compact) {
    return (
      <div className="flex items-center gap-3 rounded-xl bg-secondary px-3 py-2 text-secondary-foreground">
        <Bell className="h-4 w-4" />
        <span className="hidden text-sm font-medium md:inline">{user.branchName}</span>
        <Avatar className="h-8 w-8">
          <AvatarFallback className="bg-primary text-primary-foreground">{initials(user.displayName)}</AvatarFallback>
        </Avatar>
      </div>
    );
  }

  return (
    <Card className="bg-card text-card-foreground">
      <CardContent className="flex items-start gap-4 p-4">
        <Avatar className="h-12 w-12">
          <AvatarFallback className="bg-primary text-primary-foreground">{initials(user.displayName)}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1 space-y-2">
          <div>
            <p className="font-semibold leading-tight">{user.displayName}</p>
            <p className="truncate text-sm text-muted-foreground">{user.email}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="bg-secondary text-secondary-foreground">{user.roleName}</Badge>
            <Badge variant="outline" className="gap-1"><MapPin className="h-3 w-3" />{user.branchName}</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
