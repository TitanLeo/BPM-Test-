export * from './use-operational-support-record';
export * from './use-bspuser-role-access';
export * from './use-bspmmsticket-detail';
export * from './use-bspuser';
export * from './use-bsprole';
export * from './use-bspaudit-log';
export * from './use-posdata';
export * from './use-app-user';
export * from './use-support-module';

export const HAS_IN_MEMORY_TABLES = true as const;