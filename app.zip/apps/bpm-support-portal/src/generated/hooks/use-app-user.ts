import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppUserService } from "../services/app-user-service";
import type { AppUser } from "../models/app-user-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all AppUser records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, appUserName
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useAppUserList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["appUser-list", options],
    queryFn: () => AppUserService.getAll(options),
  });
}

/**
 * Retrieve a single AppUser record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useAppUser(id: string) {
  return useQuery({
    queryKey: ["appUser", id],
    queryFn: () => AppUserService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new AppUser record.
 * @remarks Form validation: use CreateAppUserSchema with zodResolver for type-safe create forms
 */
export function useCreateAppUser() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<AppUser, "id">) => AppUserService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["appUser-list"] });
    },
  });
}

/**
 * Update an existing AppUser record.
 * @remarks Form validation: use UpdateAppUserSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateAppUser() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<AppUser, "id">>;
    }) => AppUserService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["appUser-list"] });
      client.invalidateQueries({ queryKey: ["appUser", variables.id] });
    },
  });
}

/**
 * Delete a AppUser record by its unique identifier.
 */
export function useDeleteAppUser() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => AppUserService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["appUser-list"] });
      client.invalidateQueries({ queryKey: ["appUser", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const AppUser_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { AppUserSchema, CreateAppUserSchema, UpdateAppUserSchema } from "../validators/app-user-validator";
export type { AppUserInput, CreateAppUserInput, UpdateAppUserInput } from "../validators/app-user-validator";