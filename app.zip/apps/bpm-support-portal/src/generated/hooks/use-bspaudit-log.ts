import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BSPAuditLogService } from "../services/bsp-audit-log-service";
import type { BSPAuditLog } from "../models/bsp-audit-log-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all BSPAuditLog records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, auditLogName, actionKey, eventDate, modifiedByEmail, modifiedByName, newValue, oldValue
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useBSPAuditLogList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["bSPAuditLog-list", options],
    queryFn: () => BSPAuditLogService.getAll(options),
  });
}

/**
 * Retrieve a single BSPAuditLog record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useBSPAuditLog(id: string) {
  return useQuery({
    queryKey: ["bSPAuditLog", id],
    queryFn: () => BSPAuditLogService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new BSPAuditLog record.
 * @remarks Form validation: use CreateBSPAuditLogSchema with zodResolver for type-safe create forms
 */
export function useCreateBSPAuditLog() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<BSPAuditLog, "id">) => BSPAuditLogService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["bSPAuditLog-list"] });
    },
  });
}

/**
 * Update an existing BSPAuditLog record.
 * @remarks Form validation: use UpdateBSPAuditLogSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateBSPAuditLog() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<BSPAuditLog, "id">>;
    }) => BSPAuditLogService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["bSPAuditLog-list"] });
      client.invalidateQueries({ queryKey: ["bSPAuditLog", variables.id] });
    },
  });
}

/**
 * Delete a BSPAuditLog record by its unique identifier.
 */
export function useDeleteBSPAuditLog() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => BSPAuditLogService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["bSPAuditLog-list"] });
      client.invalidateQueries({ queryKey: ["bSPAuditLog", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const BSPAuditLog_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { BSPAuditLogSchema, CreateBSPAuditLogSchema, UpdateBSPAuditLogSchema } from "../validators/bspaudit-log-validator";
export type { BSPAuditLogInput, CreateBSPAuditLogInput, UpdateBSPAuditLogInput } from "../validators/bspaudit-log-validator";