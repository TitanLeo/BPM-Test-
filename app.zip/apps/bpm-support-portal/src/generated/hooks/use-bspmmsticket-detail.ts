import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BSPMMSTicketDetailService } from "../services/bspmms-ticket-detail-service";
import type { BSPMMSTicketDetail } from "../models/bspmms-ticket-detail-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all BSPMMSTicketDetail records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, mMSTicketDetailName, additionalNotes, detailsOfConcern, employeeID, employeeName, errorMessage, mMSID, requestTypeKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useBSPMMSTicketDetailList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["bSPMMSTicketDetail-list", options],
    queryFn: () => BSPMMSTicketDetailService.getAll(options),
  });
}

/**
 * Retrieve a single BSPMMSTicketDetail record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useBSPMMSTicketDetail(id: string) {
  return useQuery({
    queryKey: ["bSPMMSTicketDetail", id],
    queryFn: () => BSPMMSTicketDetailService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new BSPMMSTicketDetail record.
 * @remarks Form validation: use CreateBSPMMSTicketDetailSchema with zodResolver for type-safe create forms
 */
export function useCreateBSPMMSTicketDetail() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<BSPMMSTicketDetail, "id">) => BSPMMSTicketDetailService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["bSPMMSTicketDetail-list"] });
    },
  });
}

/**
 * Update an existing BSPMMSTicketDetail record.
 * @remarks Form validation: use UpdateBSPMMSTicketDetailSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateBSPMMSTicketDetail() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<BSPMMSTicketDetail, "id">>;
    }) => BSPMMSTicketDetailService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["bSPMMSTicketDetail-list"] });
      client.invalidateQueries({ queryKey: ["bSPMMSTicketDetail", variables.id] });
    },
  });
}

/**
 * Delete a BSPMMSTicketDetail record by its unique identifier.
 */
export function useDeleteBSPMMSTicketDetail() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => BSPMMSTicketDetailService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["bSPMMSTicketDetail-list"] });
      client.invalidateQueries({ queryKey: ["bSPMMSTicketDetail", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const BSPMMSTicketDetail_DATA_SOURCE_TYPE = 'InMemory' as const;

export { BSPMMSTicketDetailSchema, CreateBSPMMSTicketDetailSchema, UpdateBSPMMSTicketDetailSchema } from "../validators/bspmmsticket-detail-validator";
export type { BSPMMSTicketDetailInput, CreateBSPMMSTicketDetailInput, UpdateBSPMMSTicketDetailInput } from "../validators/bspmmsticket-detail-validator";