import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BSPRoleService } from "../services/bsp-role-service";
import type { BSPRole } from "../models/bsp-role-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all BSPRole records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, roleName, createdDate, description, isSystemRole, statusKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useBSPRoleList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["bSPRole-list", options],
    queryFn: () => BSPRoleService.getAll(options),
  });
}

/**
 * Retrieve a single BSPRole record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useBSPRole(id: string) {
  return useQuery({
    queryKey: ["bSPRole", id],
    queryFn: () => BSPRoleService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new BSPRole record.
 * @remarks Form validation: use CreateBSPRoleSchema with zodResolver for type-safe create forms
 */
export function useCreateBSPRole() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<BSPRole, "id">) => BSPRoleService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["bSPRole-list"] });
    },
  });
}

/**
 * Update an existing BSPRole record.
 * @remarks Form validation: use UpdateBSPRoleSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateBSPRole() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<BSPRole, "id">>;
    }) => BSPRoleService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["bSPRole-list"] });
      client.invalidateQueries({ queryKey: ["bSPRole", variables.id] });
    },
  });
}

/**
 * Delete a BSPRole record by its unique identifier.
 */
export function useDeleteBSPRole() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => BSPRoleService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["bSPRole-list"] });
      client.invalidateQueries({ queryKey: ["bSPRole", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const BSPRole_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { BSPRoleSchema, CreateBSPRoleSchema, UpdateBSPRoleSchema } from "../validators/bsprole-validator";
export type { BSPRoleInput, CreateBSPRoleInput, UpdateBSPRoleInput } from "../validators/bsprole-validator";