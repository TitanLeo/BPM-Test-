import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BSPUserRoleAccessService } from "../services/bsp-user-role-access-service";
import type { BSPUserRoleAccess } from "../models/bsp-user-role-access-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all BSPUserRoleAccess records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, accessName, isGranted, permissionKey, updatedDate
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useBSPUserRoleAccessList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["bSPUserRoleAccess-list", options],
    queryFn: () => BSPUserRoleAccessService.getAll(options),
  });
}

/**
 * Retrieve a single BSPUserRoleAccess record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useBSPUserRoleAccess(id: string) {
  return useQuery({
    queryKey: ["bSPUserRoleAccess", id],
    queryFn: () => BSPUserRoleAccessService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new BSPUserRoleAccess record.
 * @remarks Form validation: use CreateBSPUserRoleAccessSchema with zodResolver for type-safe create forms
 */
export function useCreateBSPUserRoleAccess() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<BSPUserRoleAccess, "id">) => BSPUserRoleAccessService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["bSPUserRoleAccess-list"] });
    },
  });
}

/**
 * Update an existing BSPUserRoleAccess record.
 * @remarks Form validation: use UpdateBSPUserRoleAccessSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateBSPUserRoleAccess() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<BSPUserRoleAccess, "id">>;
    }) => BSPUserRoleAccessService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["bSPUserRoleAccess-list"] });
      client.invalidateQueries({ queryKey: ["bSPUserRoleAccess", variables.id] });
    },
  });
}

/**
 * Delete a BSPUserRoleAccess record by its unique identifier.
 */
export function useDeleteBSPUserRoleAccess() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => BSPUserRoleAccessService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["bSPUserRoleAccess-list"] });
      client.invalidateQueries({ queryKey: ["bSPUserRoleAccess", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const BSPUserRoleAccess_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { BSPUserRoleAccessSchema, CreateBSPUserRoleAccessSchema, UpdateBSPUserRoleAccessSchema } from "../validators/bspuser-role-access-validator";
export type { BSPUserRoleAccessInput, CreateBSPUserRoleAccessInput, UpdateBSPUserRoleAccessInput } from "../validators/bspuser-role-access-validator";