import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BSPUserService } from "../services/bsp-user-service";
import type { BSPUser } from "../models/bsp-user-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all BSPUser records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, emailAddress, accountStatusKey, branch, createdDate, department, isDeleted, lastLogin, position
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useBSPUserList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["bSPUser-list", options],
    queryFn: () => BSPUserService.getAll(options),
  });
}

/**
 * Retrieve a single BSPUser record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useBSPUser(id: string) {
  return useQuery({
    queryKey: ["bSPUser", id],
    queryFn: () => BSPUserService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new BSPUser record.
 * @remarks Form validation: use CreateBSPUserSchema with zodResolver for type-safe create forms
 */
export function useCreateBSPUser() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<BSPUser, "id">) => BSPUserService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["bSPUser-list"] });
    },
  });
}

/**
 * Update an existing BSPUser record.
 * @remarks Form validation: use UpdateBSPUserSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateBSPUser() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<BSPUser, "id">>;
    }) => BSPUserService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["bSPUser-list"] });
      client.invalidateQueries({ queryKey: ["bSPUser", variables.id] });
    },
  });
}

/**
 * Delete a BSPUser record by its unique identifier.
 */
export function useDeleteBSPUser() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => BSPUserService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["bSPUser-list"] });
      client.invalidateQueries({ queryKey: ["bSPUser", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const BSPUser_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { BSPUserSchema, CreateBSPUserSchema, UpdateBSPUserSchema } from "../validators/bspuser-validator";
export type { BSPUserInput, CreateBSPUserInput, UpdateBSPUserInput } from "../validators/bspuser-validator";