import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { OperationalSupportRecordService } from "../services/operational-support-record-service";
import type { OperationalSupportRecord } from "../models/operational-support-record-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all OperationalSupportRecord records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, operationalSupportRecordName, completedDate, createdDate, description, dueDate, priorityKey, recordTypeKey, statusKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useOperationalSupportRecordList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["operationalSupportRecord-list", options],
    queryFn: () => OperationalSupportRecordService.getAll(options),
  });
}

/**
 * Retrieve a single OperationalSupportRecord record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useOperationalSupportRecord(id: string) {
  return useQuery({
    queryKey: ["operationalSupportRecord", id],
    queryFn: () => OperationalSupportRecordService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new OperationalSupportRecord record.
 * @remarks Form validation: use CreateOperationalSupportRecordSchema with zodResolver for type-safe create forms
 */
export function useCreateOperationalSupportRecord() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<OperationalSupportRecord, "id">) => OperationalSupportRecordService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["operationalSupportRecord-list"] });
    },
  });
}

/**
 * Update an existing OperationalSupportRecord record.
 * @remarks Form validation: use UpdateOperationalSupportRecordSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateOperationalSupportRecord() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<OperationalSupportRecord, "id">>;
    }) => OperationalSupportRecordService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["operationalSupportRecord-list"] });
      client.invalidateQueries({ queryKey: ["operationalSupportRecord", variables.id] });
    },
  });
}

/**
 * Delete a OperationalSupportRecord record by its unique identifier.
 */
export function useDeleteOperationalSupportRecord() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => OperationalSupportRecordService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["operationalSupportRecord-list"] });
      client.invalidateQueries({ queryKey: ["operationalSupportRecord", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const OperationalSupportRecord_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { OperationalSupportRecordSchema, CreateOperationalSupportRecordSchema, UpdateOperationalSupportRecordSchema } from "../validators/operational-support-record-validator";
export type { OperationalSupportRecordInput, CreateOperationalSupportRecordInput, UpdateOperationalSupportRecordInput } from "../validators/operational-support-record-validator";