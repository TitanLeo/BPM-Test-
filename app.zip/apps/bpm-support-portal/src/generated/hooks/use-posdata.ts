import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { POSDATAService } from "../services/posdata-service";
import type { POSDATA } from "../models/posdata-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all POSDATA records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, pOS, age, availableWorkingPOS, branch, dateEncountered, dateReported, dateResolved, issue, issueCategoryKey, model, resolution, rootCause, status, support, ticketage, ticketIDNumber, tID, wITHMANUALPADDEDSI, wITHPROCESSEDTRANSACTIONSBEFOREISSUE
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function usePOSDATAList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["pOSDATA-list", options],
    queryFn: () => POSDATAService.getAll(options),
  });
}

/**
 * Retrieve a single POSDATA record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function usePOSDATA(id: string) {
  return useQuery({
    queryKey: ["pOSDATA", id],
    queryFn: () => POSDATAService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new POSDATA record.
 * @remarks Form validation: use CreatePOSDATASchema with zodResolver for type-safe create forms
 */
export function useCreatePOSDATA() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<POSDATA, "id">) => POSDATAService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["pOSDATA-list"] });
    },
  });
}

/**
 * Update an existing POSDATA record.
 * @remarks Form validation: use UpdatePOSDATASchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdatePOSDATA() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<POSDATA, "id">>;
    }) => POSDATAService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["pOSDATA-list"] });
      client.invalidateQueries({ queryKey: ["pOSDATA", variables.id] });
    },
  });
}

/**
 * Delete a POSDATA record by its unique identifier.
 */
export function useDeletePOSDATA() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => POSDATAService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["pOSDATA-list"] });
      client.invalidateQueries({ queryKey: ["pOSDATA", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const POSDATA_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { POSDATASchema, CreatePOSDATASchema, UpdatePOSDATASchema } from "../validators/posdata-validator";
export type { POSDATAInput, CreatePOSDATAInput, UpdatePOSDATAInput } from "../validators/posdata-validator";