import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { SupportModuleService } from "../services/support-module-service";
import type { SupportModule } from "../models/support-module-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all SupportModule records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, supportModuleName
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useSupportModuleList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["supportModule-list", options],
    queryFn: () => SupportModuleService.getAll(options),
  });
}

/**
 * Retrieve a single SupportModule record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useSupportModule(id: string) {
  return useQuery({
    queryKey: ["supportModule", id],
    queryFn: () => SupportModuleService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new SupportModule record.
 * @remarks Form validation: use CreateSupportModuleSchema with zodResolver for type-safe create forms
 */
export function useCreateSupportModule() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<SupportModule, "id">) => SupportModuleService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["supportModule-list"] });
    },
  });
}

/**
 * Update an existing SupportModule record.
 * @remarks Form validation: use UpdateSupportModuleSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateSupportModule() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<SupportModule, "id">>;
    }) => SupportModuleService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["supportModule-list"] });
      client.invalidateQueries({ queryKey: ["supportModule", variables.id] });
    },
  });
}

/**
 * Delete a SupportModule record by its unique identifier.
 */
export function useDeleteSupportModule() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => SupportModuleService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["supportModule-list"] });
      client.invalidateQueries({ queryKey: ["supportModule", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const SupportModule_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { SupportModuleSchema, CreateSupportModuleSchema, UpdateSupportModuleSchema } from "../validators/support-module-validator";
export type { SupportModuleInput, CreateSupportModuleInput, UpdateSupportModuleInput } from "../validators/support-module-validator";