import { z } from 'zod';

/**
 * Zod schema for AppUser validation
 */
export const AppUserSchema = z.object({
  id: z.string().uuid(),
  appUserName: z.string().min(1, { message: "App User Name is required" }),
});

/**
 * Schema for creating a new AppUser (omits system-generated ID)
 */
export const CreateAppUserSchema = AppUserSchema.omit({ id: true });

/**
 * Schema for updating an existing AppUser
 */
export const UpdateAppUserSchema = AppUserSchema;

export type AppUserInput = z.infer<typeof AppUserSchema>;
export type CreateAppUserInput = z.infer<typeof CreateAppUserSchema>;
export type UpdateAppUserInput = z.infer<typeof UpdateAppUserSchema>;