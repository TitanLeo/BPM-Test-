import { z } from 'zod';

/**
 * Zod schema for BSPAuditLog validation
 */
export const BSPAuditLogSchema = z.object({
  id: z.string().uuid(),
  auditLogName: z.string().min(1, { message: "Audit Log Name is required" }),
  actionKey: z.enum(['UserCreated', 'UserUpdated', 'UserDeleted', 'RoleChanged', 'PermissionChanged', 'AccountActivated', 'AccountDeactivated', 'UserLogin']),
  eventDate: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Event Date is required" }),
  modifiedByEmail: z.string().email().min(1, { message: "Modified By Email is required" }),
  modifiedByName: z.string().min(1, { message: "Modified By Name is required" }),
  newValue: z.string().optional(),
  oldValue: z.string().optional(),
  targetUser: z.object({ id: z.string().uuid(), emailAddress: z.string() }).optional(),
});

/**
 * Schema for creating a new BSPAuditLog (omits system-generated ID)
 */
export const CreateBSPAuditLogSchema = BSPAuditLogSchema.omit({ id: true });

/**
 * Schema for updating an existing BSPAuditLog
 */
export const UpdateBSPAuditLogSchema = BSPAuditLogSchema;

export type BSPAuditLogInput = z.infer<typeof BSPAuditLogSchema>;
export type CreateBSPAuditLogInput = z.infer<typeof CreateBSPAuditLogSchema>;
export type UpdateBSPAuditLogInput = z.infer<typeof UpdateBSPAuditLogSchema>;