import { z } from 'zod';

/**
 * Zod schema for BSPMMSTicketDetail validation
 */
export const BSPMMSTicketDetailSchema = z.object({
  id: z.string().uuid(),
  mMSTicketDetailName: z.string().min(1, { message: "MMS Ticket Detail Name is required" }),
  additionalNotes: z.string().optional(),
  detailsOfConcern: z.string().min(1, { message: "Details Of Concern is required" }),
  employeeID: z.string().min(1, { message: "Employee ID is required" }),
  employeeName: z.string().min(1, { message: "Employee Name is required" }),
  errorMessage: z.string().optional(),
  mMSID: z.string().min(1, { message: "MMS ID is required" }),
  requestTypeKey: z.enum(['PasswordReset', 'UnlockAccount', 'ChangePassword', 'NewAccount', 'AccessIssue', 'AccountDeactivation', 'Other']),
  ticket: z.object({ id: z.string().uuid(), operationalSupportRecordName: z.string() }),
});

/**
 * Schema for creating a new BSPMMSTicketDetail (omits system-generated ID)
 */
export const CreateBSPMMSTicketDetailSchema = BSPMMSTicketDetailSchema.omit({ id: true });

/**
 * Schema for updating an existing BSPMMSTicketDetail
 */
export const UpdateBSPMMSTicketDetailSchema = BSPMMSTicketDetailSchema;

export type BSPMMSTicketDetailInput = z.infer<typeof BSPMMSTicketDetailSchema>;
export type CreateBSPMMSTicketDetailInput = z.infer<typeof CreateBSPMMSTicketDetailSchema>;
export type UpdateBSPMMSTicketDetailInput = z.infer<typeof UpdateBSPMMSTicketDetailSchema>;