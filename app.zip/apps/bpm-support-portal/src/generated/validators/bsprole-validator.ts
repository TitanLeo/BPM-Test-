import { z } from 'zod';

/**
 * Zod schema for BSPRole validation
 */
export const BSPRoleSchema = z.object({
  id: z.string().uuid(),
  roleName: z.string().min(1, { message: "Role Name is required" }),
  createdDate: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Created Date is required" }),
  description: z.string().optional(),
  isSystemRole: z.boolean(),
  statusKey: z.enum(['Active', 'Inactive']),
});

/**
 * Schema for creating a new BSPRole (omits system-generated ID)
 */
export const CreateBSPRoleSchema = BSPRoleSchema.omit({ id: true });

/**
 * Schema for updating an existing BSPRole
 */
export const UpdateBSPRoleSchema = BSPRoleSchema;

export type BSPRoleInput = z.infer<typeof BSPRoleSchema>;
export type CreateBSPRoleInput = z.infer<typeof CreateBSPRoleSchema>;
export type UpdateBSPRoleInput = z.infer<typeof UpdateBSPRoleSchema>;