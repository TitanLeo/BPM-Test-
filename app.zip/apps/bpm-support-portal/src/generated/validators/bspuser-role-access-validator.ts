import { z } from 'zod';

/**
 * Zod schema for BSPUserRoleAccess validation
 */
export const BSPUserRoleAccessSchema = z.object({
  id: z.string().uuid(),
  accessName: z.string().min(1, { message: "Access Name is required" }),
  isGranted: z.boolean(),
  permissionKey: z.enum(['DashboardAccess', 'UserManagement', 'RoleManagement', 'TicketCreation', 'TicketAssignment', 'TicketUpdate', 'TicketClosure', 'TicketReopening', 'KnowledgeBaseAccess', 'AssetManagement', 'ProjectMonitoring', 'PowerBIDashboardAccess', 'SystemConfiguration']),
  role: z.object({ id: z.string().uuid(), roleName: z.string() }),
  updatedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Updated Date is required" }),
});

/**
 * Schema for creating a new BSPUserRoleAccess (omits system-generated ID)
 */
export const CreateBSPUserRoleAccessSchema = BSPUserRoleAccessSchema.omit({ id: true });

/**
 * Schema for updating an existing BSPUserRoleAccess
 */
export const UpdateBSPUserRoleAccessSchema = BSPUserRoleAccessSchema;

export type BSPUserRoleAccessInput = z.infer<typeof BSPUserRoleAccessSchema>;
export type CreateBSPUserRoleAccessInput = z.infer<typeof CreateBSPUserRoleAccessSchema>;
export type UpdateBSPUserRoleAccessInput = z.infer<typeof UpdateBSPUserRoleAccessSchema>;