import { z } from 'zod';

/**
 * Zod schema for BSPUser validation
 */
export const BSPUserSchema = z.object({
  id: z.string().uuid(),
  emailAddress: z.string().min(1, { message: "Email Address is required" }),
  accountStatusKey: z.enum(['Active', 'Inactive', 'Deleted']),
  branch: z.string().min(1, { message: "Branch is required" }),
  createdDate: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Created Date is required" }),
  department: z.string().min(1, { message: "Department is required" }),
  isDeleted: z.boolean(),
  lastLogin: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  position: z.string().min(1, { message: "Position is required" }),
  userRole: z.object({ id: z.string().uuid(), roleName: z.string() }),
});

/**
 * Schema for creating a new BSPUser (omits system-generated ID)
 */
export const CreateBSPUserSchema = BSPUserSchema.omit({ id: true });

/**
 * Schema for updating an existing BSPUser
 */
export const UpdateBSPUserSchema = BSPUserSchema;

export type BSPUserInput = z.infer<typeof BSPUserSchema>;
export type CreateBSPUserInput = z.infer<typeof CreateBSPUserSchema>;
export type UpdateBSPUserInput = z.infer<typeof UpdateBSPUserSchema>;