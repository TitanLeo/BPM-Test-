import { z } from 'zod';

/**
 * Zod schema for OperationalSupportRecord validation
 */
export const OperationalSupportRecordSchema = z.object({
  id: z.string().uuid(),
  operationalSupportRecordName: z.string().min(1, { message: "Operational Support Record Name is required" }),
  assignedTo: z.object({ id: z.string().uuid(), appUserName: z.string() }).optional(),
  completedDate: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  createdDate: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Created Date is required" }),
  description: z.string().optional(),
  dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format").optional(),
  priorityKey: z.enum(['Low', 'Normal', 'High', 'Critical']),
  recordTypeKey: z.enum(['AccountRequest', 'SystemIssue', 'DataCorrection', 'AccessReview', 'Maintenance', 'Incident']),
  requestedBy: z.object({ id: z.string().uuid(), appUserName: z.string() }),
  statusKey: z.enum(['Draft', 'Submitted', 'InReview', 'InProgress', 'Completed', 'Cancelled']),
  supportModule: z.object({ id: z.string().uuid(), supportModuleName: z.string() }),
});

/**
 * Schema for creating a new OperationalSupportRecord (omits system-generated ID)
 */
export const CreateOperationalSupportRecordSchema = OperationalSupportRecordSchema.omit({ id: true });

/**
 * Schema for updating an existing OperationalSupportRecord
 */
export const UpdateOperationalSupportRecordSchema = OperationalSupportRecordSchema;

export type OperationalSupportRecordInput = z.infer<typeof OperationalSupportRecordSchema>;
export type CreateOperationalSupportRecordInput = z.infer<typeof CreateOperationalSupportRecordSchema>;
export type UpdateOperationalSupportRecordInput = z.infer<typeof UpdateOperationalSupportRecordSchema>;