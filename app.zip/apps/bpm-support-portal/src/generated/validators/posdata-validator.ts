import { z } from 'zod';

/**
 * Zod schema for POSDATA validation
 */
export const POSDATASchema = z.object({
  id: z.string().uuid(),
  pOS: z.string().min(1, { message: "POS is required" }),
  age: z.number().int().optional(),
  availableWorkingPOS: z.string().optional(),
  branch: z.string().optional(),
  dateEncountered: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  dateReported: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").optional(),
  dateResolved: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format").optional(),
  issue: z.string().optional(),
  issueCategoryKey: z.enum(['Software', 'ServerRelated', 'Network', 'HumanError', 'ElectricPower', 'Hardware', 'HardwareVFD', 'HardwareCashDrawer', 'HardwareUPS', 'HardwareScanner', 'HardwarePrinter', 'HardwareMSR', 'HardwareMonitor', 'HardwareEFT', 'HardwareCPU', 'HardwarePower', 'HardwareHDD', 'HardwarePOSInternalComponents', 'Undetermined']).optional(),
  model: z.string().optional(),
  resolution: z.string().optional(),
  rootCause: z.string().optional(),
  status: z.string().optional(),
  support: z.string().optional(),
  ticketage: z.string().optional(),
  ticketIDNumber: z.number().int().optional(),
  tID: z.number().int().optional(),
  wITHMANUALPADDEDSI: z.boolean().optional(),
  wITHPROCESSEDTRANSACTIONSBEFOREISSUE: z.boolean().optional(),
});

/**
 * Schema for creating a new POSDATA (omits system-generated ID)
 */
export const CreatePOSDATASchema = POSDATASchema.omit({ id: true });

/**
 * Schema for updating an existing POSDATA
 */
export const UpdatePOSDATASchema = POSDATASchema;

export type POSDATAInput = z.infer<typeof POSDATASchema>;
export type CreatePOSDATAInput = z.infer<typeof CreatePOSDATASchema>;
export type UpdatePOSDATAInput = z.infer<typeof UpdatePOSDATASchema>;