import { z } from 'zod';

/**
 * Zod schema for SupportModule validation
 */
export const SupportModuleSchema = z.object({
  id: z.string().uuid(),
  supportModuleName: z.string().min(1, { message: "Support Module Name is required" }),
});

/**
 * Schema for creating a new SupportModule (omits system-generated ID)
 */
export const CreateSupportModuleSchema = SupportModuleSchema.omit({ id: true });

/**
 * Schema for updating an existing SupportModule
 */
export const UpdateSupportModuleSchema = SupportModuleSchema;

export type SupportModuleInput = z.infer<typeof SupportModuleSchema>;
export type CreateSupportModuleInput = z.infer<typeof CreateSupportModuleSchema>;
export type UpdateSupportModuleInput = z.infer<typeof UpdateSupportModuleSchema>;