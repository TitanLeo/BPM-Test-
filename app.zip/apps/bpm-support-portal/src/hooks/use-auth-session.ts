import { useEffect, useMemo, useState } from 'react';

import { useUser } from '@/hooks/use-user';
import { createLoginAudit, resolvePortalUser } from '@/lib/auth-access';
import type { AccessStatus, LoginAuditRecord, PortalUser } from '@/lib/auth-access';

type M365User = {
  fullName?: string;
  userPrincipalName?: string;
};

export type AuthSession = {
  status: AccessStatus;
  user?: PortalUser;
  loginAudit?: LoginAuditRecord;
  detectedEmail?: string;
};

export function useAuthSession(): AuthSession {
  const { data, isLoading } = useUser();
  const [loginAudit, setLoginAudit] = useState<LoginAuditRecord>();
  const m365User = data as M365User | undefined;
  const detectedEmail = m365User?.userPrincipalName;
  const detectedName = m365User?.fullName;

  const portalUser = useMemo(() => {
    if (isLoading) return undefined;
    return resolvePortalUser(detectedEmail, detectedName);
  }, [detectedEmail, detectedName, isLoading]);

  useEffect(() => {
    if (!portalUser || loginAudit?.sessionId === portalUser.sessionId) return;
    setLoginAudit(createLoginAudit(portalUser));
  }, [loginAudit?.sessionId, portalUser]);

  if (isLoading) {
    return { status: 'loading', detectedEmail };
  }

  if (!portalUser) {
    return { status: 'denied', detectedEmail };
  }

  return { status: 'authorized', user: portalUser, loginAudit, detectedEmail };
}
