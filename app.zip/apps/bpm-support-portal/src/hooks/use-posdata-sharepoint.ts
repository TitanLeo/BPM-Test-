export {
  useCreatePOSDATA,
  useDeletePOSDATA,
  usePOSDATA,
  usePOSDATAList,
  useUpdatePOSDATA,
} from '@/lib/pos-data-store';
import type { POSDATA } from '@/lib/pos-data-store';

export type { POSDATA };
export type POSDATARecord = POSDATA;