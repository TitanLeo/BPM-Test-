import { useCreatePOSDATA, usePOSDATAList, type POSDATA } from '@/hooks/use-posdata-sharepoint';

export type TestQue = POSDATA;

export const useTestQueSharePointList = usePOSDATAList;
export const useCreateTestQueSharePoint = useCreatePOSDATA;
