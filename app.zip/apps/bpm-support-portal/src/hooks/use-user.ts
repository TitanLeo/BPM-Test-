import { useQuery } from '@tanstack/react-query';
import { getContext } from '@microsoft/power-apps/app';

type SafeUser = {
  fullName?: string;
  userPrincipalName?: string;
  objectId?: string;
  tenantId?: string;
};

const fallbackUser: SafeUser = {
  fullName: 'Maria Santos',
  userPrincipalName: 'maria.santos@example.com',
  objectId: 'a3963e7d-0916-41da-9809-0ecd2e5b6e0d',
  tenantId: 'mock-tenant',
};

export const useUser = () => {
  return useQuery({
    queryKey: ['user'],
    queryFn: async (): Promise<SafeUser> => {
      try {
        const context = await getContext();
        return context.user ?? fallbackUser;
      } catch (error: unknown) {
        console.warn('Using mock user context because Power Apps context is unavailable.', error);
        return fallbackUser;
      }
    },
  });
};
