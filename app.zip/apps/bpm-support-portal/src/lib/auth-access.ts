import type { LucideIcon } from 'lucide-react';
import { BarChart3, BookOpen, BriefcaseBusiness, ClipboardList, FileCheck2, FolderKanban, Gauge, Headset, LayoutDashboard, PackageSearch, Settings, TicketPlus } from 'lucide-react';

type Branch = { id: string; branchCode: string; branchName: string; region: string; statusKey: 'Active' | 'Inactive' };
type Role = { id: string };

export type BspRole = 'Branch User' | 'Branch Supervisor' | 'Technician' | 'Senior Officer' | 'Manager' | 'Administrator';
export type AccessStatus = 'loading' | 'authorized' | 'denied';

export type PortalUser = {
  userId: string;
  email: string;
  displayName: string;
  branchId: string;
  branchName: string;
  branchCode: string;
  region: string;
  roleId: string;
  roleName: BspRole;
  status: 'Active' | 'Inactive';
  isActive: boolean;
  createdDate: string;
  lastLoginDate: string;
  sessionId: string;
};

export type PermissionItem = {
  label: string;
  path: string;
  icon: LucideIcon;
};

export type LoginAuditRecord = {
  logId: string;
  userEmail: string;
  userName: string;
  branchId: string;
  branchName: string;
  loginDateTime: string;
  sessionId: string;
  action: 'LOGIN';
};

const roles: Array<Role & { roleName: BspRole }> = [
  { id: '78dd4319-1f54-42fe-83d2-8a62f5677fe8', roleName: 'Branch User' },
  { id: '6498a1e4-ecc6-45ca-8954-bd6255c5df77', roleName: 'Branch Supervisor' },
  { id: '5d2ca931-63e2-4ba2-946a-b39e5bb38854', roleName: 'Technician' },
  { id: 'a46c7ce1-484b-4e38-b9f1-4cc676fbf0f9', roleName: 'Senior Officer' },
  { id: '9480654b-e5ba-4871-92d5-1ff6c53026af', roleName: 'Manager' },
  { id: 'c4ecacbd-7c32-4ed7-b032-e78549ebbaf2', roleName: 'Administrator' },
];

const branches: Branch[] = [
  { id: '8868657b-6d33-41d9-a5f2-d77131fbee39', branchCode: 'SSL', branchName: 'SM San Lazaro', region: 'Metro Manila', statusKey: 'Active' },
  { id: '0bac6915-31a5-4108-933c-b9c93aab3733', branchCode: 'SNE', branchName: 'SM North EDSA', region: 'Metro Manila', statusKey: 'Active' },
  { id: '6cbb6f84-34ef-403a-b795-8c042c522fc6', branchCode: 'HOBPM', branchName: 'Head Office BPM', region: 'National Capital Region', statusKey: 'Active' },
];

type DirectoryUser = Omit<PortalUser, 'branchName' | 'branchCode' | 'region' | 'roleName' | 'sessionId'>;

const directoryUsers: DirectoryUser[] = [
  {
    userId: '4b22c1b7-9ef6-43a1-92d7-63dd46f4d112',
    email: 'juan@company.com',
    displayName: 'Juan Dela Cruz',
    branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39',
    roleId: '78dd4319-1f54-42fe-83d2-8a62f5677fe8',
    status: 'Active',
    isActive: true,
    createdDate: '2026-07-10T08:00:00.000Z',
    lastLoginDate: '2026-08-04T01:20:00.000Z',
  },
  {
    userId: 'ddf52101-7035-4e38-b8cd-2f9cbb6fe635',
    email: 'supervisor@company.com',
    displayName: 'San Lazaro Supervisor',
    branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39',
    roleId: '6498a1e4-ecc6-45ca-8954-bd6255c5df77',
    status: 'Active',
    isActive: true,
    createdDate: '2026-07-08T09:00:00.000Z',
    lastLoginDate: '2026-08-04T00:55:00.000Z',
  },
  {
    userId: 'a3963e7d-0916-41da-9809-0ecd2e5b6e0d',
    email: 'maria.santos@example.com',
    displayName: 'Maria Santos',
    branchId: '6cbb6f84-34ef-403a-b795-8c042c522fc6',
    roleId: 'c4ecacbd-7c32-4ed7-b032-e78549ebbaf2',
    status: 'Active',
    isActive: true,
    createdDate: '2026-07-01T08:00:00.000Z',
    lastLoginDate: '2026-08-04T01:00:00.000Z',
  },
];

export const rolePermissions: Record<BspRole, PermissionItem[]> = {
  'Branch User': [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Create Ticket', path: '/helpdesk', icon: TicketPlus },
    { label: 'My Branch Tickets', path: '/helpdesk', icon: ClipboardList },
    { label: 'Knowledge Base', path: '/documents', icon: BookOpen },
    { label: 'Document Monitoring', path: '/documents', icon: FileCheck2 },
    { label: 'Document Monitoring', path: '/documents', icon: FileCheck2 },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
  ],
  'Branch Supervisor': [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Branch Tickets', path: '/helpdesk', icon: ClipboardList },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
    { label: 'Knowledge Base', path: '/documents', icon: BookOpen },
  ],
  Technician: [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Assigned Tickets', path: '/helpdesk', icon: Headset },
    { label: 'Assets', path: '/modules/hardware', icon: PackageSearch },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
    { label: 'Knowledge Base', path: '/documents', icon: BookOpen },
  ],
  'Senior Officer': [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Support', path: '/helpdesk', icon: Headset },
    { label: 'Assets', path: '/modules/hardware', icon: PackageSearch },
    { label: 'Projects', path: '/modules/crms', icon: FolderKanban },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
  ],
  Manager: [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Support', path: '/helpdesk', icon: Headset },
    { label: 'Assets', path: '/modules/hardware', icon: PackageSearch },
    { label: 'Document Monitoring', path: '/documents', icon: FileCheck2 },
    { label: 'Projects', path: '/modules/crms', icon: FolderKanban },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
    { label: 'KPI Dashboard', path: '/reports', icon: Gauge },
  ],
  Administrator: [
    { label: 'Full System', path: '/settings', icon: Settings },
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Document Monitoring', path: '/documents', icon: FileCheck2 },
    { label: 'Modules', path: '/modules', icon: BriefcaseBusiness },

    { label: 'Support', path: '/helpdesk', icon: Headset },
    { label: 'Reports', path: '/reports', icon: BarChart3 },
  ],
};

export function createSessionId(email: string): string {
  const normalizedEmail = email.toLowerCase().replace(/[^a-z0-9]/g, '-');
  return `bsp-${normalizedEmail}-${Date.now().toString(36)}`;
}

export function resolvePortalUser(email: string | undefined, fallbackName: string | undefined): PortalUser | undefined {
  const normalizedEmail = email?.toLowerCase() ?? 'maria.santos@example.com';
  const directoryUser = directoryUsers.find((user: DirectoryUser) => user.email.toLowerCase() === normalizedEmail) ?? directoryUsers[2];
  const branch = branches.find((item: Branch) => item.id === directoryUser.branchId);
  const role = roles.find((item: Role & { roleName: BspRole }) => item.id === directoryUser.roleId);

  if (!branch || !role || !directoryUser.isActive || directoryUser.status !== 'Active') return undefined;

  return {
    ...directoryUser,
    displayName: fallbackName ?? directoryUser.displayName,
    branchName: branch.branchName,
    branchCode: branch.branchCode,
    region: branch.region,
    roleName: role.roleName,
    sessionId: createSessionId(directoryUser.email),
  };
}

export function createLoginAudit(user: PortalUser): LoginAuditRecord {
  return {
    logId: crypto.randomUUID(),
    userEmail: user.email,
    userName: user.displayName,
    branchId: user.branchId,
    branchName: user.branchName,
    loginDateTime: new Date().toISOString(),
    sessionId: user.sessionId,
    action: 'LOGIN',
  };
}

export function canAccessPath(user: PortalUser | undefined, path: string): boolean {
  if (!user) return false;
  if (user.roleName === 'Administrator') return true;
  const permissions = rolePermissions[user.roleName];
  return permissions.some((permission: PermissionItem) => path === permission.path || path.startsWith(`${permission.path}/`));
}

export function filterTicketsByBranch<Ticket extends { branchId?: string }>(tickets: Ticket[], user: PortalUser): Ticket[] {
  if (user.roleName === 'Administrator' || user.roleName === 'Manager' || user.roleName === 'Senior Officer' || user.roleName === 'Technician') return tickets;
  return tickets.filter((ticket: Ticket) => ticket.branchId === user.branchId);
}
