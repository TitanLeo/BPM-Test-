import { Activity, BarChart3, Camera, ClipboardList, FileCheck2, FileText, HardDrive, Headphones, Landmark, MonitorCog, Package, Settings, ShieldCheck, ShoppingCart, UserCog, WalletCards } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type Role = 'Superadmin' | 'Manager' | 'Officer' | 'Technician' | 'Requestor';
export type Status = 'Open' | 'In Progress' | 'Needs Attention' | 'Resolved' | 'Closed' | 'Pending Review' | 'Verified';
export type Priority = 'Low' | 'Normal' | 'High' | 'Critical';

export type ModuleInfo = { name: string; path: string; icon: LucideIcon; owner: string };
export type OperationalRecord = { ticketNo: string; module: string; requestor: string; assignedTo: string; status: Status; priority: Priority; dueDate: string; progress: number; branchId: string; createdBy: string; modifiedBy: string; modifiedDate: string };
export type HelpdeskTicket = OperationalRecord & { summary: string; created: string; sla: string };
export type ReportCard = { title: string; module: string; schedule: string; status: string; completion: number };
export type DocumentRecord = { reference: string; title: string; module: string; status: Status; owner: string; dueDate: string };

export const currentRole: Role = 'Superadmin';

export const modules: ModuleInfo[] = [
  { name: 'ADID', path: '/modules/adid', icon: UserCog, owner: 'Identity Support' },
  { name: 'SAP', path: '/modules/sap', icon: Package, owner: 'Finance Systems' },
  { name: 'CRMS', path: '/modules/crms', icon: ClipboardList, owner: 'Customer Ops' },
  { name: 'OS', path: '/modules/os', icon: MonitorCog, owner: 'Operations' },
  { name: 'ZPIRS', path: '/modules/zpirs', icon: ShieldCheck, owner: 'Risk Support' },
  { name: 'FIS Treasury', path: '/modules/fis-treasury', icon: WalletCards, owner: 'Treasury' },
  { name: 'CCTV', path: '/modules/cctv', icon: Camera, owner: 'Security Ops' },
  { name: 'POS', path: '/modules/pos', icon: ShoppingCart, owner: 'Store Systems' },

  { name: 'Hardware', path: '/modules/hardware', icon: HardDrive, owner: 'Field Support' },
  { name: 'MMS', path: '/modules/mms', icon: Activity, owner: 'Merch Systems' },
  { name: 'PhilCom', path: '/modules/philcom', icon: Landmark, owner: 'Communications' },
];

export const navItems = [
  { label: 'Dashboard', path: '/', icon: BarChart3 },
  { label: 'Modules', path: '/modules', icon: ClipboardList },
  ...modules.filter((module: ModuleInfo) => module.path.startsWith('/modules/')).map((module: ModuleInfo) => ({ label: module.name, path: module.path, icon: module.icon })),

  { label: 'OSD Helpdesk', path: '/helpdesk', icon: Headphones },
  { label: 'Reports', path: '/reports', icon: FileText },
  { label: 'Document Monitoring', path: '/documents', icon: FileCheck2 },
  { label: 'Settings', path: '/settings', icon: Settings, superadminOnly: true },
];

export const records: OperationalRecord[] = [
  { ticketNo: 'BPM-240801', module: 'ADID', requestor: 'Patricia Garcia', assignedTo: 'Daniel Lim', status: 'Open', priority: 'Normal', dueDate: 'Aug 05', progress: 24, branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39', createdBy: 'juan@company.com', modifiedBy: 'daniel.lim@example.com', modifiedDate: 'Aug 04, 10:20' },
  { ticketNo: 'BPM-240802', module: 'SAP', requestor: 'Angela Reyes', assignedTo: 'Robert Cruz', status: 'Needs Attention', priority: 'High', dueDate: 'Aug 04', progress: 48, branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39', createdBy: 'supervisor@company.com', modifiedBy: 'robert.cruz@example.com', modifiedDate: 'Aug 04, 11:10' },
  { ticketNo: 'BPM-240803', module: 'CRMS', requestor: 'Patricia Garcia', assignedTo: 'Angela Reyes', status: 'In Progress', priority: 'Normal', dueDate: 'Aug 06', progress: 62, branchId: '0bac6915-31a5-4108-933c-b9c93aab3733', createdBy: 'maria@company.com', modifiedBy: 'angela.reyes@example.com', modifiedDate: 'Aug 04, 12:05' },
  { ticketNo: 'BPM-240804', module: 'CCTV', requestor: 'Robert Cruz', assignedTo: 'Daniel Lim', status: 'Resolved', priority: 'High', dueDate: 'Aug 03', progress: 100, branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39', createdBy: 'supervisor@company.com', modifiedBy: 'daniel.lim@example.com', modifiedDate: 'Aug 03, 16:30' },
  { ticketNo: 'BPM-240805', module: 'POS', requestor: 'Patricia Garcia', assignedTo: 'Daniel Lim', status: 'Open', priority: 'Critical', dueDate: 'Aug 03', progress: 12, branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39', createdBy: 'juan@company.com', modifiedBy: 'daniel.lim@example.com', modifiedDate: 'Aug 04, 13:40' },
  { ticketNo: 'BPM-240806', module: 'Hardware', requestor: 'Maria Santos', assignedTo: 'Field Support', status: 'Closed', priority: 'Low', dueDate: 'Aug 02', progress: 100, branchId: '6cbb6f84-34ef-403a-b795-8c042c522fc6', createdBy: 'maria.santos@example.com', modifiedBy: 'field.support@example.com', modifiedDate: 'Aug 02, 15:15' },
];

export const tickets: HelpdeskTicket[] = records.slice(0, 5).map((record: OperationalRecord, index: number) => ({
  ...record,
  summary: ['POS receipt printer not responding', 'ADID password reset failing', 'SAP approval screen timeout', 'CCTV playback export request', 'CRMS maintenance notice'][index] ?? 'Support request',
  created: `Aug 0${index + 1}, 09:${index}0`,
  sla: index === 1 ? 'Escalated' : index === 3 ? 'Met' : 'Tracking',
}));

export const weeklyThroughput = [
  { day: 'Mon', opened: 18, resolved: 12 },
  { day: 'Tue', opened: 24, resolved: 16 },
  { day: 'Wed', opened: 20, resolved: 18 },
  { day: 'Thu', opened: 28, resolved: 22 },
  { day: 'Fri', opened: 16, resolved: 20 },
];

export const statusDistribution = [
  { name: 'Open', value: 34 },
  { name: 'Needs Attention', value: 9 },
  { name: 'In Progress', value: 27 },
  { name: 'Resolved', value: 42 },
];

export const reportCards: ReportCard[] = [
  { title: 'ADID Weekly Access Report', module: 'ADID', schedule: 'Weekly', status: 'Completed', completion: 100 },
  { title: 'SAP Month-End Support Report', module: 'SAP', schedule: 'Monthly', status: 'In Progress', completion: 60 },
  { title: 'CRMS Daily Case Report', module: 'CRMS', schedule: 'Daily', status: 'Completed', completion: 100 },
  { title: 'CCTV Incident Summary', module: 'CCTV', schedule: 'Weekly', status: 'Delayed', completion: 40 },
];

export const documents: DocumentRecord[] = [
  { reference: 'ADID-2026-081', title: 'ADID Access Form', module: 'ADID', status: 'Verified', owner: 'Angela Reyes', dueDate: 'Aug 03' },
  { reference: 'SAP-2026-044', title: 'SAP Approval Memo', module: 'SAP', status: 'Pending Review', owner: 'Robert Cruz', dueDate: 'Aug 05' },
  { reference: 'CRMS-2026-019', title: 'CRMS Merge Checklist', module: 'CRMS', status: 'Verified', owner: 'Angela Reyes', dueDate: 'Aug 04' },
  { reference: 'POS-2026-058', title: 'POS Incident Report', module: 'POS', status: 'Open', owner: 'Daniel Lim', dueDate: 'Aug 06' },
];
