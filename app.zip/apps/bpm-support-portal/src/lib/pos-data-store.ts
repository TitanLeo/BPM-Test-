import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

export const POSDATAIssueCategoryKeyToLabel = {
  Hardware: 'Hardware',
  Software: 'Software',
  Network: 'Network',
  Transaction: 'Transaction',
  Other: 'Other',
} as const;

export type POSDATAIssueCategoryKey = keyof typeof POSDATAIssueCategoryKeyToLabel;

export type POSDATA = {
  id: string;
  pOS: string;
  branch?: string;
  tID?: number;
  ticketIDNumber?: number;
  issue?: string;
  issueCategoryKey?: POSDATAIssueCategoryKey;
  dateReported?: string;
  dateEncountered?: string;
  dateResolved?: string;
  status?: string;
  support?: string;
  model?: string;
  rootCause?: string;
  resolution?: string;
  age?: number;
  ticketage?: string;
  availableWorkingPOS?: string;
  wITHMANUALPADDEDSI?: boolean;
  wITHPROCESSEDTRANSACTIONSBEFOREISSUE?: boolean;
};

const queryKey = ['local-pos-data'] as const;
let records: POSDATA[] = [];

export function usePOSDATAList() {
  return useQuery({ queryKey, queryFn: async (): Promise<POSDATA[]> => records });
}

export function usePOSDATA(id: string) {
  return useQuery({ queryKey: [...queryKey, id], queryFn: async (): Promise<POSDATA | undefined> => records.find((record: POSDATA) => record.id === id) });
}

export function useCreatePOSDATA() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: async (data: Omit<POSDATA, 'id'>): Promise<POSDATA> => {
      const created = { ...data, id: crypto.randomUUID() };
      records = [created, ...records];
      return created;
    },
    onSuccess: () => client.invalidateQueries({ queryKey }),
  });
}

export function useUpdatePOSDATA() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, changedFields }: { id: string; changedFields: Partial<Omit<POSDATA, 'id'>> }): Promise<POSDATA> => {
      const existing = records.find((record: POSDATA) => record.id === id);
      if (!existing) throw new Error('POS ticket not found.');
      const updated = { ...existing, ...changedFields };
      records = records.map((record: POSDATA) => record.id === id ? updated : record);
      return updated;
    },
    onSuccess: () => client.invalidateQueries({ queryKey }),
  });
}

export function useDeletePOSDATA() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: async (id: string): Promise<void> => { records = records.filter((record: POSDATA) => record.id !== id); },
    onSuccess: () => client.invalidateQueries({ queryKey }),
  });
}
