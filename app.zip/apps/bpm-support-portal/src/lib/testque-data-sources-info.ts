export const testQueDataSourcesInfo = {
  testque: {
    tableId: 'd3637b19-0d6e-4170-9664-15be12f939f3',
    version: '',
    primaryKey: 'ID',
    dataSourceType: 'Connector',
    apis: {
      GetAuthor: {
        path: '/{connectionId}/datasets/{dataset}/tables/d3637b190d6e4170966415be12f939f3/entities/Author',
        method: 'GET',
        parameters: [
          { name: 'connectionId', in: 'path', required: true, type: 'string' },
          { name: 'dataset', in: 'path', required: true, type: 'string' },
          { name: 'table', in: 'path', required: true, type: 'string' },
          { name: 'search', in: 'query', required: false, type: 'string' },
        ],
        responseInfo: { '200': { type: 'array' } },
      },
      GetEditor: {
        path: '/{connectionId}/datasets/{dataset}/tables/d3637b190d6e4170966415be12f939f3/entities/Editor',
        method: 'GET',
        parameters: [
          { name: 'connectionId', in: 'path', required: true, type: 'string' },
          { name: 'dataset', in: 'path', required: true, type: 'string' },
          { name: 'table', in: 'path', required: true, type: 'string' },
          { name: 'search', in: 'query', required: false, type: 'string' },
        ],
        responseInfo: { '200': { type: 'array' } },
      },
      Get4651e8f238c94ad08def41f743f76f30: {
        path: '/{connectionId}/datasets/{dataset}/tables/d3637b190d6e4170966415be12f939f3/entities/4651e8f238c94ad08def41f743f76f30',
        method: 'GET',
        parameters: [
          { name: 'connectionId', in: 'path', required: true, type: 'string' },
          { name: 'dataset', in: 'path', required: true, type: 'string' },
          { name: 'table', in: 'path', required: true, type: 'string' },
          { name: 'search', in: 'query', required: false, type: 'string' },
        ],
        responseInfo: { '200': { type: 'array' } },
      },
    },
  },
};
