import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  BarChart3,
  Bell,
  Briefcase,
  Building2,
  Camera,
  ChevronDown,
  ChevronRight,
  FileCheck2,
  FileText,
  FolderKanban,
  Headset,
  Home,
  Key,
  LockKeyhole,
  Mail,
  Menu,
  Monitor,
  Package,
  PanelLeftOpen,
  Receipt,
  Search,
  Settings2,
  Shield,
  ShieldCheck,
  Users,
} from 'lucide-react';
import { type ChangeEvent, type FormEvent, type MouseEvent, useMemo, useState } from 'react';

import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { UserProfilePanel } from '@/components/user-profile-panel';
import { useAuthSession } from '@/hooks/use-auth-session';
import { canAccessPath, filterTicketsByBranch } from '@/lib/auth-access';
import { documents, modules, records, reportCards, tickets } from '@/lib/mock-data';
import type { DocumentRecord, HelpdeskTicket, ModuleInfo, OperationalRecord, ReportCard } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

type SidebarProps = {
  collapsed: boolean;
  onCollapseToggle?: () => void;
  onNavigate?: () => void;
};

type ChildNavItem = {
  label: string;
  path: string;
  icon: typeof Home;
};

type SearchResult = {
  id: string;
  title: string;
  description: string;
  path: string;
  type: 'Ticket' | 'Module' | 'Document' | 'Report';
  icon: typeof Search;
};

const moduleItems: ChildNavItem[] = [
  { label: 'ADID', path: '/modules/adid', icon: Key },
  { label: 'SAP', path: '/modules/sap', icon: Shield },
  { label: 'CRMS', path: '/modules/crms', icon: Users },
  { label: 'OS', path: '/modules/os', icon: Monitor },
  { label: 'ZPIRS', path: '/modules/zpirs', icon: ShieldCheck },
  { label: 'FIS Treasury', path: '/modules/fis-treasury', icon: Mail },

  { label: 'CCTV', path: '/modules/cctv', icon: Camera },
  { label: 'POS', path: '/modules/pos', icon: Receipt },
  { label: 'Hardware', path: '/modules/hardware', icon: Package },
  { label: 'MMS', path: '/modules/mms', icon: Briefcase },
  { label: 'PhilCom', path: '/modules/philcom', icon: Building2 },
];

const helpdeskItems: ChildNavItem[] = [
  { label: 'Home', path: '/helpdesk#dashboard', icon: Home },
  { label: 'Create Ticket', path: '/helpdesk#create', icon: Headset },
  { label: 'All Tickets', path: '/helpdesk#list', icon: FileCheck2 },
  { label: 'Help', path: '/helpdesk#help', icon: ShieldCheck },
  { label: 'Settings', path: '/helpdesk#settings', icon: LockKeyhole },
];

const settingsItems: ChildNavItem[] = [
  { label: 'Overview', path: '/settings', icon: Home },
  { label: 'System Settings', path: '/settings/system', icon: Settings2 },
  { label: 'User Account Management', path: '/settings/user-account-management', icon: Users },
];
const searchIndex: SearchResult[] = [
  ...records.map((record: OperationalRecord) => ({
    id: `record-${record.ticketNo}`,
    title: record.ticketNo,
    description: `${record.module} · ${record.requestor} · ${record.status} · ${record.priority}`,
    path: '/helpdesk#list',
    type: 'Ticket' as const,
    icon: Headset,
  })),
  ...tickets.map((ticket: HelpdeskTicket) => ({
    id: `ticket-${ticket.ticketNo}`,
    title: ticket.summary,
    description: `${ticket.ticketNo} · ${ticket.module} · ${ticket.assignedTo} · ${ticket.sla}`,
    path: '/helpdesk#list',
    type: 'Ticket' as const,
    icon: Headset,
  })),
  ...modules.map((module: ModuleInfo) => ({
    id: `module-${module.path}`,
    title: module.name,
    description: `${module.owner} support module`,
    path: module.path,
    type: 'Module' as const,
    icon: module.icon,
  })),
  ...documents.map((document: DocumentRecord) => ({
    id: `document-${document.reference}`,
    title: document.title,
    description: `${document.reference} · ${document.module} · ${document.status} · ${document.owner}`,
    path: '/documents',
    type: 'Document' as const,
    icon: FileCheck2,
  })),
  ...reportCards.map((report: ReportCard) => ({
    id: `report-${report.title}`,
    title: report.title,
    description: `${report.module} · ${report.schedule} · ${report.status}`,
    path: '/reports',
    type: 'Report' as const,
    icon: FileText,
  })),
];

function SidebarNavLink({ item, collapsed, onNavigate }: { item: ChildNavItem; collapsed: boolean; onNavigate?: () => void }) {
  const Icon = item.icon;
  const location = useLocation();
  const currentPath = `${location.pathname}${location.hash}`;
  const isHashLink = item.path.includes('#');
  const isActive = isHashLink ? currentPath === item.path : location.pathname === item.path;

  return (
    <NavLink
      to={item.path}
      onClick={onNavigate}
      className={cn(
        'group flex items-center gap-3 rounded-xl px-3 py-3 text-base font-semibold text-sidebar-foreground transition-all duration-200 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
        isActive && 'bg-sidebar-primary text-sidebar-primary-foreground shadow-[inset_4px_0_0_var(--sidebar-primary)]',
        collapsed && 'justify-center px-2 py-4'
      )}
    >
      <Icon className={cn('shrink-0', collapsed ? '!h-10 !w-10' : '!h-6 !w-6')} />
      {!collapsed && <span className="leading-tight">{item.label}</span>}
    </NavLink>
  );
}

function GlobalSearch() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [focused, setFocused] = useState(false);
  const normalizedQuery = query.trim().toLowerCase();
  const results = useMemo<SearchResult[]>(() => {
    if (!normalizedQuery) return [];
    return searchIndex
      .filter((item: SearchResult) => `${item.title} ${item.description} ${item.type}`.toLowerCase().includes(normalizedQuery))
      .slice(0, 6);
  }, [normalizedQuery]);

  const goToResult = (result: SearchResult): void => {
    setQuery('');
    setFocused(false);
    navigate(result.path);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    const firstResult = results[0];
    if (firstResult) goToResult(firstResult);
  };

  return (
    <form onSubmit={handleSubmit} className="relative hidden w-full max-w-sm lg:block">
      <div className="flex items-center rounded-full border border-input bg-background px-3 text-foreground shadow-sm focus-within:ring-2 focus-within:ring-ring">
        <Search className="h-4 w-4 text-muted-foreground" />
        <Input
          aria-label="Search dashboard"
          value={query}
          onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => window.setTimeout(() => setFocused(false), 120)}
          placeholder="Search tickets, modules, requestors"
          className="border-0 bg-transparent shadow-none focus-visible:ring-0"
        />
      </div>
      {focused && normalizedQuery && (
        <div className="absolute left-0 right-0 top-12 z-50 overflow-hidden rounded-2xl border border-card-outline bg-popover text-popover-foreground shadow-card">
          {results.length > 0 ? (
            <div className="max-h-96 overflow-y-auto p-2">
              {results.map((result: SearchResult) => {
                const Icon = result.icon;
                return (
                  <button
                    key={result.id}
                    type="button"
                    onMouseDown={(event: MouseEvent<HTMLButtonElement>) => event.preventDefault()}
                    onClick={() => goToResult(result)}
                    className="flex w-full items-start gap-3 rounded-xl p-3 text-left transition-colors hover:bg-secondary hover:text-secondary-foreground"
                  >
                    <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      <Icon className="h-4 w-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2">
                        <span className="truncate text-sm font-semibold">{result.title}</span>
                        <Badge variant="secondary" className="bg-secondary text-secondary-foreground">{result.type}</Badge>
                      </span>
                      <span className="mt-1 block truncate text-xs text-muted-foreground">{result.description}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="p-4 text-sm text-muted-foreground">No matching tickets, modules, documents, or reports.</div>
          )}
        </div>
      )}
    </form>
  );
}

function SidebarContent({ collapsed, onCollapseToggle, onNavigate }: SidebarProps) {
  const location = useLocation();
  const [settingsOpen, setSettingsOpen] = useState(location.pathname.startsWith('/settings'));
  const { user } = useAuthSession();
  const [modulesOpen, setModulesOpen] = useState(location.pathname.startsWith('/modules'));
  const [helpdeskOpen, setHelpdeskOpen] = useState(location.pathname.startsWith('/helpdesk'));
  const branchTickets = user ? filterTicketsByBranch(tickets, user) : tickets;
  const openTicketCount = branchTickets.filter((ticket: HelpdeskTicket) => ticket.status !== 'Closed' && ticket.status !== 'Resolved').length;
  const visibleModules = user?.roleName === 'Administrator' ? moduleItems : moduleItems.filter((item: ChildNavItem) => canAccessPath(user, item.path));

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-20 items-center gap-3 border-b border-sidebar-border px-4">
        <Button variant="ghost" size="icon-sm" onClick={onCollapseToggle} className="text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
          {collapsed ? <PanelLeftOpen className="!h-9 !w-9" /> : <Menu className="!h-7 !w-7" />}
        </Button>
        <Link to="/" onClick={onNavigate} className={cn('flex min-w-0 items-center gap-3', collapsed && 'hidden')}>
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-sidebar-primary-foreground shadow-sm">
            <Shield className="!h-7 !w-7" />
          </span>
          <span className="leading-tight">
            <span className="block text-lg font-semibold">BSP</span>
            <span className="block text-sm font-medium">Support Portal</span>
          </span>
        </Link>
      </div>

      {!collapsed && user && (
        <div className="mx-4 mt-4 rounded-2xl border border-sidebar-border bg-sidebar-accent p-4 shadow-sm backdrop-blur">
          <p className="text-xs font-medium text-sidebar-foreground">Active Access</p>
          <Badge variant="secondary" className="mt-2 bg-secondary text-secondary-foreground">{user.roleName}</Badge>
          <p className="mt-2 text-xs text-sidebar-foreground">{user.branchName}</p>
        </div>
      )}

      <nav className="flex flex-1 flex-col gap-2 overflow-y-auto px-3 py-4">
        <SidebarNavLink item={{ label: 'Dashboard', path: '/', icon: Home }} collapsed={collapsed} onNavigate={onNavigate} />
        <Collapsible open={modulesOpen} onOpenChange={setModulesOpen}>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" className={cn('h-14 w-full justify-start gap-3 rounded-xl px-3 text-base font-semibold text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground [&_svg]:size-auto', collapsed && 'h-20 justify-center px-2')}>
              <Briefcase className={cn('shrink-0', collapsed ? '!h-10 !w-10' : '!h-7 !w-7')} />
              {!collapsed && <span className="flex-1 text-left leading-tight">Modules</span>}
              {!collapsed && (modulesOpen ? <ChevronDown className="!h-6 !w-6" /> : <ChevronRight className="!h-6 !w-6" />)}
            </Button>
          </CollapsibleTrigger>
          {!collapsed && (
            <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
              <div className="ml-5 mt-2 flex flex-col gap-1 border-l border-sidebar-border pl-3">
                {visibleModules.map((item: ChildNavItem) => <SidebarNavLink key={item.path} item={item} collapsed={false} onNavigate={onNavigate} />)}
              </div>
            </CollapsibleContent>
          )}
        </Collapsible>

        <Collapsible open={helpdeskOpen} onOpenChange={setHelpdeskOpen}>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" className={cn('h-14 w-full justify-start gap-3 rounded-xl px-3 text-base font-semibold text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground [&_svg]:size-auto', location.pathname.startsWith('/helpdesk') && 'bg-sidebar-primary text-sidebar-primary-foreground', collapsed && 'h-20 justify-center px-2')}>
              <Headset className={cn('shrink-0', collapsed ? '!h-10 !w-10' : '!h-7 !w-7')} />
              {!collapsed && <span className="flex-1 text-left leading-tight">OSD Helpdesk</span>}
              {!collapsed && <Badge variant="secondary" className="bg-secondary text-secondary-foreground text-sm">{openTicketCount}</Badge>}
              {!collapsed && (helpdeskOpen ? <ChevronDown className="!h-6 !w-6" /> : <ChevronRight className="!h-6 !w-6" />)}
            </Button>
          </CollapsibleTrigger>
          {!collapsed && (
            <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
              <div className="ml-5 mt-2 flex flex-col gap-1 border-l border-sidebar-border pl-3">
                {helpdeskItems.map((item: ChildNavItem) => (
                  <SidebarNavLink key={item.path} item={item} collapsed={false} onNavigate={onNavigate} />
                ))}
              </div>
            </CollapsibleContent>
          )}
        </Collapsible>
        {canAccessPath(user, '/reports') && <SidebarNavLink item={{ label: 'Reports', path: '/reports', icon: BarChart3 }} collapsed={collapsed} onNavigate={onNavigate} />}
        {canAccessPath(user, '/documents') && <SidebarNavLink item={{ label: 'Document Monitoring', path: '/documents', icon: FileCheck2 }} collapsed={collapsed} onNavigate={onNavigate} />}
        {canAccessPath(user, '/settings') && (
          <Collapsible open={settingsOpen} onOpenChange={setSettingsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className={cn('h-14 w-full justify-start gap-3 rounded-xl px-3 text-base font-semibold text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground [&_svg]:size-auto', location.pathname.startsWith('/settings') && 'bg-sidebar-primary text-sidebar-primary-foreground', collapsed && 'h-20 justify-center px-2')}>
                <LockKeyhole className={cn('shrink-0', collapsed ? '!h-10 !w-10' : '!h-7 !w-7')} />
                {!collapsed && <span className="flex-1 text-left leading-tight">Settings</span>}
                {!collapsed && (settingsOpen ? <ChevronDown className="!h-6 !w-6" /> : <ChevronRight className="!h-6 !w-6" />)}
              </Button>
            </CollapsibleTrigger>
            {!collapsed && (
              <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
                <div className="ml-5 mt-2 flex flex-col gap-1 border-l border-sidebar-border pl-3">
                  {settingsItems.map((item: ChildNavItem) => (
                    <SidebarNavLink key={item.path} item={item} collapsed={false} onNavigate={onNavigate} />
                  ))}
                </div>
              </CollapsibleContent>
            )}
          </Collapsible>
        )}
      </nav>
    </div>
  );
}

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { status, user } = useAuthSession();
  const pageTitle = useMemo(() => {
    if (location.pathname === '/' || location.pathname === '/dashboard') return 'Dashboard';
    if (location.pathname.startsWith('/modules')) return 'Modules';
    if (location.pathname.startsWith('/helpdesk')) return 'OSD Helpdesk';

    if (location.pathname.startsWith('/authentication')) return 'Authentication & Access';
    if (location.pathname.startsWith('/reports')) return 'Reports';
    if (location.pathname.startsWith('/documents')) return 'Document Monitoring';
    if (location.pathname === '/settings/system') return 'System Settings';
    if (location.pathname === '/settings/user-account-management') return 'User Account Management';
    if (location.pathname.startsWith('/settings')) return 'Settings Center';
    return 'BSP Support Portal';
  }, [location.pathname]);

  if (status === 'denied') {
    return <div className="min-h-screen bg-background text-foreground"><div className="p-6"><Outlet /></div></div>;
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <aside className={cn('fixed inset-y-0 left-0 z-30 hidden border-r border-sidebar-border bg-sidebar shadow-xl transition-all duration-300 ease-out lg:flex lg:flex-col', collapsed ? 'w-24' : 'w-80')}>
        <SidebarContent collapsed={collapsed} onCollapseToggle={() => setCollapsed((value: boolean) => !value)} />
      </aside>

      <div className={cn('transition-all duration-300 ease-out lg:pl-80', collapsed && 'lg:pl-24')}>
        <header className="sticky top-0 z-20 flex h-18 items-center justify-between border-b border-card-outline bg-card/90 px-4 text-card-foreground shadow-card backdrop-blur-xl lg:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 border-sidebar-border bg-sidebar p-0 text-sidebar-foreground">
                <SheetHeader className="sr-only">
                  <SheetTitle>BSP Navigation</SheetTitle>
                </SheetHeader>
                <SidebarContent collapsed={false} onNavigate={() => setOpen(false)} />
              </SheetContent>
            </Sheet>
            <div className="min-w-0">
              <h1 className="text-xl font-semibold tracking-tight">{pageTitle}</h1>
              <p className="truncate text-sm text-muted-foreground">Microsoft 365 Entra ID · Dataverse access control</p>
            </div>
          </div>
          <GlobalSearch />
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" aria-label="Notifications" className="rounded-full"><Bell className="h-4 w-4" /></Button>
            {user && <UserProfilePanel user={user} compact />}
          </div>
        </header>
        <main className="p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
