import { ShieldX } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

type AccessDeniedPageProps = {
  unregistered?: boolean;
};

export default function AccessDeniedPage({ unregistered = false }: AccessDeniedPageProps) {
  return (
    <div className="min-h-screen bg-background p-6 text-foreground">
      <div className="mx-auto flex min-h-[calc(100vh-3rem)] max-w-2xl items-center justify-center">
        <Card className="w-full border-destructive bg-card text-card-foreground shadow-xl">
          <CardHeader className="items-center text-center">
            <div className="mb-3 rounded-full bg-destructive p-4 text-destructive-foreground">
              <ShieldX className="h-10 w-10" />
            </div>
            <CardTitle className="text-2xl">You do not have access to Business Support Portal.</CardTitle>
            <CardDescription className="text-base">
              {unregistered
                ? 'Your account is not yet registered in Business Support Portal. Please contact the system administrator.'
                : 'Your account is inactive or missing required role and branch assignments.'}
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col justify-center gap-3 sm:flex-row">
            <Button onClick={() => window.location.assign('mailto:administrator@example.com')}>Contact Administrator</Button>
            <Button variant="outline" onClick={() => window.close()}>Exit</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
