import { ArrowDown, CheckCircle2, Database, KeyRound, Route, ShieldCheck } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { UserProfilePanel } from '@/components/user-profile-panel';
import { useAuthSession } from '@/hooks/use-auth-session';
import { rolePermissions } from '@/lib/auth-access';
import type { BspRole, PermissionItem } from '@/lib/auth-access';

const authSteps = [
  'User opens BSP',
  'Microsoft 365 authentication',
  'Retrieve email from Entra ID context',
  'Check Dataverse Users table',
  'Validate active account',
  'Create LoginAudit record',
  'Load role permissions',
  'Navigate Dashboard',
];

const schemaRows = [
  ['Users', 'UserID, Email, DisplayName, BranchID, RoleID, Status, IsActive, CreatedDate, LastLoginDate'],
  ['Branches', 'BranchID, BranchCode, BranchName, Region, Status'],
  ['Roles', 'RoleID, RoleName'],
  ['LoginAudit', 'LogID, UserEmail, UserName, BranchID, LoginDateTime, SessionID, Action'],
  ['Tickets', 'BranchID, Created By, Modified By, Modified Date'],
];

export default function AuthenticationPage() {
  const session = useAuthSession();
  const user = session.user;

  return (
    <div className="space-y-6">
      <section className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <span className="rounded-xl bg-primary p-3 text-primary-foreground"><ShieldCheck className="h-6 w-6" /></span>
              <div>
                <CardTitle>Microsoft 365 Authentication Flow</CardTitle>
                <CardDescription>No username/password screen. BSP trusts the current Entra ID session.</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2">
            {authSteps.map((step: string, index: number) => (
              <div key={step} className="flex items-center gap-3 rounded-xl border bg-card p-3 text-card-foreground">
                <Badge variant="secondary" className="bg-secondary text-secondary-foreground">{index + 1}</Badge>
                <span className="text-sm font-medium">{step}</span>
                {index < authSteps.length - 1 && <ArrowDown className="ml-auto h-4 w-4 text-muted-foreground" />}
              </div>
            ))}
          </CardContent>
        </Card>
        <div className="space-y-4">
          {user && <UserProfilePanel user={user} />}
          <Card>
            <CardHeader>
              <CardTitle>Session Status</CardTitle>
              <CardDescription>Detected Microsoft account and Dataverse access result.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between gap-3"><span className="text-muted-foreground">Status</span><Badge>{session.status}</Badge></div>
              <div className="flex justify-between gap-3"><span className="text-muted-foreground">Email</span><span className="font-medium">{user?.email ?? session.detectedEmail ?? 'Resolving'}</span></div>
              <div className="flex justify-between gap-3"><span className="text-muted-foreground">SessionID</span><span className="truncate font-medium">{user?.sessionId ?? 'Pending'}</span></div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Database className="h-5 w-5" />Dataverse Schema</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow><TableHead>Table</TableHead><TableHead>Fields</TableHead></TableRow></TableHeader>
              <TableBody>{schemaRows.map((row: string[]) => <TableRow key={row[0]}><TableCell className="font-medium">{row[0]}</TableCell><TableCell>{row[1]}</TableCell></TableRow>)}</TableBody>
            </Table>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" />Permission Model</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(rolePermissions).map(([role, permissions]: [string, PermissionItem[]]) => (
              <div key={role} className="rounded-xl border bg-card p-3 text-card-foreground">
                <p className="font-medium">{role as BspRole}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {permissions.map((permission: PermissionItem) => <Badge key={`${role}-${permission.label}`} variant="secondary" className="bg-secondary text-secondary-foreground">{permission.label}</Badge>)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 xl:grid-cols-3">
        <Card><CardHeader><CardTitle>Relationship Diagram</CardTitle></CardHeader><CardContent className="space-y-2 text-sm"><p>Users → Branches</p><p>Users → Roles</p><p>LoginAudit → Branches</p><p>Tickets → Branches</p><p>Tickets → Users</p></CardContent></Card>
        <Card><CardHeader><CardTitle>Branch Filtering</CardTitle></CardHeader><CardContent className="rounded-xl bg-secondary p-4 text-sm font-medium text-secondary-foreground">User.BranchID = Ticket.BranchID</CardContent></Card>
        <Card><CardHeader><CardTitle className="flex items-center gap-2"><Route className="h-5 w-5" />Role Redirect</CardTitle></CardHeader><CardContent className="text-sm text-muted-foreground">Authenticated users land on the dashboard with navigation reduced to their role permissions. Unauthorized module routes show Access Denied.</CardContent></Card>
      </section>

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><CheckCircle2 className="h-5 w-5" />Login Audit Logic</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-2 lg:grid-cols-5">
          {['Email', 'Name', 'Branch', 'Timestamp', 'SessionID'].map((field: string) => <div key={field} className="rounded-xl border bg-card p-3 text-sm font-medium text-card-foreground">{field}</div>)}
        </CardContent>
      </Card>
    </div>
  );
}
