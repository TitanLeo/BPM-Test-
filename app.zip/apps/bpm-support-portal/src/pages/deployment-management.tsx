import { Bell, CalendarDays, CheckCircle2, Clock, Eye, Truck, UserCheck } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';

 type DeploymentItem = { deploymentId: string; branch: string; deviceModel: string; assignedTechnician: string; scheduleDate: string; status: string; history: string };

const deploymentItems: DeploymentItem[] = [
  { deploymentId: 'DEP-2401', branch: 'SM San Lazaro', deviceModel: 'Verifone X990', assignedTechnician: 'R. Santos', scheduleDate: '2026-08-14', status: 'Pending', history: 'Awaiting device release' },
  { deploymentId: 'DEP-2402', branch: 'SM North EDSA', deviceModel: 'PAX A920', assignedTechnician: 'M. Cruz', scheduleDate: '2026-08-16', status: 'Completed', history: 'Installed and accepted' },
  { deploymentId: 'DEP-2403', branch: 'Head Office BPM', deviceModel: 'Ingenico Move 5000', assignedTechnician: 'J. Reyes', scheduleDate: '2026-08-19', status: 'Delayed', history: 'Pending vendor confirmation' },
  { deploymentId: 'DEP-2404', branch: 'SM San Lazaro', deviceModel: 'Verifone X990', assignedTechnician: 'A. Lim', scheduleDate: '2026-08-22', status: 'Upcoming', history: 'Scheduled for installation' },
];

const statusClass = (status: string): string => {
  if (status === 'Completed') return 'bg-primary text-primary-foreground';
  if (status === 'Delayed') return 'bg-destructive text-destructive-foreground';
  if (status === 'Pending') return 'bg-accent text-accent-foreground';
  return 'bg-secondary text-secondary-foreground';
};

export default function DeploymentManagementPage() {
  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-4 rounded-2xl border border-card-outline bg-card p-6 text-card-foreground shadow-card lg:flex-row lg:items-center lg:justify-between">
        <div className="space-y-3">
          <nav aria-label="Breadcrumb" className="text-sm font-medium text-muted-foreground">Access / BPM Support Portal</nav>
          <h2 className="text-3xl font-semibold tracking-tight">Deployment Management</h2>
          <p className="text-sm text-muted-foreground">Branch deployment tracking, installation schedules, technicians, and deployment history.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" aria-label="Notifications" className="rounded-full"><Bell className="h-4 w-4" /></Button>
          <Avatar className="h-10 w-10"><AvatarFallback className="bg-primary text-primary-foreground">BP</AvatarFallback></Avatar>
        </div>
      </header>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[{ title: 'Pending Deployments', value: '9', icon: Clock }, { title: 'Completed Deployments', value: '42', icon: CheckCircle2 }, { title: 'Delayed Deployments', value: '3', icon: Truck }, { title: 'Upcoming Installations', value: '12', icon: CalendarDays }].map((card: { title: string; value: string; icon: typeof Clock }) => {
          const Icon = card.icon;
          return <Card key={card.title} className="border-l-4 border-l-primary"><CardContent className="flex items-center gap-4 p-5"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Icon className="h-6 w-6" /></span><div><p className="text-sm text-muted-foreground">{card.title}</p><p className="text-2xl font-semibold">{card.value}</p></div></CardContent></Card>;
        })}
      </section>

      <Card>
        <CardHeader>
          <CardTitle>Branch Deployment Tracking</CardTitle>
          <CardDescription>Mock deployment workspace prepared for future Dataverse integration.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 lg:grid-cols-[1fr_180px_220px_200px]">
            <Input placeholder="Search deployments" />
            <Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Branch" /></SelectTrigger><SelectContent><SelectItem value="all">All Branches</SelectItem><SelectItem value="ssl">SM San Lazaro</SelectItem><SelectItem value="sne">SM North EDSA</SelectItem></SelectContent></Select>
            <Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Deployment Status" /></SelectTrigger><SelectContent><SelectItem value="all">All Statuses</SelectItem><SelectItem value="pending">Pending</SelectItem><SelectItem value="completed">Completed</SelectItem><SelectItem value="delayed">Delayed</SelectItem></SelectContent></Select>
            <Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Technician" /></SelectTrigger><SelectContent><SelectItem value="all">All Technicians</SelectItem><SelectItem value="santos">R. Santos</SelectItem><SelectItem value="cruz">M. Cruz</SelectItem></SelectContent></Select>
          </div>
          <div className="overflow-hidden rounded-2xl border border-card-outline">
            <Table>
              <TableHeader className="bg-secondary text-secondary-foreground"><TableRow className="hover:bg-secondary"><TableHead>Deployment ID</TableHead><TableHead>Branch</TableHead><TableHead>Device Model</TableHead><TableHead>Assigned Technician</TableHead><TableHead>Schedule Date</TableHead><TableHead>Status</TableHead><TableHead>Deployment History</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
              <TableBody>{deploymentItems.map((item: DeploymentItem) => <TableRow key={item.deploymentId}><TableCell className="font-medium">{item.deploymentId}</TableCell><TableCell>{item.branch}</TableCell><TableCell>{item.deviceModel}</TableCell><TableCell><span className="inline-flex items-center gap-2"><UserCheck className="h-4 w-4" />{item.assignedTechnician}</span></TableCell><TableCell>{item.scheduleDate}</TableCell><TableCell><Badge variant="secondary" className={statusClass(item.status)}>{item.status}</Badge></TableCell><TableCell>{item.history}</TableCell><TableCell><Button variant="ghost" size="sm" onClick={() => toast.info(`Viewing deployment ${item.deploymentId}`)}><Eye className="h-4 w-4" />View</Button></TableCell></TableRow>)}</TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
