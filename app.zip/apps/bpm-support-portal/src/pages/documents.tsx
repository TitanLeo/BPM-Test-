import { useMemo, useState } from 'react';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis, YAxis } from 'recharts';
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  CalendarClock,
  CheckCircle2,
  Bot,
  Clock3,
  FileArchive,
  FileCheck2,
  FilePlus2,
  FileText,
  Image,
  SendHorizontal,
  Search,
  ShieldCheck,
  UploadCloud,
  XCircle,
} from 'lucide-react';
import { toast } from 'sonner';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuthSession } from '@/hooks/use-auth-session';
import type { BspRole } from '@/lib/auth-access';

const statuses = ['Received', 'Under Review', 'Pending Approval', 'Approved', 'Released', 'Archived', 'Rejected'];
const categories = ['Memorandum', 'Project Documents', 'Asset Documents', 'Contracts', 'Vendor Documents', 'Policies', 'Reports', 'Others'];

const documentRecords = [
  { number: 'DOC-2026-081', title: 'POS Terminal Replacement Memo', category: 'Memorandum', receivedDate: 'Aug 01, 2026', origin: 'SM San Lazaro', destination: 'BPM Support', owner: 'Juan Dela Cruz', status: 'Pending Approval', priority: 'High', dueDate: 'Aug 06, 2026', branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39' },
  { number: 'DOC-2026-082', title: 'CCTV Storage Expansion Contract', category: 'Contracts', receivedDate: 'Aug 02, 2026', origin: 'Vendor Desk', destination: 'Security Ops', owner: 'Maria Santos', status: 'Under Review', priority: 'Critical', dueDate: 'Aug 05, 2026', branchId: '6cbb6f84-34ef-403a-b795-8c042c522fc6' },
  { number: 'DOC-2026-083', title: 'Asset Turnover Checklist', category: 'Asset Documents', receivedDate: 'Aug 03, 2026', origin: 'Hardware Team', destination: 'Branch Supervisor', owner: 'San Lazaro Supervisor', status: 'Approved', priority: 'Normal', dueDate: 'Aug 08, 2026', branchId: '8868657b-6d33-41d9-a5f2-d77131fbee39' },
  { number: 'DOC-2026-084', title: 'M365 Retention Policy Update', category: 'Policies', receivedDate: 'Aug 04, 2026', origin: 'Head Office BPM', destination: 'All Branches', owner: 'Compliance Office', status: 'Released', priority: 'Normal', dueDate: 'Aug 10, 2026', branchId: '6cbb6f84-34ef-403a-b795-8c042c522fc6' },
  { number: 'DOC-2026-085', title: 'Project Budget Exception Report', category: 'Reports', receivedDate: 'Aug 04, 2026', origin: 'Projects PMO', destination: 'Manager', owner: 'PMO Analyst', status: 'Rejected', priority: 'High', dueDate: 'Aug 04, 2026', branchId: '0bac6915-31a5-4108-933c-b9c93aab3733' },
];

type DocumentRow = (typeof documentRecords)[number];
type FilterState = { query: string; origin: string; status: string; date: string };
type StatisticCard = { label: string; value: string; icon: typeof FileText };

const chartConfig = {
  documents: { label: 'Documents', color: 'var(--chart-1)' },
  incoming: { label: 'Incoming', color: 'var(--chart-1)' },
  outgoing: { label: 'Outgoing', color: 'var(--chart-2)' },
  workload: { label: 'Workload', color: 'var(--chart-3)' },
} satisfies ChartConfig;

const monthlyVolumeData = [
  { month: 'Mar', incoming: 92, outgoing: 64 },
  { month: 'Apr', incoming: 104, outgoing: 78 },
  { month: 'May', incoming: 118, outgoing: 91 },
  { month: 'Jun', incoming: 126, outgoing: 97 },
  { month: 'Jul', incoming: 141, outgoing: 112 },
  { month: 'Aug', incoming: 76, outgoing: 54 },
];

const statusChartData = statuses.map((status: string, index: number) => ({
  status,
  value: documentRecords.filter((record: DocumentRow) => record.status === status).length + (index % 3),
  fill: `var(--chart-${(index % 5) + 1})`,
}));

const overdueData = [
  { department: 'BPM Support', overdue: 8 },
  { department: 'Security Ops', overdue: 5 },
  { department: 'Hardware Team', overdue: 3 },
  { department: 'PMO', overdue: 6 },
];

const workloadData = [
  { department: 'BPM Support', workload: 42 },
  { department: 'Security Ops', workload: 31 },
  { department: 'Branch Ops', workload: 28 },
  { department: 'PMO', workload: 22 },
];

function getDocumentAccess(role: BspRole | undefined): string {
  if (role === 'Branch User') return 'Branch document view: documents are filtered by User.BranchID.';
  if (role === 'Manager') return 'Approval access enabled for pending documents.';
  if (role === 'Administrator') return 'Full document monitoring access enabled.';
  return 'Document visibility follows BSP role permissions.';
}

function getStatusVariant(status: string): 'default' | 'secondary' | 'destructive' | 'outline' {
  if (status === 'Rejected') return 'destructive';
  if (status === 'Approved' || status === 'Released') return 'default';
  if (status === 'Archived') return 'outline';
  return 'secondary';
}

function UploadComponent() {
  const fileTypes = [
    { label: 'PDF', icon: FileText },
    { label: 'Word', icon: FileText },
    { label: 'Excel', icon: FileCheck2 },
    { label: 'Images', icon: Image },
  ];

  return (
    <Card className="bg-card text-card-foreground shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg">Upload Files</CardTitle>
        <CardDescription>Attach PDF, Word, Excel, and image files to the document record.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-2xl border border-dashed bg-background p-6 text-center text-foreground">
          <UploadCloud className="mx-auto h-9 w-9" />
          <p className="mt-3 font-medium">Drop documents here or select files</p>
          <p className="mt-1 text-sm text-muted-foreground">Files are stored against the active document workflow.</p>
          <Button className="mt-4" onClick={() => toast.info('File picker ready for document upload')}>Select files</Button>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {fileTypes.map(({ label, icon: Icon }: { label: string; icon: typeof FileText }) => (
            <div key={label} className="rounded-xl border bg-background p-3 text-center text-sm font-medium text-foreground">
              <Icon className="mx-auto mb-2 h-4 w-4" />
              {label}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function TimelineTracking() {
  const steps = [
    { label: 'Received', icon: ArrowDownToLine },
    { label: 'Reviewed', icon: FileText },
    { label: 'Approved', icon: ShieldCheck },
    { label: 'Released', icon: ArrowUpFromLine },
  ];

  return (
    <Card className="bg-card text-card-foreground shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg">Document Timeline</CardTitle>
        <CardDescription>Movement tracking from receipt through release.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-3 md:grid-cols-4">
          {steps.map(({ label, icon: Icon }: { label: string; icon: typeof FileText }, index: number) => (
            <div key={label} className="relative rounded-2xl border bg-background p-4 text-foreground">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground"><Icon className="h-5 w-5" /></span>
              <p className="mt-3 font-medium">{label}</p>
              <p className="text-sm text-muted-foreground">Step {index + 1}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

type CopilotResponse = { answer: string; details: string[]; related: string[] };

const defaultCopilotResponse: CopilotResponse = {
  answer: 'I could not find an approved BSP knowledge article related to this request.',
  details: [
    'BSP Copilot answers must be based on approved BSP knowledge sources such as SOPs, BPM policies, technical documentation, troubleshooting guides, user manuals, FAQs, and knowledge base articles.',
    'Try searching by issue category, system name, branch, device type, or document title.',
  ],
  related: ['BSP Knowledge Base Articles', 'Helpdesk Ticket Procedure', 'BPM Support SOP'],
};

const copilotKnowledge: Array<{ keywords: string[]; response: CopilotResponse }> = [
  { keywords: ['cctv', 'camera', 'recording', 'dvr', 'nvr'], response: { answer: 'For CCTV issues, follow the approved troubleshooting flow before creating a ticket.', details: ['1. Confirm whether the issue affects one camera or multiple cameras.', '2. Check camera power, network cable, DVR/NVR status, and monitor display.', '3. Capture the branch name, affected camera, error message, and date/time observed.', '4. If the issue continues, create a Helpdesk Ticket under CCTV.'], related: ['CCTV Troubleshooting Guide', 'Ticket Escalation Procedure', 'Asset Repair History'] } },
  { keywords: ['pos', 'terminal', 'tid', 'cashier', 'available working pos'], response: { answer: 'For POS issues, record the terminal details and date encountered, then submit a POS ticket if basic checks do not resolve the issue.', details: ['1. Verify power, network connection, and terminal availability.', '2. Record Branch, TID, Issue, Date Reported, Date Encountered, Status, and Available Working POS.', '3. Check whether another POS is available for branch operation continuity.', '4. If unresolved, create a Helpdesk Ticket under POS for technician action.'], related: ['POS Troubleshooting Guide', 'POS-DATA Ticket Procedure', 'Branch Operations Support SOP'] } },
  { keywords: ['network', 'internet', 'connection', 'wifi', 'lan', 'switch'], response: { answer: 'For network or internet issues, complete basic connectivity checks before escalation.', details: ['1. Verify cable connections and device network status.', '2. Restart the affected workstation or network device when safe to do so.', '3. Test another workstation to confirm whether the issue is isolated or branch-wide.', '4. If the issue persists, create a Helpdesk Ticket under Network or Internet.'], related: ['Network Troubleshooting Guide', 'Internet Support Procedure', 'IT Support Escalation SOP'] } },
  { keywords: ['asset', 'warranty', 'repair', 'replacement', 'assigned'], response: { answer: 'Asset questions should be checked against assignment, warranty, replacement, and repair history records.', details: ['1. Search the asset tag, serial number, branch, or assigned user.', '2. Review assignment status, warranty coverage, and repair history.', '3. For replacement or repair requests, attach supporting photos or diagnosis notes.', '4. Create a Helpdesk Ticket if technician verification is required.'], related: ['Asset Management Documentation', 'Asset Assignment Procedure', 'Warranty and Replacement Guide'] } },
  { keywords: ['project', 'milestone', 'timeline', 'owner', 'status'], response: { answer: 'Project requests should be reviewed through approved project documentation, owners, milestones, and timelines.', details: ['1. Search the project name or owner.', '2. Review status, milestones, current timeline, and linked documentation.', '3. Check open dependencies or pending approvals before requesting updates.'], related: ['Project Documentation', 'Project Timeline Register', 'PMO Status Report'] } },
];

function getCopilotResponse(query: string): CopilotResponse {
  const normalizedQuery = query.toLowerCase();
  const match = copilotKnowledge.find((entry: { keywords: string[]; response: CopilotResponse }) =>
    entry.keywords.some((keyword: string) => normalizedQuery.includes(keyword)),
  );
  return match?.response ?? defaultCopilotResponse;
}

function BspCopilotPanel() {
  const [query, setQuery] = useState('How do I report a POS issue?');
  const [response, setResponse] = useState<CopilotResponse>(getCopilotResponse('pos'));

  const submitQuery = () => {
    setResponse(getCopilotResponse(query));
    toast.info('BSP Copilot searched approved knowledge sources');
  };

  return (
    <Card className="bg-card text-card-foreground shadow-sm">
      <CardHeader>
        <div className="flex items-start gap-3">
          <span className="rounded-2xl bg-primary p-3 text-primary-foreground"><Bot className="h-5 w-5" /></span>
          <div>
            <CardTitle>BSP Copilot</CardTitle>
            <CardDescription>Official AI Knowledge Assistant for BSP approved knowledge sources.</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 lg:grid-cols-[1fr_auto]">
          <Textarea value={query} onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => setQuery(event.target.value)} placeholder="Ask about SOPs, troubleshooting, helpdesk procedures, assets, or projects" className="min-h-24" />
          <Button onClick={submitQuery} className="self-end"><SendHorizontal className="h-4 w-4" />Ask</Button>
        </div>
        <div className="rounded-2xl border bg-background p-4 text-foreground">
          <h3 className="font-semibold">## Answer</h3>
          <p className="mt-2 text-sm">{response.answer}</p>
          <h3 className="mt-4 font-semibold">## Details</h3>
          <div className="mt-2 space-y-2 text-sm">{response.details.map((detail: string) => <p key={detail}>{detail}</p>)}</div>
          <h3 className="mt-4 font-semibold">## Related Knowledge</h3>
          <ul className="mt-2 space-y-1 text-sm">{response.related.map((article: string) => <li key={article}>• {article}</li>)}</ul>
          <h3 className="mt-4 font-semibold">## Need More Help?</h3>
          <ul className="mt-2 space-y-1 text-sm"><li>• Create a Helpdesk Ticket</li><li>• Search another article</li><li>• Contact BPM Support</li></ul>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DocumentsPage() {
  const { user } = useAuthSession();
  const [filters, setFilters] = useState<FilterState>({ query: '', origin: 'all', status: 'all', date: 'all' });


  const accessMessage = getDocumentAccess(user?.roleName);
  const visibleRecords = useMemo<DocumentRow[]>(() => {
    const branchScoped = user?.roleName === 'Branch User' ? documentRecords.filter((record: DocumentRow) => record.branchId === user.branchId) : documentRecords;
    return branchScoped.filter((record: DocumentRow) => {
      const searchTarget = `${record.number} ${record.title}`.toLowerCase();
      const matchesQuery = filters.query.length === 0 || searchTarget.includes(filters.query.toLowerCase());
      const matchesOrigin = filters.origin === 'all' || record.origin === filters.origin;
      const matchesStatus = filters.status === 'all' || record.status === filters.status;
      return matchesQuery && matchesOrigin && matchesStatus;
    });
  }, [filters.origin, filters.query, filters.status, user?.branchId, user?.roleName]);

  const statistics: StatisticCard[] = [
    { label: 'Incoming Documents', value: '148', icon: ArrowDownToLine },
    { label: 'Outgoing Documents', value: '92', icon: ArrowUpFromLine },
    { label: 'Pending Approval', value: '24', icon: Clock3 },
    { label: 'Approved Documents', value: '318', icon: CheckCircle2 },
    { label: 'Rejected Documents', value: '7', icon: XCircle },
  ];

  const origins = [...new Set(documentRecords.map((record: DocumentRow) => record.origin))];

  return (
    <div className="space-y-4 sm:space-y-6">
      <section className="rounded-2xl border bg-card p-4 text-card-foreground shadow-sm sm:rounded-3xl sm:p-5 lg:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary" className="text-xs">Microsoft Fluent document tracker</Badge>
              <Badge variant="outline" className="text-xs">{user?.roleName ?? 'Role scoped'}</Badge>
            </div>
            <h2 className="mt-3 text-xl font-semibold tracking-tight sm:mt-4 sm:text-2xl">Document Monitoring</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">Monitor incoming and outgoing documents and track approval workflows.</p>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-muted-foreground">{accessMessage}</p>
          </div>
          <div className="grid gap-2 sm:flex sm:flex-wrap">
            <Button className="min-h-11 justify-center" onClick={() => toast.success('Create document record workflow opened')}><FilePlus2 className="h-4 w-4" />Create Document Record</Button>
            <Button className="min-h-11 justify-center" variant="outline" onClick={() => toast.info('Document movement tracking view opened')}><CalendarClock className="h-4 w-4" />Track Movement</Button>
          </div>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 sm:gap-4 xl:grid-cols-5">
        {statistics.map(({ label, value, icon: Icon }: StatisticCard) => (
          <Card key={label} className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 p-4 pb-2 sm:p-6 sm:pb-2">
              <CardTitle className="text-sm font-medium leading-5">{label}</CardTitle>
              <span className="rounded-xl bg-primary p-2 text-primary-foreground"><Icon className="h-4 w-4" /></span>
            </CardHeader>
            <CardContent className="p-4 pt-0 sm:p-6 sm:pt-0">
              <div className="text-2xl font-semibold tracking-tight">{value}</div>
              <p className="mt-1 text-xs leading-5 text-muted-foreground">Current monitoring cycle</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <Card className="bg-card text-card-foreground shadow-sm">
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="text-lg">Search and Filters</CardTitle>
          <CardDescription className="leading-6">Filter by document number, title, origin, status, and date scope.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 p-4 pt-0 sm:p-6 sm:pt-0 md:grid-cols-2 xl:grid-cols-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4" />
            <Input className="min-h-11 pl-9 text-base sm:text-sm" placeholder="Document number or title" value={filters.query} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setFilters((current: FilterState) => ({ ...current, query: event.target.value }))} />
          </div>
          <Select value={filters.origin} onValueChange={(value: string) => setFilters((current: FilterState) => ({ ...current, origin: value }))}>
            <SelectTrigger className="min-h-11"><SelectValue placeholder="Origin" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All origins</SelectItem>
              {origins.filter((origin: string) => origin.length > 0).map((origin: string) => <SelectItem key={origin} value={origin}>{origin}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filters.status} onValueChange={(value: string) => setFilters((current: FilterState) => ({ ...current, status: value }))}>
            <SelectTrigger className="min-h-11"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {statuses.filter((status: string) => status.length > 0).map((status: string) => <SelectItem key={status} value={status}>{status}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filters.date} onValueChange={(value: string) => setFilters((current: FilterState) => ({ ...current, date: value }))}>
            <SelectTrigger className="min-h-11"><SelectValue placeholder="Date" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All dates</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This week</SelectItem>
              <SelectItem value="month">This month</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Tabs defaultValue="registry" className="space-y-4">
        <TabsList className="grid h-auto w-full grid-cols-2 gap-1 p-1 sm:grid-cols-3 lg:w-fit lg:grid-cols-5">
          <TabsTrigger className="min-h-10 text-xs sm:text-sm" value="registry">Registry</TabsTrigger>
          <TabsTrigger className="min-h-10 text-xs sm:text-sm" value="copilot">BSP Copilot</TabsTrigger>
          <TabsTrigger className="min-h-10 text-xs sm:text-sm" value="workflow">Workflow</TabsTrigger>
          <TabsTrigger className="min-h-10 text-xs sm:text-sm" value="charts">Charts</TabsTrigger>
          <TabsTrigger className="min-h-10 text-xs sm:text-sm" value="upload">Upload</TabsTrigger>
        </TabsList>

        <TabsContent value="registry">
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle>Document Registry</CardTitle>
              <CardDescription className="leading-6">Incoming and outgoing document records with ownership, status, and due dates.</CardDescription>
            </CardHeader>
            <CardContent className="p-4 pt-0 sm:p-6 sm:pt-0">
              <div className="space-y-3 lg:hidden">
                {visibleRecords.map((record: DocumentRow) => (
                  <article key={record.number} className="rounded-2xl border bg-background p-4 text-foreground shadow-sm">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold leading-5">{record.number}</p>
                        <h3 className="mt-1 text-base font-semibold leading-6">{record.title}</h3>
                      </div>
                      <Badge variant={getStatusVariant(record.status)} className="shrink-0 whitespace-nowrap">{record.status}</Badge>
                    </div>
                    <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                      <div><p className="font-medium">Category</p><p className="mt-1 text-muted-foreground">{record.category}</p></div>
                      <div><p className="font-medium">Owner</p><p className="mt-1 text-muted-foreground">{record.owner}</p></div>
                      <div><p className="font-medium">Origin</p><p className="mt-1 text-muted-foreground">{record.origin}</p></div>
                      <div><p className="font-medium">Destination</p><p className="mt-1 text-muted-foreground">{record.destination}</p></div>
                      <div><p className="font-medium">Received</p><p className="mt-1 text-muted-foreground">{record.receivedDate}</p></div>
                      <div><p className="font-medium">Due</p><p className="mt-1 text-muted-foreground">{record.dueDate}</p></div>
                    </div>
                  </article>
                ))}
              </div>
              <div className="hidden overflow-x-auto lg:block">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Document Number</TableHead>
                      <TableHead>Document Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Received Date</TableHead>
                      <TableHead>Origin</TableHead>
                      <TableHead>Destination</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Due Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {visibleRecords.map((record: DocumentRow) => (
                      <TableRow key={record.number}>
                        <TableCell className="font-medium">{record.number}</TableCell>
                        <TableCell>{record.title}</TableCell>
                        <TableCell>{record.category}</TableCell>
                        <TableCell>{record.receivedDate}</TableCell>
                        <TableCell>{record.origin}</TableCell>
                        <TableCell>{record.destination}</TableCell>
                        <TableCell>{record.owner}</TableCell>
                        <TableCell><Badge variant={getStatusVariant(record.status)}>{record.status}</Badge></TableCell>
                        <TableCell>{record.priority}</TableCell>
                        <TableCell>{record.dueDate}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="copilot">
          <BspCopilotPanel />
        </TabsContent>

        <TabsContent value="workflow">
          <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <TimelineTracking />
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Approval Workflow UI</CardTitle>
                <CardDescription>Manager approval path for pending document records.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {categories.slice(0, 5).map((category: string) => (
                  <div key={category} className="flex items-center justify-between rounded-xl border bg-background p-3 text-foreground">
                    <span className="text-sm font-medium">{category}</span>
                    <Badge variant="secondary">Configured</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="charts">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Documents by Status</CardTitle><CardDescription>Status distribution across monitored records.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <PieChart accessibilityLayer>
                    <ChartTooltip content={<ChartTooltipContent nameKey="status" />} />
                    <Pie data={statusChartData} dataKey="value" nameKey="status" innerRadius={58} outerRadius={105}>
                      {statusChartData.map((entry: { status: string; value: number; fill: string }) => <Cell key={entry.status} fill={entry.fill} />)}
                    </Pie>
                  </PieChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Monthly Volume</CardTitle><CardDescription>Incoming and outgoing document trend.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <AreaChart accessibilityLayer data={monthlyVolumeData}>
                    <CartesianGrid vertical={false} />
                    <XAxis dataKey="month" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area dataKey="incoming" type="monotone" fill="var(--chart-1)" stroke="var(--chart-1)" />
                    <Area dataKey="outgoing" type="monotone" fill="var(--chart-2)" stroke="var(--chart-2)" />
                  </AreaChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Overdue Documents</CardTitle><CardDescription>Overdue document count by department.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <BarChart accessibilityLayer data={overdueData}>
                    <CartesianGrid vertical={false} />
                    <XAxis dataKey="department" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="overdue" fill="var(--chart-5)" radius={4} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Department Workload</CardTitle><CardDescription>Current document handling volume by department.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <BarChart accessibilityLayer data={workloadData}>
                    <CartesianGrid vertical={false} />
                    <XAxis dataKey="department" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="workload" fill="var(--chart-3)" radius={4} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="upload">
          <UploadComponent />
        </TabsContent>
      </Tabs>
    </div>
  );
}
