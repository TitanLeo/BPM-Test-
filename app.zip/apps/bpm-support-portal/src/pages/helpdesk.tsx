import { useEffect, useMemo, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  ChevronsUpDown,
  CircleHelp,
  Clock3,
  FileText,
  Headphones,
  ListChecks,
  MessageSquare,
  Paperclip,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  UserRound,
  UsersRound,
} from 'lucide-react';
import { toast } from 'sonner';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { TicketDetailDrawer } from '@/components/ticket-detail-drawer';
import { useUser } from '@/hooks/use-user';
import { modules, type ModuleInfo, type Priority, type Status } from '@/lib/mock-data';

type Screen = 'dashboard' | 'create' | 'list' | 'details' | 'help' | 'settings';
type QueueTab = 'All' | 'My Queue' | 'Unassigned' | 'At Risk' | 'Escalated' | 'Resolved' | 'Closed';
type TicketStatus = 'New' | 'Assigned' | 'In Progress' | 'Waiting User' | 'Waiting Vendor' | 'Resolved' | 'Closed';
type TicketPriority = 'Low' | 'Medium' | 'High' | 'Critical';
type SortKey = 'ticketId' | 'branch' | 'requestor' | 'category' | 'priority' | 'status' | 'assignedTo' | 'dateCreated' | 'slaStatus';
type SortDirection = 'asc' | 'desc';
type SlaStatus = 'On Track' | 'At Risk' | 'Breached' | 'Met';
type Ticket = {
  ticketId: string;
  title: string;
  branch: string;
  requestor: string;
  contact: string;
  category: string;
  description: string;
  priority: TicketPriority;
  status: TicketStatus;
  assignedTo: string;
  dateCreated: string;
  slaTarget: string;
  slaRemaining: string;
  slaStatus: SlaStatus;
  resolution: string;
  attachments: string;
  escalated: boolean;
  atRisk: boolean;
};

type ActionCard = {
  title: string;
  description: string;
  button: string;
  icon: typeof Plus;
  screen: Screen;
};

type QuickAction = {
  label: string;
  screen: Screen;
  icon: typeof Plus;
};

type Activity = {
  type: string;
  ticketId: string;
  detail: string;
  time: string;
};

type RoleCapability = {
  role: string;
  actions: string[];
};

type KpiTone = 'open' | 'waiting' | 'resolved' | 'priority';
type KpiCard = {
  label: string;
  value: number;
  detail: string;
  trend: string;
  tone: KpiTone;
  icon: typeof Clock3;
};

const tickets: Ticket[] = [
  { ticketId: 'OSD-1001', title: 'POS terminal cannot connect', branch: 'SM San Lazaro', requestor: 'Rhea Santos', contact: 'rhea.santos@example.com', category: 'POS', description: 'Cashier lane 4 POS is unable to reach the payment gateway.', priority: 'Critical', status: 'New', assignedTo: 'Unassigned', dateCreated: 'Aug 06, 2026 08:12 AM', slaTarget: 'Aug 06, 2026 12:12 PM', slaRemaining: '1h 20m', slaStatus: 'At Risk', resolution: 'Awaiting network validation.', attachments: 'pos-error.png', escalated: true, atRisk: true },
  { ticketId: 'OSD-1002', title: 'New AD account request', branch: 'SM North EDSA', requestor: 'Marco Lim', contact: 'marco.lim@example.com', category: 'Microsoft 365', description: 'Create branch operations account for new supervisor.', priority: 'Medium', status: 'Waiting User', assignedTo: 'Bianca Cruz', dateCreated: 'Aug 05, 2026 03:45 PM', slaTarget: 'Aug 07, 2026 03:45 PM', slaRemaining: '12h 10m', slaStatus: 'On Track', resolution: 'Waiting for manager approval.', attachments: 'request-form.pdf', escalated: false, atRisk: false },
  { ticketId: 'OSD-1003', title: 'CCTV playback unavailable', branch: 'SM Megamall', requestor: 'Nina Uy', contact: 'nina.uy@example.com', category: 'CCTV', description: 'Security team cannot play back footage from camera group B.', priority: 'High', status: 'In Progress', assignedTo: 'Carlo Lim', dateCreated: 'Aug 04, 2026 11:18 AM', slaTarget: 'Aug 05, 2026 11:18 AM', slaRemaining: 'Breached', slaStatus: 'Breached', resolution: 'Storage service restart scheduled.', attachments: 'camera-list.xlsx', escalated: true, atRisk: true },
  { ticketId: 'OSD-1004', title: 'Laptop blue screen issue', branch: 'Head Office BPM', requestor: 'Lara Dizon', contact: 'lara.dizon@example.com', category: 'Hardware', description: 'Operations laptop crashes during Teams calls.', priority: 'Low', status: 'Resolved', assignedTo: 'Dina Ramos', dateCreated: 'Aug 03, 2026 01:30 PM', slaTarget: 'Aug 06, 2026 01:30 PM', slaRemaining: 'Met', slaStatus: 'Met', resolution: 'Updated drivers and confirmed stable operation.', attachments: 'diagnostics.txt', escalated: false, atRisk: false },
  { ticketId: 'OSD-1005', title: 'Printer queue stuck', branch: 'SM Cebu', requestor: 'Paolo Reyes', contact: 'paolo.reyes@example.com', category: 'Hardware', description: 'Branch printer queue has pending jobs for multiple users.', priority: 'Medium', status: 'Closed', assignedTo: 'Allan Reyes', dateCreated: 'Aug 02, 2026 09:05 AM', slaTarget: 'Aug 04, 2026 09:05 AM', slaRemaining: 'Met', slaStatus: 'Met', resolution: 'Cleared queue and reinstalled print driver.', attachments: 'none', escalated: false, atRisk: false },
  { ticketId: 'OSD-1006', title: 'Branch internet intermittent', branch: 'SM Iloilo', requestor: 'Grace Tan', contact: 'grace.tan@example.com', category: 'Internet', description: 'Users report intermittent browsing and Teams call drops.', priority: 'High', status: 'Assigned', assignedTo: 'Allan Reyes', dateCreated: 'Aug 06, 2026 10:40 AM', slaTarget: 'Aug 07, 2026 10:40 AM', slaRemaining: '5h 35m', slaStatus: 'On Track', resolution: 'ISP ticket validation in progress.', attachments: 'speed-test.png', escalated: false, atRisk: false },
  { ticketId: 'OSD-1007', title: 'Vendor software patch needed', branch: 'SM Aura', requestor: 'Mina Cruz', contact: 'mina.cruz@example.com', category: 'Software', description: 'Inventory client requires vendor patch before month-end audit.', priority: 'Medium', status: 'Waiting Vendor', assignedTo: 'Carlo Lim', dateCreated: 'Aug 01, 2026 04:20 PM', slaTarget: 'Aug 05, 2026 04:20 PM', slaRemaining: 'Breached', slaStatus: 'Breached', resolution: 'Vendor response requested.', attachments: 'vendor-case.txt', escalated: true, atRisk: true },
];

const categories = ['CCTV', 'POS', 'Network', 'Internet', 'Email', 'Microsoft 365', 'Hardware', 'Software', ...modules.map((module: ModuleInfo) => module.name)];
const priorities: TicketPriority[] = ['Low', 'Medium', 'High', 'Critical'];
const statuses: TicketStatus[] = ['New', 'Assigned', 'In Progress', 'Waiting User', 'Waiting Vendor', 'Resolved', 'Closed'];
const branches = ['SM San Lazaro', 'SM North EDSA', 'SM Megamall', 'Head Office BPM', 'SM Cebu', 'SM Iloilo', 'SM Aura'];
const technicians = ['Allan Reyes', 'Bianca Cruz', 'Carlo Lim', 'Dina Ramos', 'Unassigned'];
const queueTabs: { label: QueueTab; count: number }[] = [
  { label: 'All', count: 152 },
  { label: 'My Queue', count: 18 },
  { label: 'Unassigned', count: 7 },
  { label: 'At Risk', count: 11 },
  { label: 'Escalated', count: 9 },
  { label: 'Resolved', count: 64 },
  { label: 'Closed', count: 38 },
];

function toOperationalRecord(ticket: Ticket) {
  const statusMap: Record<TicketStatus, Status> = {
    New: 'Open',
    Assigned: 'Open',
    'In Progress': 'In Progress',
    'Waiting User': 'Needs Attention',
    'Waiting Vendor': 'Needs Attention',
    Resolved: 'Resolved',
    Closed: 'Closed',
  };
  const priorityMap: Record<TicketPriority, Priority> = {
    Low: 'Low',
    Medium: 'Normal',
    High: 'High',
    Critical: 'Critical',
  };

  return {
    ticketNo: ticket.ticketId,
    module: ticket.category,
    requestor: ticket.requestor,
    assignedTo: ticket.assignedTo,
    status: statusMap[ticket.status],
    priority: priorityMap[ticket.priority],
    dueDate: ticket.slaTarget,
    progress: ticket.status === 'Closed' || ticket.status === 'Resolved' ? 100 : ticket.status === 'In Progress' ? 64 : 22,
    branchId: ticket.branch,
    createdBy: ticket.requestor,
    modifiedBy: ticket.assignedTo,
    modifiedDate: ticket.dateCreated,
    title: ticket.title,
    branch: ticket.branch,
    category: ticket.category,
    description: ticket.description,
    resolution: ticket.resolution,
    attachments: ticket.attachments,
    ticketId: ticket.ticketId,
    dateCreated: ticket.dateCreated,
  };
}

function statusBadgeClass(status: TicketStatus): string {
  if (status === 'New') return 'bg-primary text-primary-foreground border-transparent shadow-sm ring-1 ring-primary';
  if (status === 'Assigned') return 'bg-secondary text-secondary-foreground border-transparent shadow-sm ring-1 ring-secondary';
  if (status === 'In Progress') return 'bg-primary text-primary-foreground border-transparent shadow-sm ring-1 ring-primary';
  if (status === 'Waiting User' || status === 'Waiting Vendor') return 'bg-accent text-accent-foreground border-transparent shadow-sm ring-1 ring-accent';
  if (status === 'Resolved') return 'bg-success text-success-foreground border-transparent shadow-sm ring-1 ring-success';
  return 'bg-sidebar text-sidebar-foreground border-transparent shadow-sm ring-1 ring-sidebar';
}

function priorityBadgeClass(priority: TicketPriority): string {
  if (priority === 'Critical') return 'bg-destructive text-destructive-foreground border-transparent shadow-sm ring-1 ring-destructive';
  if (priority === 'High') return 'bg-accent text-accent-foreground border-transparent shadow-sm ring-1 ring-accent';
  if (priority === 'Medium') return 'bg-primary text-primary-foreground border-transparent shadow-sm ring-1 ring-primary';
  return 'bg-secondary text-secondary-foreground border-transparent shadow-sm ring-1 ring-secondary';
}

function slaBadgeClass(slaStatus: SlaStatus): string {
  if (slaStatus === 'Breached') return 'bg-destructive text-destructive-foreground border-transparent shadow-sm';
  if (slaStatus === 'At Risk') return 'bg-accent text-accent-foreground border-transparent shadow-sm';
  if (slaStatus === 'Met') return 'bg-success text-success-foreground border-transparent shadow-sm';
  return 'bg-secondary text-secondary-foreground border-transparent shadow-sm';
}

export default function HelpdeskPage() {
  const { data: user } = useUser();
  const location = useLocation();
  const [screen, setScreen] = useState<Screen>('dashboard');
  const [selectedTicket, setSelectedTicket] = useState<Ticket>(tickets[0]);
  const [query, setQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [branchFilter, setBranchFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('dateCreated');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [technicianFilter, setTechnicianFilter] = useState<string>('all');
  const [dateRangeFilter, setDateRangeFilter] = useState<string>('all');
  const [queueTab, setQueueTab] = useState<QueueTab>('All');

  useEffect(() => {
    const hashScreen = location.hash.replace('#', '') as Screen;
    const availableScreens: Screen[] = ['dashboard', 'create', 'list', 'details', 'help', 'settings'];
    if (availableScreens.includes(hashScreen)) {
      setScreen(hashScreen);
    }
  }, [location.hash]);

  const profile = {
    name: user?.fullName ?? 'Maria Santos',
    email: user?.userPrincipalName ?? 'maria.santos@example.com',
    branch: 'Head Office BPM',
  };

  const initials = profile.name.split(' ').map((part: string) => part[0]).join('').slice(0, 2).toUpperCase();

  const filteredTickets = useMemo<Ticket[]>(() => {
    const sortValue = (ticket: Ticket, key: SortKey): string => {
      return String(ticket[key]).toLowerCase();
    };

    return tickets
      .filter((ticket: Ticket) => {
        const target = `${ticket.ticketId} ${ticket.title} ${ticket.branch} ${ticket.category} ${ticket.requestor} ${ticket.assignedTo}`.toLowerCase();
        const matchesQuery = query.length === 0 || target.includes(query.toLowerCase());
        const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
        const matchesPriority = priorityFilter === 'all' || ticket.priority === priorityFilter;
        const matchesCategory = categoryFilter === 'all' || ticket.category === categoryFilter;
        const matchesBranch = branchFilter === 'all' || ticket.branch === branchFilter;
        const matchesTechnician = technicianFilter === 'all' || ticket.assignedTo === technicianFilter;
        const matchesTab = queueTab === 'All'
          || (queueTab === 'My Queue' && ticket.assignedTo === 'Allan Reyes')
          || (queueTab === 'Unassigned' && ticket.assignedTo === 'Unassigned')
          || (queueTab === 'At Risk' && ticket.atRisk)
          || (queueTab === 'Escalated' && ticket.escalated)
          || (queueTab === 'Resolved' && ticket.status === 'Resolved')
          || (queueTab === 'Closed' && ticket.status === 'Closed');
        return matchesQuery && matchesStatus && matchesPriority && matchesCategory && matchesBranch && matchesTechnician && matchesTab && dateRangeFilter.length > 0;
      })
      .sort((first: Ticket, second: Ticket) => {
        const firstValue = sortValue(first, sortKey);
        const secondValue = sortValue(second, sortKey);
        const comparison = firstValue.localeCompare(secondValue, undefined, { numeric: true, sensitivity: 'base' });
        return sortDirection === 'asc' ? comparison : -comparison;
      });
  }, [branchFilter, categoryFilter, dateRangeFilter, priorityFilter, query, queueTab, sortDirection, sortKey, statusFilter, technicianFilter]);

  const kpis: KpiCard[] = [
    { label: 'Open Tickets', value: tickets.filter((ticket: Ticket) => !['Resolved', 'Closed'].includes(ticket.status)).length, detail: 'Active branch requests', trend: '+8% today', tone: 'open', icon: Clock3 },
    { label: 'Waiting Tickets', value: tickets.filter((ticket: Ticket) => ticket.status === 'Waiting User' || ticket.status === 'Waiting Vendor').length, detail: 'Needs requester or vendor action', trend: '-2% queue', tone: 'waiting', icon: CircleHelp },
    { label: 'Resolved Tickets', value: tickets.filter((ticket: Ticket) => ticket.status === 'Resolved').length, detail: 'Completed this cycle', trend: '+12% SLA', tone: 'resolved', icon: CheckCircle2 },
    { label: 'High Priority Tickets', value: tickets.filter((ticket: Ticket) => ticket.priority === 'High' || ticket.priority === 'Critical').length, detail: 'High and critical impact', trend: 'Watch list', tone: 'priority', icon: ShieldCheck },
  ];

  const actionCards: ActionCard[] = [
    { title: 'Create Ticket', description: 'Start a new support request', button: 'Open Form', icon: Plus, screen: 'create' },
    { title: 'Review Tickets', description: 'View and manage all requests', button: 'View Queue', icon: ListChecks, screen: 'list' },
    { title: 'Need Help', description: 'Helpdesk guide and standards', button: 'Open Help', icon: CircleHelp, screen: 'help' },
  ];

  const quickActions: QuickAction[] = [
    { label: 'Create Ticket', screen: 'create', icon: Plus },
    { label: 'My Tickets', screen: 'list', icon: UserRound },
    { label: 'Review Queue', screen: 'list', icon: ListChecks },
    { label: 'Escalation Queue', screen: 'list', icon: AlertTriangle },
    { label: 'Knowledge Base', screen: 'help', icon: FileText },
  ];

  const recentActivity: Activity[] = [
    { type: 'Ticket Created', ticketId: 'OSD-1001', detail: 'POS terminal cannot connect reported by SM San Lazaro', time: '8 min ago' },
    { type: 'Ticket Assigned', ticketId: 'OSD-1006', detail: 'Internet ticket assigned to Allan Reyes', time: '18 min ago' },
    { type: 'Ticket Escalated', ticketId: 'OSD-1003', detail: 'CCTV playback issue escalated for SLA breach', time: '32 min ago' },
    { type: 'Ticket Updated', ticketId: 'OSD-1007', detail: 'Vendor patch request updated with new ETA', time: '1h ago' },
    { type: 'Comment Added', ticketId: 'OSD-1002', detail: 'Manager approval reminder added', time: '2h ago' },
    { type: 'Ticket Resolved', ticketId: 'OSD-1004', detail: 'Laptop blue screen ticket resolved', time: '4h ago' },
    { type: 'Ticket Closed', ticketId: 'OSD-1005', detail: 'Printer queue ticket closed by requester', time: 'Yesterday' },
  ];

  const roleCapabilities: RoleCapability[] = [
    { role: 'Branch User', actions: ['Create Ticket', 'My Tickets', 'View Status', 'Add Comments', 'Confirm Resolution'] },
    { role: 'Technician', actions: ['Assigned Queue', 'Update Tickets', 'Internal Notes', 'Resolve Tickets'] },
    { role: 'Senior Officer', actions: ['Queue Management', 'Reassignment', 'Escalation Handling', 'SLA Monitoring'] },
    { role: 'Manager', actions: ['KPI Visibility', 'Queue Overview', 'SLA Dashboard', 'Operational Monitoring'] },
    { role: 'Administrator', actions: ['Full Access', 'Configuration', 'Categories', 'Priorities', 'SLA Settings', 'User Management'] },
  ];

  const toggleSort = (key: SortKey): void => {
    if (sortKey === key) {
      setSortDirection((currentDirection: SortDirection) => currentDirection === 'asc' ? 'desc' : 'asc');
      return;
    }

    setSortKey(key);
    setSortDirection('asc');
  };

  const renderSortableHead = (label: string, key: SortKey) => (
    <Button type="button" variant="ghost" size="sm" className="h-8 px-2 font-semibold" onClick={() => toggleSort(key)}>
      {label}
      <ChevronsUpDown className="h-3.5 w-3.5" />
    </Button>
  );

  const openTicket = (ticket: Ticket): void => {
    setSelectedTicket(ticket);
    setScreen('details');
  };

  const submitTicket = (): void => {
    toast.success('Ticket submitted to the OSD Helpdesk queue');
    setScreen('list');
  };

  const runQueueAction = (label: string): void => {
    if (label === 'Escalation Queue') {
      setQueueTab('Escalated');
    }
    if (label === 'My Tickets') {
      setQueueTab('My Queue');
    }
    setScreen(label === 'Knowledge Base' ? 'help' : label === 'Create Ticket' ? 'create' : 'list');
  };

  return (
    <div className="-m-4 min-h-[calc(100vh-4rem)] bg-background p-3 text-foreground sm:p-4 lg:-m-6 lg:p-6">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6">
        <header className="rounded-2xl border bg-card p-4 text-card-foreground shadow-sm sm:rounded-3xl sm:p-5 lg:p-6">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-start gap-3 sm:gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-sm sm:h-14 sm:w-14">
                <Headphones className="h-6 w-6 sm:h-7 sm:w-7" />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">OSD Helpdesk Workspace</h2>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">Branch IT requests, triage, SLA monitoring, and resolution tracking</p>
                <nav className="mt-4 grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
                  {[
                    { label: 'Home', value: 'dashboard' as Screen },
                    { label: 'Create Ticket', value: 'create' as Screen },
                    { label: 'Review Tickets', value: 'list' as Screen },
                    { label: 'Help', value: 'help' as Screen },
                    { label: 'Settings', value: 'settings' as Screen },
                  ].map((item: { label: string; value: Screen }) => (
                    <Button key={item.value} className="min-h-10 justify-center text-xs sm:text-sm" variant={screen === item.value ? 'default' : 'secondary'} size="sm" onClick={() => setScreen(item.value)}>
                      {item.label}
                    </Button>
                  ))}
                </nav>
              </div>
            </div>
            <div className="grid gap-3 sm:flex sm:flex-row sm:items-center">
              <Button className="min-h-11 justify-center" variant="outline" onClick={() => setScreen('settings')}><Settings className="h-4 w-4" />Settings</Button>
              <div className="flex min-w-0 items-center gap-3 rounded-2xl border bg-background p-3 text-foreground">
                <Avatar><AvatarFallback className="bg-primary text-primary-foreground">{initials}</AvatarFallback></Avatar>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{profile.name}</p>
                  <p className="truncate text-xs text-muted-foreground">{profile.email}</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        {screen === 'dashboard' && (
          <div className="grid gap-4 sm:gap-6 xl:grid-cols-[1fr_340px]">
            <div className="space-y-4 sm:space-y-6">
              <section className="grid gap-3 sm:gap-5 md:grid-cols-3">
                {actionCards.map(({ title, description, button, icon: Icon, screen: nextScreen }: ActionCard, index: number) => {
                  const toneClass = index === 1 ? 'from-accent to-primary' : index === 2 ? 'from-secondary to-card' : 'from-primary to-sidebar';
                  return (
                    <Card key={title} className="group relative overflow-hidden rounded-2xl border-card-outline-strong bg-card-glass text-card-foreground shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover sm:rounded-[24px]">
                      <div className={`absolute inset-x-5 top-0 h-1 rounded-b-full bg-gradient-to-r sm:inset-x-6 ${toneClass}`} />
                      <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary opacity-20 blur-3xl transition-opacity group-hover:opacity-30" />
                      <CardHeader className="relative p-4 pb-3 sm:p-6 sm:pb-3">
                        <div className="mb-3 flex items-start justify-between gap-4">
                          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-md transition-transform group-hover:scale-105 sm:h-14 sm:w-14">
                            <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
                          </span>
                          <Badge variant={index === 0 ? 'default' : 'secondary'} className="rounded-full">OSD</Badge>
                        </div>
                        <CardTitle className="text-lg sm:text-xl">{title}</CardTitle>
                        <CardDescription className="text-sm leading-6">{description}</CardDescription>
                      </CardHeader>
                      <CardContent className="relative p-4 pt-0 sm:p-6 sm:pt-0">
                        <Button className="min-h-11 w-full justify-between rounded-2xl shadow-sm" variant={index === 2 ? 'secondary' : 'default'} onClick={() => setScreen(nextScreen)}>
                          {button}
                          <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </section>

              <Card className="bg-card text-card-foreground shadow-sm">
                <CardHeader className="p-4 sm:p-6">
                  <CardTitle>Desk Overview</CardTitle>
                  <CardDescription className="leading-6">Helpdesk summary by active queue, waiting state, SLA completion, and priority impact.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-3 p-4 pt-0 sm:grid-cols-2 sm:gap-5 sm:p-6 sm:pt-0 xl:grid-cols-4">
                  {kpis.map(({ label, value, detail, trend, tone, icon: Icon }: KpiCard) => {
                    const toneClass: Record<KpiTone, string> = {
                      open: 'from-primary to-sidebar text-primary-foreground shadow-[0_20px_46px_color-mix(in_oklab,var(--primary)_24%,transparent)]',
                      waiting: 'from-accent to-destructive text-accent-foreground shadow-[0_20px_46px_color-mix(in_oklab,var(--accent)_28%,transparent)]',
                      resolved: 'from-chart-3 to-primary text-primary-foreground shadow-[0_20px_46px_color-mix(in_oklab,var(--chart-3)_24%,transparent)]',
                      priority: 'from-sidebar to-accent text-sidebar-foreground shadow-[0_20px_46px_color-mix(in_oklab,var(--accent)_24%,transparent)]',
                    };
                    return (
                      <div key={label} className={`group relative min-h-[138px] overflow-hidden rounded-[20px] bg-gradient-to-br p-4 transition-transform hover:-translate-y-1 sm:h-[150px] sm:p-5 ${toneClass[tone]}`}>
                        <div className="absolute inset-x-8 top-0 h-px bg-current opacity-60" />
                        <div className="absolute -right-8 -top-10 h-32 w-32 rounded-full bg-current opacity-10 blur-2xl" />
                        <div className="relative flex h-full flex-col justify-between gap-4">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <p className="text-sm font-semibold text-inherit">{label}</p>
                              <p className="mt-1 text-xs font-medium leading-5 text-inherit">{detail}</p>
                            </div>
                            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-background text-foreground shadow-sm sm:h-12 sm:w-12">
                              <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
                            </span>
                          </div>
                          <div className="flex items-end justify-between gap-3">
                            <p className="text-4xl font-bold tracking-tight text-inherit sm:text-5xl">{value}</p>
                            <Badge variant="secondary" className="rounded-full shadow-sm">{trend}</Badge>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              <Card className="bg-card text-card-foreground shadow-sm">
                <CardHeader>
                  <CardTitle>Role-Based Workspace Readiness</CardTitle>
                  <CardDescription>Interface sections are organized for future BSP RBAC permissions.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
                  {roleCapabilities.map((role: RoleCapability) => (
                    <div key={role.role} className="rounded-2xl border bg-background p-4 text-foreground">
                      <div className="flex items-center gap-2">
                        <UsersRound className="h-4 w-4" />
                        <p className="font-semibold">{role.role}</p>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {role.actions.map((action: string) => <Badge key={action} variant="secondary" className="rounded-full">{action}</Badge>)}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="bg-card text-card-foreground shadow-sm">
                <CardHeader className="p-4 sm:p-6">
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription className="leading-6">Common OSD queue actions.</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-2 p-4 pt-0 sm:p-6 sm:pt-0">
                  {quickActions.map(({ label, icon: Icon }: QuickAction) => (
                    <Button key={label} variant="outline" className="min-h-11 justify-between rounded-2xl" onClick={() => runQueueAction(label)}>
                      <span className="flex items-center gap-2"><Icon className="h-4 w-4" />{label}</span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-card text-card-foreground shadow-sm">
                <CardHeader className="p-4 sm:p-6">
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription className="leading-6">Sample helpdesk movement across tickets.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 p-4 pt-0 sm:p-6 sm:pt-0">
                  {recentActivity.map((activity: Activity) => (
                    <button key={`${activity.type}-${activity.ticketId}`} type="button" className="min-h-20 w-full rounded-2xl border bg-background p-3 text-left text-foreground transition-colors hover:bg-secondary" onClick={() => toast.info(`${activity.type}: ${activity.ticketId}`)}>
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold">{activity.type}</p>
                          <p className="mt-1 text-xs leading-5 text-muted-foreground">{activity.ticketId} · {activity.detail}</p>
                        </div>
                        <Badge variant="secondary" className="shrink-0 rounded-full">{activity.time}</Badge>
                      </div>
                    </button>
                  ))}
                </CardContent>
              </Card>

              <Card className="group relative overflow-hidden rounded-[28px] border-card-outline-strong bg-card-glass text-card-foreground shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
                <div className="absolute inset-x-8 top-0 h-1 rounded-b-full bg-gradient-to-r from-primary via-accent to-primary" />
                <CardHeader className="relative pb-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <CardTitle>Requestor Profile</CardTitle>
                      <CardDescription>Default requester details for new tickets.</CardDescription>
                    </div>
                    <Badge variant="secondary" className="rounded-full shadow-sm">Verified</Badge>
                  </div>
                </CardHeader>
                <CardContent className="relative space-y-5">
                  <div className="rounded-[24px] border border-card-outline bg-background p-4 text-foreground shadow-sm">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-16 w-16 shadow-md ring-4 ring-primary">
                        <AvatarFallback className="bg-primary text-lg font-bold text-primary-foreground">{initials}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="truncate text-lg font-bold tracking-tight">{profile.name}</p>
                        <p className="truncate text-sm text-muted-foreground">{profile.email}</p>
                        <Badge variant="outline" className="mt-2 rounded-full bg-secondary text-secondary-foreground">Primary requestor</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {screen === 'create' && (
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle>Create Ticket</CardTitle>
              <CardDescription className="leading-6">Capture a new OSD Helpdesk request with required ticket fields.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 p-4 pt-0 sm:p-6 sm:pt-0 lg:grid-cols-2">
              <div className="space-y-2"><Label htmlFor="ticket-title">Title</Label><Input id="ticket-title" className="min-h-11 text-base sm:text-sm" placeholder="Brief issue title" /></div>
              <div className="space-y-2"><Label htmlFor="ticket-branch">Branch</Label><Input id="ticket-branch" className="min-h-11 text-base sm:text-sm" defaultValue={profile.branch} /></div>
              <div className="space-y-2"><Label>Category</Label><Select defaultValue="POS"><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent>{categories.filter((category: string) => category.length > 0).map((category: string) => <SelectItem key={category} value={category}>{category}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label>Priority</Label><Select defaultValue="Medium"><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent>{priorities.filter((priority: TicketPriority) => priority.length > 0).map((priority: TicketPriority) => <SelectItem key={priority} value={priority}>{priority}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label>Status</Label><Select defaultValue="New"><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent>{statuses.filter((status: TicketStatus) => status.length > 0).map((status: TicketStatus) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label htmlFor="ticket-assigned">Assigned Technician</Label><Input id="ticket-assigned" className="min-h-11 text-base sm:text-sm" placeholder="Optional OSD assignee" /></div>
              <div className="space-y-2 lg:col-span-2"><Label htmlFor="ticket-description">Description</Label><Textarea id="ticket-description" placeholder="Describe the issue, impact, and affected users" rows={5} /></div>
              <div className="space-y-2"><Label htmlFor="ticket-attachments">Attachments</Label><Input id="ticket-attachments" className="min-h-11 text-base sm:text-sm" placeholder="Attachment names or SharePoint links" /></div>
              <div className="space-y-2"><Label htmlFor="ticket-contact">Contact Information</Label><Input id="ticket-contact" className="min-h-11 text-base sm:text-sm" defaultValue={profile.email} /></div>
              <div className="grid gap-2 sm:flex sm:flex-wrap lg:col-span-2"><Button className="min-h-11" onClick={submitTicket}>Submit Ticket</Button><Button className="min-h-11" variant="outline" onClick={() => setScreen('dashboard')}>Cancel</Button></div>
            </CardContent>
          </Card>
        )}

        {screen === 'list' && (
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="p-4 sm:p-6">
              <CardTitle>Ticket Queue</CardTitle>
              <CardDescription className="leading-6">Review Tickets opens the enterprise queue with tabs, filters, SLA status, and actions.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-4 pt-0 sm:p-6 sm:pt-0">
              <Tabs value={queueTab} onValueChange={(value: string) => setQueueTab(value as QueueTab)}>
                <TabsList className="grid h-auto grid-cols-2 gap-2 bg-muted p-2 text-muted-foreground sm:grid-cols-3 lg:flex lg:flex-wrap lg:justify-start">
                  {queueTabs.filter((tab: { label: QueueTab; count: number }) => tab.label.length > 0).map((tab: { label: QueueTab; count: number }) => (
                    <TabsTrigger key={tab.label} value={tab.label} className="min-h-10 gap-2 rounded-xl text-xs sm:text-sm">
                      {tab.label}<Badge variant="secondary" className="rounded-full">{tab.count}</Badge>
                    </TabsTrigger>
                  ))}
                </TabsList>
                <TabsContent value={queueTab} className="mt-4 space-y-4">
                  <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
                    <div className="relative md:col-span-2"><Search className="pointer-events-none absolute left-3 top-3.5 h-4 w-4" /><Input className="min-h-11 pl-9 text-base sm:text-sm" placeholder="Search ticket number, branch, requestor, category" value={query} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)} /></div>
                    <div className="space-y-1"><Label className="text-xs font-semibold">Status filter</Label><Select value={statusFilter} onValueChange={setStatusFilter}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All statuses</SelectItem>{statuses.filter((status: TicketStatus) => status.length > 0).map((status: TicketStatus) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></div>
                    <Select value={priorityFilter} onValueChange={setPriorityFilter}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All priorities</SelectItem>{priorities.filter((priority: TicketPriority) => priority.length > 0).map((priority: TicketPriority) => <SelectItem key={priority} value={priority}>{priority}</SelectItem>)}</SelectContent></Select>
                    <Select value={categoryFilter} onValueChange={setCategoryFilter}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All categories</SelectItem>{categories.filter((category: string) => category.length > 0).map((category: string) => <SelectItem key={category} value={category}>{category}</SelectItem>)}</SelectContent></Select>
                    <Select value={branchFilter} onValueChange={setBranchFilter}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All branches</SelectItem>{branches.filter((branch: string) => branch.length > 0).map((branch: string) => <SelectItem key={branch} value={branch}>{branch}</SelectItem>)}</SelectContent></Select>
                    <Select value={technicianFilter} onValueChange={setTechnicianFilter}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All technicians</SelectItem>{technicians.filter((technician: string) => technician.length > 0).map((technician: string) => <SelectItem key={technician} value={technician}>{technician}</SelectItem>)}</SelectContent></Select>
                    <Select value={dateRangeFilter} onValueChange={setDateRangeFilter}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Any date range</SelectItem><SelectItem value="today">Today</SelectItem><SelectItem value="week">This week</SelectItem><SelectItem value="month">This month</SelectItem></SelectContent></Select>
                  </div>
                  <div className="space-y-3 lg:hidden">
                    {filteredTickets.length === 0 ? (
                      <div className="rounded-2xl border bg-background p-6 text-center text-sm text-muted-foreground">No tickets match the selected filters.</div>
                    ) : filteredTickets.map((ticket: Ticket) => (
                      <article key={ticket.ticketId} className="rounded-2xl border bg-background p-4 text-foreground shadow-sm">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <p className="text-sm font-semibold leading-5">{ticket.ticketId}</p>
                            <h3 className="mt-1 text-base font-semibold leading-6">{ticket.title}</h3>
                            <p className="mt-1 text-sm leading-5 text-muted-foreground">{ticket.branch} · {ticket.category}</p>
                          </div>
                          <Badge variant="outline" className={`shrink-0 rounded-full px-3 py-1 font-semibold ${slaBadgeClass(ticket.slaStatus)}`}>{ticket.slaStatus}</Badge>
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          <Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${priorityBadgeClass(ticket.priority)}`}>{ticket.priority}</Badge>
                          <Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${statusBadgeClass(ticket.status)}`}>{ticket.status}</Badge>
                        </div>
                        <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                          <div><p className="font-medium">Requestor</p><p className="mt-1 text-muted-foreground">{ticket.requestor}</p></div>
                          <div><p className="font-medium">Assigned to</p><p className="mt-1 text-muted-foreground">{ticket.assignedTo}</p></div>
                          <div><p className="font-medium">Created</p><p className="mt-1 text-muted-foreground">{ticket.dateCreated}</p></div>
                          <div><p className="font-medium">SLA target</p><p className="mt-1 text-muted-foreground">{ticket.slaTarget}</p></div>
                        </div>
                        <Button className="mt-4 min-h-11 w-full" variant="outline" onClick={() => openTicket(ticket)}>Open ticket</Button>
                      </article>
                    ))}
                  </div>
                  <div className="hidden overflow-x-auto rounded-2xl border lg:block">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{renderSortableHead('Ticket Number', 'ticketId')}</TableHead><TableHead>{renderSortableHead('Branch', 'branch')}</TableHead><TableHead>{renderSortableHead('Requestor', 'requestor')}</TableHead><TableHead>{renderSortableHead('Category', 'category')}</TableHead><TableHead>{renderSortableHead('Priority', 'priority')}</TableHead><TableHead>{renderSortableHead('Status', 'status')}</TableHead><TableHead>{renderSortableHead('Assigned To', 'assignedTo')}</TableHead><TableHead>{renderSortableHead('Created Date', 'dateCreated')}</TableHead><TableHead>{renderSortableHead('SLA Status', 'slaStatus')}</TableHead><TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredTickets.length === 0 ? (
                          <TableRow><TableCell colSpan={10} className="py-8 text-center text-muted-foreground">No tickets match the selected filters.</TableCell></TableRow>
                        ) : filteredTickets.map((ticket: Ticket) => (
                          <TableRow key={ticket.ticketId} className="hover:bg-secondary">
                            <TableCell className="font-medium">{ticket.ticketId}</TableCell>
                            <TableCell>{ticket.branch}</TableCell>
                            <TableCell>{ticket.requestor}</TableCell>
                            <TableCell>{ticket.category}</TableCell>
                            <TableCell><Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${priorityBadgeClass(ticket.priority)}`}>{ticket.priority}</Badge></TableCell>
                            <TableCell><Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${statusBadgeClass(ticket.status)}`}>{ticket.status}</Badge></TableCell>
                            <TableCell>{ticket.assignedTo}</TableCell>
                            <TableCell>{ticket.dateCreated}</TableCell>
                            <TableCell><Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${slaBadgeClass(ticket.slaStatus)}`}>{ticket.slaStatus}</Badge></TableCell>
                            <TableCell><Button size="sm" variant="outline" onClick={() => openTicket(ticket)}>Open</Button></TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}

        {screen === 'details' && (
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0">
                  <CardTitle className="text-xl leading-7 sm:text-2xl">Ticket Detail Workbench</CardTitle>
                  <CardDescription className="mt-2 break-words leading-6">{selectedTicket.ticketId} · {selectedTicket.category} · {selectedTicket.branch}</CardDescription>
                </div>
                <div className="grid gap-2 sm:flex sm:flex-wrap">
                  <Button className="min-h-11" onClick={() => toast.success(`${selectedTicket.ticketId} assigned`)}>Assign</Button>
                  <Button className="min-h-11" variant="outline" onClick={() => toast.success(`${selectedTicket.ticketId} updated`)}>Update</Button>
                  <TicketDetailDrawer ticket={toOperationalRecord(selectedTicket)}><Button className="min-h-11" variant="secondary">Quick View</Button></TicketDetailDrawer>
                </div>
              </div>
            </CardHeader>
            <CardContent className="grid gap-4 p-4 pt-0 sm:p-6 sm:pt-0 lg:grid-cols-3">
              <div className="rounded-2xl border bg-background p-4 text-foreground sm:p-5 lg:col-span-2">
                <div className="flex flex-wrap gap-2"><Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${statusBadgeClass(selectedTicket.status)}`}>{selectedTicket.status}</Badge><Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${priorityBadgeClass(selectedTicket.priority)}`}>{selectedTicket.priority}</Badge><Badge variant="outline" className={`rounded-full px-3 py-1 font-semibold ${slaBadgeClass(selectedTicket.slaStatus)}`}>{selectedTicket.slaStatus}</Badge></div>
                <div className="mt-5 space-y-5 text-sm leading-6"><div><p className="font-semibold">Description</p><p className="mt-2 text-muted-foreground">{selectedTicket.description}</p></div><div><p className="font-semibold">Resolution</p><p className="mt-2 text-muted-foreground">{selectedTicket.resolution}</p></div></div>
                <div className="mt-5 rounded-2xl border bg-card p-4 text-card-foreground"><div className="flex items-center gap-2"><MessageSquare className="h-4 w-4" /><p className="font-semibold">Collaboration</p></div><p className="mt-2 text-sm leading-6 text-muted-foreground">Internal notes, requester comments, and technician updates are staged here for future RBAC-enabled workflows.</p></div>
              </div>
              <div className="grid gap-3 rounded-2xl border bg-background p-4 text-sm text-foreground sm:grid-cols-2 lg:block lg:space-y-3">
                <p><span className="block font-medium sm:inline">Ticket Number:</span> {selectedTicket.ticketId}</p>
                <p><span className="block font-medium sm:inline">Category:</span> {selectedTicket.category}</p>
                <p><span className="block font-medium sm:inline">Branch:</span> {selectedTicket.branch}</p>
                <p><span className="block font-medium sm:inline">Requestor:</span> {selectedTicket.requestor}</p>
                <p className="break-words"><span className="block font-medium sm:inline">Contact Information:</span> {selectedTicket.contact}</p>
                <p><span className="block font-medium sm:inline">Priority:</span> {selectedTicket.priority}</p>
                <p><span className="block font-medium sm:inline">Status:</span> {selectedTicket.status}</p>
                <p><span className="block font-medium sm:inline">Assigned Technician:</span> {selectedTicket.assignedTo}</p>
                <p><span className="block font-medium sm:inline">Created Date:</span> {selectedTicket.dateCreated}</p>
                <p><span className="block font-medium sm:inline">SLA Target:</span> {selectedTicket.slaTarget}</p>
                <p><span className="block font-medium sm:inline">SLA Remaining:</span> {selectedTicket.slaRemaining}</p>
                <p className="flex items-center gap-2 sm:col-span-2"><Paperclip className="h-4 w-4 shrink-0" />{selectedTicket.attachments}</p>
              </div>
              <div className="grid gap-2 sm:flex sm:flex-wrap lg:col-span-3"><Button className="min-h-11" onClick={() => toast.success('Ticket status updated')}>Update Status</Button><Button className="min-h-11" variant="outline" onClick={() => setScreen('list')}>Back to Queue</Button></div>
            </CardContent>
          </Card>
        )}

        {screen === 'help' && (
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="p-4 sm:p-6"><CardTitle className="text-xl sm:text-2xl">Help</CardTitle><CardDescription className="leading-6">Helpdesk guide and standards for OSD ticket handling.</CardDescription></CardHeader>
            <CardContent className="grid gap-3 p-4 pt-0 sm:p-6 sm:pt-0 md:grid-cols-3">
              {['Log clear impact and affected branch', 'Use priority based on business urgency', 'Keep resolution notes updated'].map((item: string, index: number) => <div key={item} className="rounded-2xl border bg-background p-4 text-foreground sm:p-5"><Badge variant="secondary">Standard {index + 1}</Badge><p className="mt-3 text-base font-medium leading-6">{item}</p></div>)}
            </CardContent>
          </Card>
        )}

        {screen === 'settings' && (
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="p-4 sm:p-6"><CardTitle className="text-xl sm:text-2xl">Settings</CardTitle><CardDescription className="leading-6">Configure OSD queue routing, categories, priorities, SLA standards, and user management readiness.</CardDescription></CardHeader>
            <CardContent className="grid gap-3 p-4 pt-0 sm:p-6 sm:pt-0 md:grid-cols-2">
              <div className="rounded-2xl border bg-background p-4 text-foreground sm:p-5"><FileText className="h-5 w-5" /><p className="mt-3 text-base font-medium">Ticket categories</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Categories include CCTV, POS, Network, Internet, Email, Microsoft 365, Hardware, and Software.</p></div>
              <div className="rounded-2xl border bg-background p-4 text-foreground sm:p-5"><UserRound className="h-5 w-5" /><p className="mt-3 text-base font-medium">Requestor profile</p><p className="mt-2 text-sm leading-6 text-muted-foreground">Name, email, and branch default from Microsoft 365 context.</p></div>
              <Button asChild className="min-h-11 md:w-fit" variant="outline"><Link to="/settings">Open system settings</Link></Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
