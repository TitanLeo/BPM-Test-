import { useMemo, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis, YAxis } from 'recharts';
import { AlertTriangle, BookmarkCheck, Clock, ShieldCheck, TrendingUp } from 'lucide-react';

import { TicketDetailDrawer } from '@/components/ticket-detail-drawer';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import type { ChartConfig } from '@/components/ui/chart';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { records, statusDistribution, weeklyThroughput } from '@/lib/mock-data';
import type { OperationalRecord, Priority, Status } from '@/lib/mock-data';

const chartConfig = {
  opened: { label: 'Opened', color: 'var(--chart-1)' },
  resolved: { label: 'Resolved', color: 'var(--chart-2)' },
  value: { label: 'Records', color: 'var(--chart-1)' },
} satisfies ChartConfig;

type TicketFilter = 'all' | Status | Priority;
type SavedView = { name: string; description: string; filter: TicketFilter };
type KpiCard = { title: string; value: string; trend: string; badge: string; icon: typeof Clock; style: string };

const kpiCards: KpiCard[] = [
  { title: 'Open Requests', value: '42', trend: '+5% vs last week', badge: 'Live queue', icon: Clock, style: 'from-primary to-primary' },
  { title: 'Needs Attention', value: '9', trend: '+3 escalations', badge: 'Priority focus', icon: AlertTriangle, style: 'from-accent to-accent' },
  { title: 'SLA Compliance', value: '94%', trend: '+2% month to date', badge: 'On target', icon: ShieldCheck, style: 'from-primary to-[color:var(--chart-3)]' },
  { title: 'Resolution Rate', value: '87%', trend: '+6% throughput', badge: 'Improving', icon: TrendingUp, style: 'from-primary via-primary to-accent' },
];

const savedViews: SavedView[] = [
  { name: 'Executive Watchlist', description: 'Attention and critical items', filter: 'Needs Attention' },
  { name: 'High Priority Queue', description: 'Urgent branch support work', filter: 'High' },
  { name: 'Resolved This Week', description: 'Completed operational records', filter: 'Resolved' },
];

function filterCount(filter: TicketFilter): number {
  if (filter === 'all') return records.length;
  return records.filter((record: OperationalRecord) => record.status === filter || record.priority === filter).length;
}

function statusClass(status: Status): string {
  if (status === 'Needs Attention') return 'bg-accent text-accent-foreground';
  if (status === 'In Progress') return 'bg-primary text-primary-foreground';
  if (status === 'Resolved' || status === 'Verified') return 'bg-success text-success-foreground';
  return 'bg-secondary text-secondary-foreground';
}

function priorityClass(priority: Priority): string {
  if (priority === 'Critical') return 'bg-destructive text-destructive-foreground';
  if (priority === 'High') return 'bg-accent text-accent-foreground';
  return 'bg-secondary text-secondary-foreground';
}

export default function HomePage() {
  const [activeFilter, setActiveFilter] = useState<TicketFilter>('all');
  const [activeView, setActiveView] = useState('Executive Watchlist');
  const filters: { label: string; value: TicketFilter }[] = [
    { label: 'All', value: 'all' }, { label: 'Open', value: 'Open' }, { label: 'Needs Attention', value: 'Needs Attention' },
    { label: 'In Progress', value: 'In Progress' }, { label: 'High Priority', value: 'High' }, { label: 'Critical', value: 'Critical' }, { label: 'Resolved', value: 'Resolved' },
  ];
  const filteredRecords = useMemo<OperationalRecord[]>(() => activeFilter === 'all' ? records : records.filter((record: OperationalRecord) => record.status === activeFilter || record.priority === activeFilter), [activeFilter]);

  const selectFilter = (filter: TicketFilter): void => { setActiveView(''); setActiveFilter(filter); };
  const selectView = (view: SavedView): void => { setActiveView(view.name); setActiveFilter(view.filter); };

  return (
    <div className="space-y-8">
      <section className="rounded-[28px] border border-card-outline bg-card/85 p-6 text-card-foreground shadow-card backdrop-blur-xl lg:p-8">
        <div className="mb-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
          <div><h2 className="text-2xl font-semibold tracking-tight">Executive Operations Center</h2><p className="mt-2 text-sm text-muted-foreground">Real-time support demand, SLA health, and service resolution performance.</p></div>
          <Badge variant="secondary">Power BI-style service view</Badge>
        </div>
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {kpiCards.map((card: KpiCard) => {
            const Icon = card.icon;
            return (
              <div key={card.title} className={`group relative h-[156px] overflow-hidden rounded-[22px] border border-primary-foreground bg-gradient-to-br ${card.style} p-5 text-primary-foreground shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover`}>
                <div className="relative flex h-full flex-col justify-between">
                  <div className="flex items-start justify-between gap-3"><div><p className="text-sm font-bold">{card.title}</p><p className="mt-2 text-4xl font-black tracking-tight">{card.value}</p></div><span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary-foreground text-primary"><Icon className="h-6 w-6" /></span></div>
                  <div className="flex items-center justify-between gap-2 text-xs font-bold"><span className="rounded-full bg-primary-foreground px-3 py-1 text-primary">{card.trend}</span><span>{card.badge}</span></div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <Card><CardHeader><CardTitle>Status Distribution</CardTitle><CardDescription>Queue composition by current operational state.</CardDescription></CardHeader><CardContent><ChartContainer config={chartConfig} className="h-[250px] w-full"><PieChart><ChartTooltip content={<ChartTooltipContent />} /><Pie data={statusDistribution} dataKey="value" nameKey="name" innerRadius={62} outerRadius={96}>{statusDistribution.map((entry: { name: string; value: number }, index: number) => <Cell key={entry.name} fill={`var(--chart-${(index % 5) + 1})`} />)}</Pie></PieChart></ChartContainer></CardContent></Card>
        <Card><CardHeader><CardTitle>Weekly Throughput</CardTitle><CardDescription>Opened versus resolved requests.</CardDescription></CardHeader><CardContent><ChartContainer config={chartConfig} className="h-[250px] w-full"><BarChart accessibilityLayer data={weeklyThroughput}><CartesianGrid vertical={false} /><XAxis dataKey="day" tickLine={false} axisLine={false} /><YAxis tickLine={false} axisLine={false} /><ChartTooltip content={<ChartTooltipContent />} /><Bar dataKey="opened" fill="var(--chart-1)" radius={8} /><Bar dataKey="resolved" fill="var(--chart-2)" radius={8} /></BarChart></ChartContainer></CardContent></Card>
      </section>

      <Card>
        <CardHeader>
          <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-start">
            <div className="flex-1"><div className="flex items-center gap-2"><CardTitle>Operational Records</CardTitle><Badge variant="secondary">{filteredRecords.length} shown</Badge></div><CardDescription>Enterprise support queue across active modules.</CardDescription>
              <div className="mt-4 rounded-2xl border border-card-outline bg-background p-3"><div className="mb-3 flex items-center gap-2 text-sm font-semibold"><BookmarkCheck className="h-4 w-4" />Saved filter views</div><div className="grid gap-2 md:grid-cols-3">
                {savedViews.map((view: SavedView) => <button key={view.name} type="button" onClick={() => selectView(view)} className={`rounded-xl border p-3 text-left transition-colors ${activeView === view.name ? 'bg-primary text-primary-foreground' : 'bg-card text-card-foreground hover:bg-secondary hover:text-secondary-foreground'}`}><span className="flex justify-between gap-2 text-sm font-bold">{view.name}<span>{filterCount(view.filter)}</span></span><span className={`mt-1 block text-xs ${activeView === view.name ? 'text-primary-foreground' : 'text-muted-foreground'}`}>{view.description}</span></button>)}
              </div></div>
              <div className="mt-4 flex flex-wrap gap-2">{filters.map((filter: { label: string; value: TicketFilter }) => <button key={filter.value} type="button" onClick={() => selectFilter(filter.value)} className={`rounded-full border px-4 py-2 text-sm font-semibold ${activeFilter === filter.value && !activeView ? 'bg-primary text-primary-foreground' : 'bg-background text-foreground hover:bg-secondary hover:text-secondary-foreground'}`}>{filter.label} <span className="ml-1">{filterCount(filter.value)}</span></button>)}</div>
            </div>
            <div className="w-full lg:w-56"><div className="mb-2 flex justify-between text-sm font-medium"><span>SLA Compliance</span><span>94%</span></div><Progress value={94} /></div>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto"><Table><TableHeader><TableRow><TableHead>Ticket No.</TableHead><TableHead>Module</TableHead><TableHead>Requestor</TableHead><TableHead>Assigned To</TableHead><TableHead>Status</TableHead><TableHead>Priority</TableHead><TableHead>Due Date</TableHead></TableRow></TableHeader><TableBody>
          {filteredRecords.map((record: OperationalRecord) => <TicketDetailDrawer key={record.ticketNo} ticket={record}><TableRow className="cursor-pointer"><TableCell className="font-semibold">{record.ticketNo}</TableCell><TableCell>{record.module}</TableCell><TableCell>{record.requestor}</TableCell><TableCell>{record.assignedTo}</TableCell><TableCell><Badge variant="outline" className={statusClass(record.status)}>{record.status}</Badge></TableCell><TableCell><Badge variant="outline" className={priorityClass(record.priority)}>{record.priority}</Badge></TableCell><TableCell>{record.dueDate}</TableCell></TableRow></TicketDetailDrawer>)}
        </TableBody></Table></CardContent>
      </Card>
    </div>
  );
}