import { type ChangeEvent, type FormEvent, useMemo, useState } from 'react';
import { format } from 'date-fns';
import { useParams } from 'react-router-dom';
import { ArrowUpDown, Bell, CalendarIcon, CheckCircle2, Clock, Eye, Package, Pencil, Plus, Search, ShieldCheck, Trash2, Truck, Wrench } from 'lucide-react';
import { toast } from 'sonner';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { useCreatePOSDATA, useDeletePOSDATA, usePOSDATAList, useUpdatePOSDATA } from '@/generated/hooks/use-posdata';
import { POSDATAIssueCategoryKeyToLabel, type POSDATA, type POSDATAIssueCategoryKey } from '@/generated/models/posdata-model';
import MmsPasswordResetPage from '@/pages/mms-password-reset';
import { modules, records, type ModuleInfo, type OperationalRecord } from '@/lib/mock-data';
import { cn } from '@/lib/utils';

type PosTab = 'monitoring' | 'inventory' | 'deployments';
type TicketMode = 'add' | 'view' | 'edit';
type PosSortKey = 'branch' | 'tID' | 'issue' | 'dateReported' | 'status';
type SortDirection = 'asc' | 'desc';
type InventoryStatus = 'Active' | 'In Repair' | 'Retired' | 'Needs Replacement';
type InventoryDevice = { assetTag: string; serialNumber: string; model: string; branch: string; status: InventoryStatus; warrantyExpiry: string; lastUpdated: string; lane: string; health: number; owner: string };
type DeploymentRecord = { deploymentId: string; branch: string; deviceModel: string; assignedTechnician: string; scheduledDate: string; installationDate: string; status: 'Scheduled' | 'In Progress' | 'Completed' | 'Delayed' };
type InventoryFilter = 'all' | InventoryStatus;
type PosFormState = {
  branch: string;
  tID: string;
  ticketIDNumber: string;
  issue: string;
  issueCategoryKey: POSDATAIssueCategoryKey | 'none';
  dateReported: string;
  dateEncountered: string;
  dateResolved: string;
  status: string;
  support: string;
  model: string;
  rootCause: string;
  resolution: string;
  age: string;
  ticketage: string;
  availableWorkingPOS: string;
  wITHMANUALPADDEDSI: string;
  wITHPROCESSEDTRANSACTIONSBEFOREISSUE: string;
};

const inventoryDevices: InventoryDevice[] = [
  { assetTag: 'POS-10021', serialNumber: 'SN-POS-88310', model: 'Verifone VX520', branch: 'Main Branch', status: 'Active', warrantyExpiry: '2027-04-18', lastUpdated: '2026-08-04', lane: 'Counter 01', health: 96, owner: 'Store Systems' },
  { assetTag: 'POS-10034', serialNumber: 'SN-POS-88492', model: 'Ingenico Desk 5000', branch: 'North Branch', status: 'In Repair', warrantyExpiry: '2026-12-11', lastUpdated: '2026-08-07', lane: 'Counter 03', health: 48, owner: 'Field Support' },
  { assetTag: 'POS-10057', serialNumber: 'SN-POS-88941', model: 'PAX A920', branch: 'South Branch', status: 'Active', warrantyExpiry: '2028-01-23', lastUpdated: '2026-08-08', lane: 'Mobile Kiosk', health: 91, owner: 'Store Systems' },
  { assetTag: 'POS-10066', serialNumber: 'SN-POS-89104', model: 'Verifone VX680', branch: 'East Branch', status: 'Retired', warrantyExpiry: '2025-10-30', lastUpdated: '2026-07-29', lane: 'Counter 02', health: 18, owner: 'Asset Control' },
  { assetTag: 'POS-10078', serialNumber: 'SN-POS-89355', model: 'Ingenico Move 5000', branch: 'West Branch', status: 'Needs Replacement', warrantyExpiry: '2026-09-02', lastUpdated: '2026-08-09', lane: 'Counter 05', health: 36, owner: 'Store Systems' },
  { assetTag: 'POS-10091', serialNumber: 'SN-POS-89420', model: 'PAX A920', branch: 'Main Branch', status: 'Active', warrantyExpiry: '2028-03-19', lastUpdated: '2026-08-10', lane: 'Queue Buster', health: 88, owner: 'Store Systems' },
];

const deployments: DeploymentRecord[] = [
  { deploymentId: 'DEP-24081', branch: 'Main Branch', deviceModel: 'PAX A920', assignedTechnician: 'R. Santos', scheduledDate: '2026-08-12', installationDate: '2026-08-12', status: 'Scheduled' },
  { deploymentId: 'DEP-24082', branch: 'North Branch', deviceModel: 'Ingenico Desk 5000', assignedTechnician: 'M. Cruz', scheduledDate: '2026-08-13', installationDate: 'Pending', status: 'In Progress' },
  { deploymentId: 'DEP-24083', branch: 'South Branch', deviceModel: 'Verifone VX520', assignedTechnician: 'A. Reyes', scheduledDate: '2026-08-07', installationDate: '2026-08-07', status: 'Completed' },
  { deploymentId: 'DEP-24084', branch: 'East Branch', deviceModel: 'PAX A920', assignedTechnician: 'J. Lim', scheduledDate: '2026-08-09', installationDate: 'Pending', status: 'Delayed' },
];

const statuses = ['Open', 'In Progress', 'Waiting User', 'Waiting Vendor', 'Resolved', 'Closed'];
const statusFilterOptions = ['all', ...statuses] as const;
const issueCategories = Object.entries(POSDATAIssueCategoryKeyToLabel) as [POSDATAIssueCategoryKey, string][];

const getTodayValue = (): string => format(new Date(), 'yyyy-MM-dd');

const createEmptyForm = (): PosFormState => {
  const today = getTodayValue();
  return {
    branch: '',
    tID: '',
    ticketIDNumber: '',
    issue: '',
    issueCategoryKey: 'none',
    dateReported: today,
    dateEncountered: today,
    dateResolved: '',
    status: 'Open',
    support: '',
    model: '',
    rootCause: '',
    resolution: '',
    age: '0',
    ticketage: '0 days',
    availableWorkingPOS: '',
    wITHMANUALPADDEDSI: 'no',
    wITHPROCESSEDTRANSACTIONSBEFOREISSUE: 'no',
  };
};

const statusBadgeClass = (value: string): string => {
  const normalized = value.toLowerCase();
  if (normalized.includes('retired') || normalized.includes('delayed') || normalized.includes('closed')) return 'bg-destructive text-destructive-foreground';
  if (normalized.includes('repair') || normalized.includes('progress') || normalized.includes('scheduled') || normalized.includes('waiting')) return 'bg-accent text-accent-foreground';
  return 'bg-primary text-primary-foreground';
};

const calculateTicketAgeDays = (dateReported: string, status: string, dateResolved: string): number => {
  const reportedDate = parseFormDate(dateReported);
  if (!reportedDate) return 0;
  const normalizedStatus = status.toLowerCase();
  const endDate = normalizedStatus.includes('closed') && dateResolved ? parseFormDate(dateResolved) ?? new Date() : new Date();
  const reportedStart = new Date(reportedDate.getFullYear(), reportedDate.getMonth(), reportedDate.getDate()).getTime();
  const endStart = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate()).getTime();
  return Math.max(0, Math.floor((endStart - reportedStart) / 86_400_000));
};

const formatTicketAge = (dateReported: string, status: string, dateResolved: string): string => {
  const days = calculateTicketAgeDays(dateReported, status, dateResolved);
  return `${days} ${days === 1 ? 'day' : 'days'}`;
};

const getSortableValue = (record: POSDATA, key: PosSortKey): string | number => {
  if (key === 'tID') return record.tID ?? record.ticketIDNumber ?? 0;
  if (key === 'dateReported') return parseFormDate(record.dateReported ?? '')?.getTime() ?? 0;
  return (record[key] ?? '').toString().toLowerCase();
};

const toFormState = (record?: POSDATA): PosFormState => ({
  branch: record?.branch ?? '',
  tID: record?.tID?.toString() ?? '',
  ticketIDNumber: record?.ticketIDNumber?.toString() ?? '',
  issue: record?.issue ?? '',
  issueCategoryKey: record?.issueCategoryKey ?? 'none',
  dateReported: record?.dateReported ?? '',
  dateEncountered: record?.dateEncountered ?? '',
  dateResolved: record?.dateResolved ?? '',
  status: record?.status ?? 'Open',
  support: record?.support ?? '',
  model: record?.model ?? '',
  rootCause: record?.rootCause ?? '',
  resolution: record?.resolution ?? '',
  age: String(calculateTicketAgeDays(record?.dateReported ?? '', record?.status ?? 'Open', record?.dateResolved ?? '')),
  ticketage: formatTicketAge(record?.dateReported ?? '', record?.status ?? 'Open', record?.dateResolved ?? ''),
  availableWorkingPOS: record?.availableWorkingPOS ?? '',
  wITHMANUALPADDEDSI: record?.wITHMANUALPADDEDSI ? 'yes' : 'no',
  wITHPROCESSEDTRANSACTIONSBEFOREISSUE: record?.wITHPROCESSEDTRANSACTIONSBEFOREISSUE ? 'yes' : 'no',
});

const toPayload = (form: PosFormState): Omit<POSDATA, 'id'> => ({
  pOS: form.branch || `POS-${form.tID || Date.now()}`,
  branch: form.branch,
  tID: form.tID ? Number(form.tID) : undefined,
  ticketIDNumber: form.ticketIDNumber ? Number(form.ticketIDNumber) : undefined,
  issue: form.issue,
  issueCategoryKey: form.issueCategoryKey === 'none' ? undefined : form.issueCategoryKey,
  dateReported: form.dateReported,
  dateEncountered: form.dateEncountered,
  dateResolved: form.dateResolved,
  status: form.status,
  support: form.support,
  model: form.model,
  rootCause: form.rootCause,
  resolution: form.resolution,
  age: calculateTicketAgeDays(form.dateReported, form.status, form.dateResolved),
  ticketage: formatTicketAge(form.dateReported, form.status, form.dateResolved),
  availableWorkingPOS: form.availableWorkingPOS,
  wITHMANUALPADDEDSI: form.wITHMANUALPADDEDSI === 'yes',
  wITHPROCESSEDTRANSACTIONSBEFOREISSUE: form.wITHPROCESSEDTRANSACTIONSBEFOREISSUE === 'yes',
});

function KpiCard({ title, value, icon: Icon, alert = false }: { title: string; value: string; icon: typeof Package; alert?: boolean }) {
  return (
    <Card className={cn('border-l-4 border-l-primary', alert && 'border-l-destructive')}>
      <CardContent className="flex items-center gap-3 p-4 sm:gap-4 sm:p-5">
        <span className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground sm:h-12 sm:w-12', alert && 'bg-destructive text-destructive-foreground')}>
          <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
        </span>
        <div className="min-w-0">
          <p className="text-xs font-medium text-muted-foreground sm:text-sm">{title}</p>
          <p className="text-xl font-semibold sm:text-2xl">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function PosTabs({ activeTab, setActiveTab }: { activeTab: PosTab; setActiveTab: (tab: PosTab) => void }) {
  const tabs: { id: PosTab; label: string }[] = [{ id: 'monitoring', label: 'Monitoring' }, { id: 'inventory', label: 'Inventory' }, { id: 'deployments', label: 'Deployments' }];
  return (
    <div className="overflow-x-auto rounded-2xl border border-card-outline bg-card p-1" role="tablist" aria-label="POS workspaces">
      <div className="grid min-w-max grid-cols-3 gap-1 sm:min-w-0">
        {tabs.map((tab: { id: PosTab; label: string }) => (
          <button key={tab.id} type="button" role="tab" aria-selected={activeTab === tab.id} onClick={() => setActiveTab(tab.id)} className={cn('min-h-11 rounded-xl px-4 py-2 text-sm font-semibold transition-colors duration-200', activeTab === tab.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-secondary hover:text-secondary-foreground')}>
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function formatPosDate(value?: string): string {
  if (!value) return 'Not set';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString();
}


function parseFormDate(value: string): Date | undefined {
  if (!value) return undefined;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? undefined : date;
}

function toDateValue(date?: Date): string {
  if (!date) return '';
  return format(date, 'yyyy-MM-dd');
}

function DatePickerField({ label, value, required = false, readOnly, onChange }: { label: string; value: string; required?: boolean; readOnly: boolean; onChange: (value: string) => void }) {
  const selectedDate = parseFormDate(value);
  const LabelComponent = required ? RequiredLabel : Label;
  return (
    <div className="space-y-2">
      <LabelComponent>{label}</LabelComponent>
      <Popover>
        <PopoverTrigger asChild>
          <Button type="button" variant="outline" disabled={readOnly} className={cn('w-full justify-start text-left font-normal', !selectedDate && 'text-muted-foreground')}>
            <CalendarIcon className="mr-2 h-4 w-4" />
            {selectedDate ? format(selectedDate, 'PPP') : <span>Select date</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0">
          <Calendar mode="single" selected={selectedDate} onSelect={(date: Date | undefined) => onChange(toDateValue(date))} initialFocus />
        </PopoverContent>
      </Popover>
    </div>
  );
}
function RequiredLabel({ children }: { children: string }) {
  return <Label className="text-destructive">{children}</Label>;
}

function PosTicketDialog({ mode, open, form, onOpenChange, onFormChange, onSubmit, onSwitchToEdit }: { mode: TicketMode; open: boolean; form: PosFormState; onOpenChange: (open: boolean) => void; onFormChange: (field: keyof PosFormState, value: string) => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void; onSwitchToEdit?: () => void }) {
  const readOnly = mode === 'view';
  const title = mode === 'add' ? 'Add POS Ticket' : mode === 'edit' ? 'Edit POS Ticket' : 'View POS Ticket';
  const ticketAge = formatTicketAge(form.dateReported, form.status, form.dateResolved);
  const ageDays = String(calculateTicketAgeDays(form.dateReported, form.status, form.dateResolved));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] w-[calc(100vw-1.5rem)] max-w-5xl overflow-hidden p-0 sm:w-full">
        <div className="sticky top-0 z-10 border-b border-border bg-popover px-4 py-4 text-popover-foreground sm:px-6">
          <DialogHeader className="space-y-2">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div className="space-y-1">
                <DialogTitle className="text-xl sm:text-2xl">{title}</DialogTitle>
                <DialogDescription>Complete the required POS-DATA fields first, then add device and resolution details.</DialogDescription>
              </div>
              <Badge variant="secondary" className={statusBadgeClass(form.status || 'Open')}>{form.status || 'Open'}</Badge>
            </div>
          </DialogHeader>
        </div>
        <form onSubmit={onSubmit} className="flex max-h-[calc(92vh-5rem)] flex-col">
          <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4 sm:px-6">
            <section className="grid gap-3 rounded-2xl border border-card-outline bg-secondary p-3 text-secondary-foreground sm:grid-cols-3 sm:p-4">
              <div>
                <p className="text-xs font-medium">Ticket age</p>
                <p className="text-lg font-semibold">{ticketAge}</p>
              </div>
              <div>
                <p className="text-xs font-medium">Branch</p>
                <p className="truncate text-lg font-semibold">{form.branch || 'Not set'}</p>
              </div>
              <div>
                <p className="text-xs font-medium">Terminal ID</p>
                <p className="truncate text-lg font-semibold">{form.tID || form.ticketIDNumber || 'Not set'}</p>
              </div>
            </section>

            <section className="space-y-3 rounded-2xl border border-card-outline bg-card p-4 text-card-foreground">
              <h3 className="text-sm font-semibold text-foreground">Ticket Information</h3>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-2 lg:col-span-2"><RequiredLabel>Branch</RequiredLabel><Input className="min-h-11" value={form.branch} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('branch', event.target.value)} /></div>
                <div className="space-y-2"><RequiredLabel>TID</RequiredLabel><Input className="min-h-11" value={form.tID} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('tID', event.target.value)} /></div>
                <div className="space-y-2"><Label>Ticket ID Number</Label><Input className="min-h-11" value={form.ticketIDNumber} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('ticketIDNumber', event.target.value)} /></div>
                <div className="space-y-2 lg:col-span-2"><Label>Status</Label><Select value={form.status} disabled={readOnly} onValueChange={(value: string) => onFormChange('status', value)}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent>{statuses.filter((status: string) => status).map((status: string) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-2 lg:col-span-2"><Label>Support</Label><Input className="min-h-11" value={form.support} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('support', event.target.value)} /></div>
              </div>
            </section>

            <section className="space-y-3 rounded-2xl border border-card-outline bg-card p-4 text-card-foreground">
              <h3 className="text-sm font-semibold text-foreground">Issue Details</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2 sm:col-span-2"><RequiredLabel>Issue</RequiredLabel><Input className="min-h-11" value={form.issue} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('issue', event.target.value)} /></div>
                <div className="space-y-2 sm:col-span-2"><Label>Issue Category</Label><Select value={form.issueCategoryKey} disabled={readOnly} onValueChange={(value: string) => onFormChange('issueCategoryKey', value)}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">None</SelectItem>{issueCategories.filter(([key]: [POSDATAIssueCategoryKey, string]) => key).map(([key, label]: [POSDATAIssueCategoryKey, string]) => <SelectItem key={key} value={key}>{label.trim()}</SelectItem>)}</SelectContent></Select></div>
                <DatePickerField label="Date Reported" value={form.dateReported} required readOnly={readOnly} onChange={(value: string) => onFormChange('dateReported', value)} />
                <DatePickerField label="Date Encountered" value={form.dateEncountered} readOnly={readOnly} onChange={(value: string) => onFormChange('dateEncountered', value)} />
                <DatePickerField label="Date Resolved" value={form.dateResolved} readOnly={readOnly} onChange={(value: string) => onFormChange('dateResolved', value)} />
                <div className="space-y-2"><Label>Age</Label><Input className="min-h-11" value={ageDays} readOnly /></div>
              </div>
            </section>

            <section className="space-y-3 rounded-2xl border border-card-outline bg-card p-4 text-card-foreground">
              <h3 className="text-sm font-semibold text-foreground">Device and Resolution</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2"><Label>Model</Label><Input className="min-h-11" value={form.model} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('model', event.target.value)} /></div>
                <div className="space-y-2"><Label>Available Working POS</Label><Input className="min-h-11" value={form.availableWorkingPOS} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLInputElement>) => onFormChange('availableWorkingPOS', event.target.value)} /></div>
                <div className="space-y-2"><Label>With Manual Padded SI</Label><Select value={form.wITHMANUALPADDEDSI} disabled={readOnly} onValueChange={(value: string) => onFormChange('wITHMANUALPADDEDSI', value)}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="no">No</SelectItem><SelectItem value="yes">Yes</SelectItem></SelectContent></Select></div>
                <div className="space-y-2"><Label>With Processed Transactions Before Issue</Label><Select value={form.wITHPROCESSEDTRANSACTIONSBEFOREISSUE} disabled={readOnly} onValueChange={(value: string) => onFormChange('wITHPROCESSEDTRANSACTIONSBEFOREISSUE', value)}><SelectTrigger className="min-h-11"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="no">No</SelectItem><SelectItem value="yes">Yes</SelectItem></SelectContent></Select></div>
                <div className="space-y-2 sm:col-span-2"><Label>Root Cause</Label><Textarea className="min-h-28" value={form.rootCause} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => onFormChange('rootCause', event.target.value)} /></div>
                <div className="space-y-2 sm:col-span-2"><Label>Resolution</Label><Textarea className="min-h-28" value={form.resolution} readOnly={readOnly} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => onFormChange('resolution', event.target.value)} /></div>
              </div>
            </section>
          </div>
          <DialogFooter className="sticky bottom-0 mt-0 gap-2 border-t border-border bg-popover px-4 py-4 text-popover-foreground sm:px-6">
            <Button type="button" variant="outline" className="min-h-11 w-full sm:w-auto" onClick={() => onOpenChange(false)}>Close</Button>
            {readOnly && onSwitchToEdit && <Button type="button" className="min-h-11 w-full sm:w-auto" onClick={onSwitchToEdit}><Pencil className="mr-2 h-4 w-4" />Edit Ticket</Button>}
            {!readOnly && <Button type="submit" className="min-h-11 w-full sm:w-auto">{mode === 'add' ? 'Create Ticket' : 'Save Changes'}</Button>}
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}


function PosMonitoringWorkspace() {
  const { data: posDataResponse = [], isLoading } = usePOSDATAList();
  const createTicket = useCreatePOSDATA();
  const updateTicket = useUpdatePOSDATA();
  const deleteTicket = useDeletePOSDATA();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [mode, setMode] = useState<TicketMode>('add');
  const [selectedRecord, setSelectedRecord] = useState<POSDATA | undefined>();
  const [form, setForm] = useState<PosFormState>(() => createEmptyForm());
  const posData = Array.isArray(posDataResponse) ? posDataResponse : [];
  const openCount = posData.filter((record: POSDATA) => (record.status ?? '').toLowerCase().includes('open')).length;
  const inProgressCount = posData.filter((record: POSDATA) => (record.status ?? '').toLowerCase().includes('progress')).length;
  const resolvedCount = posData.filter((record: POSDATA) => ['resolved', 'closed'].some((status: string) => (record.status ?? '').toLowerCase().includes(status))).length;
  const criticalCount = posData.filter((record: POSDATA) => (record.issue ?? '').toLowerCase().includes('critical') || (record.issueCategoryKey ?? '').toLowerCase().includes('hardware')).length;
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<PosSortKey>('dateReported');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const filteredAndSortedPosData = useMemo(() => {
    const filtered = statusFilter === 'all' ? posData : posData.filter((record: POSDATA) => (record.status || 'Open') === statusFilter);
    return [...filtered].sort((first: POSDATA, second: POSDATA) => {
      const firstValue = getSortableValue(first, sortKey);
      const secondValue = getSortableValue(second, sortKey);
      const comparison = typeof firstValue === 'number' && typeof secondValue === 'number' ? firstValue - secondValue : String(firstValue).localeCompare(String(secondValue));
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [posData, sortDirection, sortKey, statusFilter]);

  const handleSort = (key: PosSortKey): void => {
    if (sortKey === key) {
      setSortDirection((current: SortDirection) => current === 'asc' ? 'desc' : 'asc');
      return;
    }
    setSortKey(key);
    setSortDirection('asc');
  };

  const SortableHeader = ({ label, sortBy }: { label: string; sortBy: PosSortKey }) => (
    <Button type="button" variant="ghost" size="sm" onClick={() => handleSort(sortBy)} className="h-auto px-0 py-0 font-semibold text-secondary-foreground hover:bg-transparent">
      {label}
      <ArrowUpDown className="ml-2 h-3.5 w-3.5" />
    </Button>
  );

  const openDialog = (nextMode: TicketMode, record?: POSDATA): void => {
    setMode(nextMode);
    setSelectedRecord(record);
    setForm(nextMode === 'add' ? createEmptyForm() : toFormState(record));
    setDialogOpen(true);
  };

  const onFormChange = (field: keyof PosFormState, value: string): void => setForm((current: PosFormState) => {
    const next = { ...current, [field]: value };
    const computedAge = calculateTicketAgeDays(next.dateReported, next.status, next.dateResolved);
    return { ...next, age: String(computedAge), ticketage: formatTicketAge(next.dateReported, next.status, next.dateResolved) };
  });

  const onSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    if (!form.branch.trim() || !form.tID.trim() || !form.issue.trim() || !form.dateReported.trim()) {
      toast.error('Branch, TID, Issue, and Date Reported are required.');
      return;
    }
    if (mode === 'edit' && selectedRecord) {
      updateTicket.mutate({ id: selectedRecord.id, changedFields: toPayload(form) }, { onSuccess: () => { toast.success('POS ticket updated.'); setDialogOpen(false); }, onError: () => toast.error('Unable to update POS ticket.') });
      return;
    }
    createTicket.mutate(toPayload(form), { onSuccess: () => { toast.success('POS ticket created.'); setDialogOpen(false); }, onError: () => toast.error('Unable to create POS ticket.') });
  };

  const onDelete = (record: POSDATA): void => {
    const ticketLabel = record.ticketIDNumber ?? record.tID ?? record.pOS ?? record.id;
    deleteTicket.mutate(record.id, {
      onSuccess: () => toast.success(`POS ticket ${ticketLabel} deleted.`),
      onError: () => toast.error('Unable to delete POS ticket.'),
    });
  };

  return (
    <div className="space-y-4 transition-opacity duration-200 sm:space-y-6">
      <section className="grid gap-3 sm:grid-cols-2 sm:gap-4 xl:grid-cols-4"><KpiCard title="Open Tickets" value={String(openCount)} icon={Clock} /><KpiCard title="In Progress" value={String(inProgressCount)} icon={Wrench} /><KpiCard title="Resolved Tickets" value={String(resolvedCount)} icon={CheckCircle2} /><KpiCard title="High Priority" value={String(criticalCount)} icon={Bell} alert /></section>
      <Card>
        <CardHeader className="gap-4 p-4 sm:p-6">
          <div className="flex flex-row items-start justify-between gap-3">
            <div className="min-w-0 flex-1 space-y-1">
              <CardTitle className="text-xl sm:text-2xl">POS Ticket Monitoring</CardTitle>
              <CardDescription className="max-w-2xl">Live POS-DATA support queue with touch-friendly controls for field updates.</CardDescription>
            </div>
            <Button className="min-h-11 shrink-0 px-3 sm:px-4" onClick={() => openDialog('add')}><Plus className="h-4 w-4 sm:mr-2" /><span className="sr-only sm:not-sr-only">Add Ticket</span></Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 p-4 pt-0 sm:p-6 sm:pt-0">
          <div className="flex flex-col gap-3 rounded-2xl border border-card-outline bg-secondary p-3 text-secondary-foreground sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-1">
              <p className="text-sm font-semibold">Ticket queue</p>
              <p className="text-xs text-secondary-foreground">Filter current POS incidents by status.</p>
            </div>
            <div className="w-full sm:max-w-xs">
            <Select value={statusFilter} onValueChange={(value: string) => setStatusFilter(value)}>
              <SelectTrigger className="min-h-11" aria-label="Filter POS tickets by status"><SelectValue placeholder="Filter by status" /></SelectTrigger>
              <SelectContent>
                {statusFilterOptions.filter((status: string) => status).map((status: string) => <SelectItem key={status} value={status}>{status === 'all' ? 'All Statuses' : status}</SelectItem>)}
              </SelectContent>
            </Select>
            </div>
          </div>
          <div className="grid gap-3 lg:hidden">
            {isLoading && posData.length === 0 && <div className="rounded-2xl border border-card-outline bg-card p-4 text-center text-sm text-muted-foreground">Loading POS-DATA tickets...</div>}
            {!isLoading && filteredAndSortedPosData.length === 0 && <div className="rounded-2xl border border-card-outline bg-card p-4 text-center text-sm text-muted-foreground">No POS-DATA tickets found.</div>}
            {filteredAndSortedPosData.map((record: POSDATA) => (
              <article key={record.id} className="rounded-2xl border border-card-outline bg-card p-4 text-card-foreground shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1">
                    <p className="text-sm font-semibold">{record.branch || 'Not set'}</p>
                    <p className="text-xs text-muted-foreground">TID {record.tID ?? record.ticketIDNumber ?? record.pOS}</p>
                  </div>
                  <Badge variant="secondary" className={statusBadgeClass(record.status ?? 'Open')}>{record.status || 'Open'}</Badge>
                </div>
                <div className="mt-3 space-y-2 text-sm">
                  <p className="font-medium">{record.issue || record.issueCategoryKey || 'Not set'}</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <span className="rounded-xl bg-secondary p-2 text-secondary-foreground">Reported<br /><strong>{formatPosDate(record.dateReported)}</strong></span>
                    <span className="rounded-xl bg-secondary p-2 text-secondary-foreground">Age<br /><strong>{formatTicketAge(record.dateReported ?? '', record.status ?? 'Open', record.dateResolved ?? '')}</strong></span>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <Button variant="outline" size="sm" className="min-h-11" aria-label="View POS ticket" onClick={() => openDialog('view', record)}><Eye className="mr-1 h-3.5 w-3.5" />View</Button>
                  <Button variant="outline" size="sm" className="min-h-11" aria-label="Edit POS ticket" onClick={() => openDialog('edit', record)}><Pencil className="mr-1 h-3.5 w-3.5" />Edit</Button>
                  <Button variant="destructive" size="sm" className="min-h-11" aria-label="Delete POS ticket" disabled={deleteTicket.isPending} onClick={() => onDelete(record)}><Trash2 className="mr-1 h-3.5 w-3.5" />Delete</Button>
                </div>
              </article>
            ))}
          </div>
          <div className="hidden overflow-hidden rounded-2xl border border-card-outline lg:block"><Table><TableHeader className="bg-secondary text-secondary-foreground"><TableRow className="hover:bg-secondary"><TableHead>Controls</TableHead><TableHead><SortableHeader label="Branch" sortBy="branch" /></TableHead><TableHead><SortableHeader label="TID" sortBy="tID" /></TableHead><TableHead><SortableHeader label="Issue" sortBy="issue" /></TableHead><TableHead><SortableHeader label="Date Reported" sortBy="dateReported" /></TableHead><TableHead><SortableHeader label="Status" sortBy="status" /></TableHead></TableRow></TableHeader><TableBody>{isLoading && posData.length === 0 && <TableRow><TableCell colSpan={6} className="py-8 text-center text-muted-foreground">Loading POS-DATA tickets...</TableCell></TableRow>}{!isLoading && filteredAndSortedPosData.length === 0 && <TableRow><TableCell colSpan={6} className="py-8 text-center text-muted-foreground">No POS-DATA tickets found.</TableCell></TableRow>}{filteredAndSortedPosData.map((record: POSDATA) => <TableRow key={record.id} className="hover:bg-secondary"><TableCell><div className="flex flex-wrap gap-2"><Button variant="outline" size="icon-sm" aria-label="View POS ticket" onClick={() => openDialog('view', record)}><Eye className="h-3.5 w-3.5" /></Button><Button variant="outline" size="icon-sm" aria-label="Edit POS ticket" onClick={() => openDialog('edit', record)}><Pencil className="h-3.5 w-3.5" /></Button><Button variant="destructive" size="icon-sm" aria-label="Delete POS ticket" disabled={deleteTicket.isPending} onClick={() => onDelete(record)}><Trash2 className="h-3.5 w-3.5" /></Button></div></TableCell><TableCell>{record.branch || 'Not set'}</TableCell><TableCell className="font-medium">{record.tID ?? record.ticketIDNumber ?? record.pOS}</TableCell><TableCell>{record.issue || record.issueCategoryKey || 'Not set'}</TableCell><TableCell>{formatPosDate(record.dateReported)}</TableCell><TableCell><Badge variant="secondary" className={statusBadgeClass(record.status ?? 'Open')}>{record.status || 'Open'}</Badge></TableCell></TableRow>)}</TableBody></Table></div>
        </CardContent>
      </Card>
      <PosTicketDialog mode={mode} open={dialogOpen} form={form} onOpenChange={setDialogOpen} onFormChange={onFormChange} onSubmit={onSubmit} onSwitchToEdit={() => setMode('edit')} />
    </div>
  );
}

function InventoryWorkspace() {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<InventoryFilter>('all');
  const [modelFilter, setModelFilter] = useState('all');
  const [branchFilter, setBranchFilter] = useState('all');
  const normalizedQuery = query.trim().toLowerCase();
  const branches = useMemo<string[]>(() => Array.from(new Set(inventoryDevices.map((device: InventoryDevice) => device.branch))).sort((first: string, second: string) => first.localeCompare(second)), []);
  const models = useMemo<string[]>(() => Array.from(new Set(inventoryDevices.map((device: InventoryDevice) => device.model))).sort((first: string, second: string) => first.localeCompare(second)), []);
  const filteredDevices = useMemo<InventoryDevice[]>(() => inventoryDevices.filter((device: InventoryDevice) => {
    const matchesQuery = !normalizedQuery || `${device.assetTag} ${device.serialNumber} ${device.model} ${device.branch} ${device.lane} ${device.owner}`.toLowerCase().includes(normalizedQuery);
    const matchesStatus = statusFilter === 'all' || device.status === statusFilter;
    const matchesModel = modelFilter === 'all' || device.model === modelFilter;
    const matchesBranch = branchFilter === 'all' || device.branch === branchFilter;
    return matchesQuery && matchesStatus && matchesModel && matchesBranch;
  }), [branchFilter, modelFilter, normalizedQuery, statusFilter]);
  const activeCount = inventoryDevices.filter((device: InventoryDevice) => device.status === 'Active').length;
  const repairCount = inventoryDevices.filter((device: InventoryDevice) => device.status === 'In Repair').length;
  const attentionCount = inventoryDevices.filter((device: InventoryDevice) => device.status === 'Needs Replacement' || device.status === 'In Repair').length;
  const averageHealth = inventoryDevices.length > 0 ? Math.round(inventoryDevices.reduce((total: number, device: InventoryDevice) => total + device.health, 0) / inventoryDevices.length) : 0;
  const clearFilters = (): void => { setQuery(''); setStatusFilter('all'); setModelFilter('all'); setBranchFilter('all'); };
  const viewAsset = (device: InventoryDevice): void => {
    toast.info(`${device.assetTag} assigned to ${device.branch} ${device.lane}.`);
  };
  return (
    <div className="space-y-6 transition-opacity duration-200">
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <KpiCard title="Total POS Devices" value={String(inventoryDevices.length)} icon={Package} />
        <KpiCard title="Active Devices" value={String(activeCount)} icon={CheckCircle2} />
        <KpiCard title="Needs Attention" value={String(attentionCount)} icon={Wrench} alert />
        <KpiCard title="Avg Device Health" value={`${averageHealth}%`} icon={ShieldCheck} />
      </section>
      <section className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
        <Card className="border-l-4 border-l-primary">
          <CardHeader>
            <CardTitle>Inventory Readiness</CardTitle>
            <CardDescription>Device availability and repair exposure across branches.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-2xl bg-secondary p-4 text-secondary-foreground">
              <div className="flex items-center justify-between gap-3"><span className="text-sm font-semibold">Active coverage</span><span className="text-2xl font-bold">{inventoryDevices.length > 0 ? Math.round((activeCount / inventoryDevices.length) * 100) : 0}%</span></div>
              <Progress value={inventoryDevices.length > 0 ? Math.round((activeCount / inventoryDevices.length) * 100) : 0} className="mt-3" />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-card-outline bg-card p-4 text-card-foreground"><p className="text-sm font-semibold">Repair queue</p><p className="mt-2 text-2xl font-bold">{repairCount}</p><p className="text-xs text-muted-foreground">Devices currently with field support</p></div>
              <div className="rounded-2xl border border-card-outline bg-card p-4 text-card-foreground"><p className="text-sm font-semibold">Filtered result</p><p className="mt-2 text-2xl font-bold">{filteredDevices.length}</p><p className="text-xs text-muted-foreground">Matching inventory records</p></div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Priority Assets</CardTitle>
            <CardDescription>Lowest-health devices that may require replacement planning.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2">
            {[...inventoryDevices].sort((first: InventoryDevice, second: InventoryDevice) => first.health - second.health).slice(0, 4).map((device: InventoryDevice) => (
              <button key={device.assetTag} type="button" onClick={() => viewAsset(device)} className="rounded-2xl border border-card-outline bg-card p-4 text-left text-card-foreground transition-all hover:-translate-y-0.5 hover:bg-secondary hover:text-secondary-foreground hover:shadow-md">
                <div className="flex items-start justify-between gap-3"><span className="font-semibold">{device.assetTag}</span><Badge variant="secondary" className={statusBadgeClass(device.status)}>{device.status}</Badge></div>
                <p className="mt-2 text-sm text-muted-foreground">{device.branch} · {device.lane}</p>
                <div className="mt-3 flex items-center gap-3"><Progress value={device.health} className="h-2" /><span className="text-sm font-semibold">{device.health}%</span></div>
              </button>
            ))}
          </CardContent>
        </Card>
      </section>
      <Card>
        <CardHeader>
          <div className="flex flex-col justify-between gap-3 lg:flex-row lg:items-start">
            <div><CardTitle>Inventory Workspace</CardTitle><CardDescription>Filter POS assets by branch, model, status, and device identifiers.</CardDescription></div>
            <Button variant="outline" onClick={clearFilters}>Reset Filters</Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 lg:grid-cols-[1fr_180px_220px_180px]">
            <div className="flex items-center rounded-2xl border border-input bg-background px-3"><Search className="h-4 w-4 text-muted-foreground" /><Input aria-label="Search inventory" value={query} onChange={(event: ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)} placeholder="Search asset, serial, branch, lane, or owner" className="border-0 bg-transparent shadow-none focus-visible:ring-0" /></div>
            <Select value={branchFilter} onValueChange={(value: string) => setBranchFilter(value)}><SelectTrigger><SelectValue placeholder="Branch" /></SelectTrigger><SelectContent><SelectItem value="all">All Branches</SelectItem>{branches.filter((branch: string) => branch).map((branch: string) => <SelectItem key={branch} value={branch}>{branch}</SelectItem>)}</SelectContent></Select>
            <Select value={modelFilter} onValueChange={(value: string) => setModelFilter(value)}><SelectTrigger><SelectValue placeholder="Model" /></SelectTrigger><SelectContent><SelectItem value="all">All Models</SelectItem>{models.filter((model: string) => model).map((model: string) => <SelectItem key={model} value={model}>{model}</SelectItem>)}</SelectContent></Select>
            <Select value={statusFilter} onValueChange={(value: string) => setStatusFilter(value as InventoryFilter)}><SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="all">All Statuses</SelectItem>{(['Active', 'In Repair', 'Retired', 'Needs Replacement'] as InventoryStatus[]).filter((status: InventoryStatus) => status).map((status: InventoryStatus) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select>
          </div>
          <div className="grid gap-3 lg:hidden">
            {filteredDevices.map((device: InventoryDevice) => (
              <article key={device.assetTag} className="rounded-2xl border border-card-outline bg-card p-4 text-card-foreground shadow-sm">
                <div className="flex items-start justify-between gap-3"><div><p className="font-semibold">{device.assetTag}</p><p className="text-sm text-muted-foreground">{device.serialNumber}</p></div><Badge variant="secondary" className={statusBadgeClass(device.status)}>{device.status}</Badge></div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-sm"><span className="rounded-xl bg-secondary p-2 text-secondary-foreground">Model<br /><strong>{device.model}</strong></span><span className="rounded-xl bg-secondary p-2 text-secondary-foreground">Health<br /><strong>{device.health}%</strong></span><span className="rounded-xl bg-secondary p-2 text-secondary-foreground">Branch<br /><strong>{device.branch}</strong></span><span className="rounded-xl bg-secondary p-2 text-secondary-foreground">Lane<br /><strong>{device.lane}</strong></span></div>
                <Button variant="outline" size="sm" className="mt-4 w-full" onClick={() => viewAsset(device)}><Eye className="mr-2 h-4 w-4" />View asset</Button>
              </article>
            ))}
          </div>
          <div className="hidden overflow-hidden rounded-2xl border border-card-outline lg:block">
            <Table><TableHeader className="bg-secondary text-secondary-foreground"><TableRow className="hover:bg-secondary"><TableHead>Asset Tag</TableHead><TableHead>Serial Number</TableHead><TableHead>Model</TableHead><TableHead>Branch / Lane</TableHead><TableHead>Status</TableHead><TableHead>Health</TableHead><TableHead>Warranty</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader><TableBody>{filteredDevices.map((device: InventoryDevice) => <TableRow key={device.assetTag} className="hover:bg-secondary"><TableCell className="font-medium">{device.assetTag}</TableCell><TableCell>{device.serialNumber}</TableCell><TableCell>{device.model}</TableCell><TableCell><div className="font-medium">{device.branch}</div><div className="text-xs text-muted-foreground">{device.lane}</div></TableCell><TableCell><Badge variant="secondary" className={statusBadgeClass(device.status)}>{device.status}</Badge></TableCell><TableCell><div className="flex min-w-32 items-center gap-2"><Progress value={device.health} className="h-2" /><span className="text-sm font-semibold">{device.health}%</span></div></TableCell><TableCell>{formatPosDate(device.warrantyExpiry)}</TableCell><TableCell><Button variant="outline" size="sm" onClick={() => viewAsset(device)}><Eye className="mr-2 h-4 w-4" />View</Button></TableCell></TableRow>)}</TableBody></Table>
          </div>
          {filteredDevices.length === 0 && <div className="rounded-2xl border border-card-outline bg-card p-6 text-center text-sm text-muted-foreground">No POS inventory assets match the selected filters.</div>}
        </CardContent>
      </Card>
    </div>
  );
}

function DeploymentsWorkspace() {
  return <div className="space-y-6 transition-opacity duration-200"><section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4"><KpiCard title="Scheduled" value="14" icon={Clock} /><KpiCard title="In Progress" value="8" icon={Truck} /><KpiCard title="Completed" value="42" icon={CheckCircle2} /><KpiCard title="Delayed" value="3" icon={Wrench} alert /></section><Card><CardHeader><CardTitle>Deployment Workspace</CardTitle><CardDescription>Mock branch deployment tracking and installation schedule prepared for future Dataverse integration.</CardDescription></CardHeader><CardContent className="space-y-4"><div className="grid gap-3 lg:grid-cols-[1fr_180px_180px_220px]"><div className="flex items-center rounded-2xl border border-input bg-background px-3"><Search className="h-4 w-4 text-muted-foreground" /><Input aria-label="Search deployments" placeholder="Search deployment, branch, or technician" className="border-0 bg-transparent shadow-none focus-visible:ring-0" /></div><Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Branch" /></SelectTrigger><SelectContent><SelectItem value="all">All Branches</SelectItem><SelectItem value="main">Main Branch</SelectItem><SelectItem value="north">North Branch</SelectItem></SelectContent></Select><Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="all">All Statuses</SelectItem><SelectItem value="scheduled">Scheduled</SelectItem><SelectItem value="progress">In Progress</SelectItem><SelectItem value="completed">Completed</SelectItem><SelectItem value="delayed">Delayed</SelectItem></SelectContent></Select><Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Assigned Technician" /></SelectTrigger><SelectContent><SelectItem value="all">All Technicians</SelectItem><SelectItem value="santos">R. Santos</SelectItem><SelectItem value="cruz">M. Cruz</SelectItem></SelectContent></Select></div><div className="overflow-hidden rounded-2xl border border-card-outline"><Table><TableHeader className="bg-secondary text-secondary-foreground"><TableRow className="hover:bg-secondary"><TableHead>Deployment ID</TableHead><TableHead>Branch</TableHead><TableHead>Device Model</TableHead><TableHead>Assigned Technician</TableHead><TableHead>Scheduled Date</TableHead><TableHead>Installation Date</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader><TableBody>{deployments.map((deployment: DeploymentRecord) => <TableRow key={deployment.deploymentId} className="hover:bg-secondary"><TableCell className="font-medium">{deployment.deploymentId}</TableCell><TableCell>{deployment.branch}</TableCell><TableCell>{deployment.deviceModel}</TableCell><TableCell>{deployment.assignedTechnician}</TableCell><TableCell>{deployment.scheduledDate}</TableCell><TableCell>{deployment.installationDate}</TableCell><TableCell><Badge variant="secondary" className={statusBadgeClass(deployment.status)}>{deployment.status}</Badge></TableCell><TableCell><Button variant="outline" size="sm">View</Button></TableCell></TableRow>)}</TableBody></Table></div></CardContent></Card></div>;
}

function PosModulePage() {
  const [activeTab, setActiveTab] = useState<PosTab>('monitoring');
  return <div className="space-y-4 sm:space-y-6"><header className="flex flex-col gap-4 rounded-2xl border border-card-outline bg-card p-4 text-card-foreground shadow-card sm:p-6 lg:flex-row lg:items-center lg:justify-between"><div className="space-y-2 sm:space-y-3"><nav aria-label="Breadcrumb" className="text-xs font-medium text-muted-foreground sm:text-sm">Access / BPM Support Portal</nav><h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">POS Module</h2></div><div className="flex items-center gap-3"><Button variant="outline" size="icon" aria-label="Notifications" className="rounded-full"><Bell className="h-4 w-4" /></Button><div className="flex min-h-12 flex-1 items-center gap-3 rounded-2xl border border-card-outline bg-secondary px-3 py-2 text-secondary-foreground sm:flex-none"><Avatar className="h-9 w-9"><AvatarFallback className="bg-primary text-primary-foreground">BP</AvatarFallback></Avatar><div className="min-w-0 leading-tight"><p className="truncate text-sm font-semibold">BSP User</p><p className="text-xs text-muted-foreground">Service desk</p></div></div></div></header><PosTabs activeTab={activeTab} setActiveTab={setActiveTab} />{activeTab === 'monitoring' && <PosMonitoringWorkspace />}{activeTab === 'inventory' && <InventoryWorkspace />}{activeTab === 'deployments' && <DeploymentsWorkspace />}</div>;
}

function GenericModulePage({ module }: { module: ModuleInfo }) {
  const Icon = module.icon;
  const moduleRecords = records.filter((record: OperationalRecord) => record.module === module.name);
  return <div className="space-y-6"><header className="flex flex-col gap-4 rounded-2xl border border-card-outline bg-card p-6 text-card-foreground shadow-card lg:flex-row lg:items-center lg:justify-between"><div className="space-y-3"><nav aria-label="Breadcrumb" className="text-sm font-medium text-muted-foreground">Access / BPM Support Portal / Modules</nav><div className="flex items-center gap-4"><span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Icon className="h-7 w-7" /></span><div><h2 className="text-3xl font-semibold tracking-tight">{module.name} Module</h2><p className="text-sm text-muted-foreground">{module.owner} service workspace</p></div></div></div><div className="flex items-center gap-3"><Button variant="outline" size="icon" aria-label="Notifications" className="rounded-full"><Bell className="h-4 w-4" /></Button><Avatar className="h-10 w-10"><AvatarFallback className="bg-primary text-primary-foreground">BP</AvatarFallback></Avatar></div></header><Card><CardHeader><CardTitle>{module.name} Request Queue</CardTitle><CardDescription>Generic operational page for tracking {module.name} requests, ownership, priority, and status.</CardDescription></CardHeader><CardContent><div className="overflow-hidden rounded-2xl border border-card-outline"><Table><TableHeader className="bg-secondary text-secondary-foreground"><TableRow className="hover:bg-secondary"><TableHead>Ticket</TableHead><TableHead>Requestor</TableHead><TableHead>Assigned To</TableHead><TableHead>Status</TableHead><TableHead>Priority</TableHead><TableHead>Due Date</TableHead></TableRow></TableHeader><TableBody>{moduleRecords.map((record: OperationalRecord) => <TableRow key={record.ticketNo} className="hover:bg-secondary"><TableCell className="font-medium">{record.ticketNo}</TableCell><TableCell>{record.requestor}</TableCell><TableCell>{record.assignedTo}</TableCell><TableCell><Badge variant="secondary" className={statusBadgeClass(record.status)}>{record.status}</Badge></TableCell><TableCell><Badge variant={record.priority === 'High' || record.priority === 'Critical' ? 'destructive' : 'secondary'}>{record.priority}</Badge></TableCell><TableCell>{record.dueDate}</TableCell></TableRow>)}</TableBody></Table></div></CardContent></Card></div>;
}

export default function ModuleDetailPage() {
  const { moduleId } = useParams();
  const module = modules.find((item: ModuleInfo) => item.path.endsWith(`/${moduleId ?? ''}`)) ?? modules[0];
  if (module.path === '/modules/pos') return <PosModulePage />;
  if (module.path === '/modules/mms') return <MmsPasswordResetPage />;
  return <GenericModulePage module={module} />;
}
