import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { modules } from '@/lib/mock-data';
import type { ModuleInfo } from '@/lib/mock-data';

export default function ModulesPage() {
  return <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{modules.map((module: ModuleInfo) => { const Icon = module.icon; return <Card key={module.name}><CardHeader><div className="flex items-center gap-3"><span className="rounded-lg bg-primary p-2 text-primary-foreground"><Icon className="h-5 w-5" /></span><div><CardTitle>{module.name}</CardTitle><CardDescription>{module.owner}</CardDescription></div></div></CardHeader><CardContent><Button asChild variant="outline"><Link to={module.path}>Open module</Link></Button></CardContent></Card>; })}</div>;
}
