import { Bell, Eye, PackageCheck, PackageSearch, Search, ShieldCheck, Wrench } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';

 type PosInventoryItem = { assetTag: string; serialNumber: string; model: string; branch: string; status: string; warrantyExpiry: string; lastUpdated: string; owner: string };

const inventoryItems: PosInventoryItem[] = [
  { assetTag: 'POS-1001', serialNumber: 'SN-POS-77821', model: 'Verifone X990', branch: 'SM San Lazaro', status: 'Active', warrantyExpiry: '2027-03-18', lastUpdated: '2026-08-08', owner: 'Store Systems' },
  { assetTag: 'POS-1002', serialNumber: 'SN-POS-77822', model: 'PAX A920', branch: 'SM North EDSA', status: 'In Repair', warrantyExpiry: '2026-12-05', lastUpdated: '2026-08-07', owner: 'Field Support' },
  { assetTag: 'POS-1003', serialNumber: 'SN-POS-77823', model: 'Ingenico Move 5000', branch: 'Head Office BPM', status: 'Active', warrantyExpiry: '2028-01-22', lastUpdated: '2026-08-06', owner: 'Store Systems' },
  { assetTag: 'POS-1004', serialNumber: 'SN-POS-77824', model: 'Verifone VX520', branch: 'SM San Lazaro', status: 'Retired', warrantyExpiry: '2025-09-14', lastUpdated: '2026-08-05', owner: 'Asset Control' },
];

const statusClass = (status: string): string => {
  if (status === 'Active') return 'bg-primary text-primary-foreground';
  if (status === 'In Repair') return 'bg-accent text-accent-foreground';
  return 'bg-secondary text-secondary-foreground';
};

export default function PosInventoryPage() {
  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-4 rounded-2xl border border-card-outline bg-card p-6 text-card-foreground shadow-card lg:flex-row lg:items-center lg:justify-between">
        <div className="space-y-3">
          <nav aria-label="Breadcrumb" className="text-sm font-medium text-muted-foreground">Access / BPM Support Portal</nav>
          <h2 className="text-3xl font-semibold tracking-tight">POS Inventory</h2>
          <p className="text-sm text-muted-foreground">Asset inventory management for POS devices and branch assignment records.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" aria-label="Notifications" className="rounded-full"><Bell className="h-4 w-4" /></Button>
          <Avatar className="h-10 w-10"><AvatarFallback className="bg-primary text-primary-foreground">BP</AvatarFallback></Avatar>
        </div>
      </header>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {[{ title: 'Total POS Devices', value: '248', icon: PackageSearch }, { title: 'Active Devices', value: '213', icon: ShieldCheck }, { title: 'In Repair', value: '21', icon: Wrench }, { title: 'Retired Devices', value: '14', icon: PackageCheck }].map((card: { title: string; value: string; icon: typeof PackageSearch }) => {
          const Icon = card.icon;
          return <Card key={card.title} className="border-l-4 border-l-primary"><CardContent className="flex items-center gap-4 p-5"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Icon className="h-6 w-6" /></span><div><p className="text-sm text-muted-foreground">{card.title}</p><p className="text-2xl font-semibold">{card.value}</p></div></CardContent></Card>;
        })}
      </section>

      <Card>
        <CardHeader>
          <CardTitle>POS Device Data</CardTitle>
          <CardDescription>Mock asset information prepared for future Dataverse inventory integration.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 lg:grid-cols-[1fr_180px_180px_180px]">
            <div className="flex items-center rounded-2xl border border-input bg-background px-3"><Search className="h-4 w-4 text-muted-foreground" /><Input placeholder="Inventory Search" className="border-0 bg-transparent shadow-none focus-visible:ring-0" /></div>
            <Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Branch" /></SelectTrigger><SelectContent><SelectItem value="all">All Branches</SelectItem><SelectItem value="ssl">SM San Lazaro</SelectItem><SelectItem value="sne">SM North EDSA</SelectItem></SelectContent></Select>
            <Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="all">All Statuses</SelectItem><SelectItem value="active">Active</SelectItem><SelectItem value="repair">In Repair</SelectItem><SelectItem value="retired">Retired</SelectItem></SelectContent></Select>
            <Select defaultValue="all"><SelectTrigger><SelectValue placeholder="Model" /></SelectTrigger><SelectContent><SelectItem value="all">All Models</SelectItem><SelectItem value="verifone">Verifone</SelectItem><SelectItem value="pax">PAX</SelectItem></SelectContent></Select>
          </div>
          <div className="overflow-hidden rounded-2xl border border-card-outline">
            <Table>
              <TableHeader className="bg-secondary text-secondary-foreground"><TableRow className="hover:bg-secondary"><TableHead>Asset Tag</TableHead><TableHead>Serial Number</TableHead><TableHead>Model</TableHead><TableHead>Branch</TableHead><TableHead>Status</TableHead><TableHead>Warranty Expiry</TableHead><TableHead>Last Updated</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
              <TableBody>{inventoryItems.map((item: PosInventoryItem) => <TableRow key={item.assetTag}><TableCell className="font-medium">{item.assetTag}</TableCell><TableCell>{item.serialNumber}</TableCell><TableCell>{item.model}</TableCell><TableCell>{item.branch}</TableCell><TableCell><Badge variant="secondary" className={statusClass(item.status)}>{item.status}</Badge></TableCell><TableCell>{item.warrantyExpiry}</TableCell><TableCell>{item.lastUpdated}</TableCell><TableCell><Button variant="ghost" size="sm" onClick={() => toast.info(`Viewing asset ${item.assetTag}`)}><Eye className="h-4 w-4" />View</Button></TableCell></TableRow>)}</TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
