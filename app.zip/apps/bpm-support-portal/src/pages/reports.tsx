import { useMemo, useState } from 'react';
import { addDays, format } from 'date-fns';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, XAxis, YAxis } from 'recharts';
import {
  Activity,
  BarChart3,
  BriefcaseBusiness,
  CalendarIcon,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  FileText,
  FolderKanban,
  MonitorCog,
  Printer,
  ShieldCheck,
  TicketCheck,
  RotateCcw,
  SearchX,
  TimerOff,
} from 'lucide-react';
import { toast } from 'sonner';

import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TicketDetailDrawer } from '@/components/ticket-detail-drawer';
import { useAuthSession } from '@/hooks/use-auth-session';
import type { BspRole } from '@/lib/auth-access';
import { cn } from '@/lib/utils';
import type { DateRange } from 'react-day-picker';
import type { OperationalRecord } from '@/lib/mock-data';

type FilterState = {
  branch: string;
  region: string;
  category: string;
  status: string;
  priority: string;
  technician: string;
  project: string;
};

type KpiCard = {
  label: string;
  value: string;
  change: string;
  icon: typeof BarChart3;
};

type ReportAccess = {
  scope: string;
  detail: string;
};

const filterOptions = {
  branches: ['SM San Lazaro', 'SM North EDSA', 'SM Megamall', 'Head Office BPM'],
  regions: ['Metro Manila', 'North Luzon', 'South Luzon', 'Visayas', 'Mindanao'],
  categories: ['POS', 'Network', 'CCTV', 'Hardware', 'Microsoft 365', 'Others'],
  statuses: ['Open', 'In Progress', 'Closed', 'Overdue', 'Delayed'],
  priorities: ['Low', 'Medium', 'High', 'Critical'],
  technicians: ['Allan Reyes', 'Bianca Cruz', 'Carlo Lim', 'Dina Ramos'],
  projects: ['Branch refresh', 'POS upgrade', 'CCTV rollout', 'M365 hardening'],
};

const kpiCards: KpiCard[] = [
  { label: 'Open Tickets', value: '248', change: '+12 this week', icon: Activity },
  { label: 'Closed Tickets', value: '1,428', change: '92% closure rate', icon: TicketCheck },
  { label: 'Overdue Tickets', value: '19', change: '-8 vs last month', icon: TimerOff },
  { label: 'SLA Compliance', value: '96.4%', change: '+2.1 pts', icon: ShieldCheck },
  { label: 'Active Assets', value: '3,846', change: '128 expiring warranty', icon: MonitorCog },
  { label: 'Open Projects', value: '37', change: '6 at risk', icon: FolderKanban },
];

const ticketTrendData = [
  { period: 'Aug 1', daily: 34, weekly: 210, monthly: 812 },
  { period: 'Aug 2', daily: 41, weekly: 224, monthly: 839 },
  { period: 'Aug 3', daily: 28, weekly: 236, monthly: 866 },
  { period: 'Aug 4', daily: 52, weekly: 248, monthly: 904 },
  { period: 'Aug 5', daily: 46, weekly: 259, monthly: 930 },
  { period: 'Aug 6', daily: 57, weekly: 271, monthly: 971 },
];

const ticketCategoryData = [
  { name: 'POS', value: 326, fill: 'var(--chart-1)' },
  { name: 'Network', value: 288, fill: 'var(--chart-2)' },
  { name: 'CCTV', value: 181, fill: 'var(--chart-3)' },
  { name: 'Hardware', value: 242, fill: 'var(--chart-4)' },
  { name: 'Microsoft 365', value: 197, fill: 'var(--chart-5)' },
  { name: 'Others', value: 104, fill: 'var(--muted-foreground)' },
];

const branchDistributionData = [
  { branch: 'San Lazaro', tickets: 132 },
  { branch: 'North EDSA', tickets: 118 },
  { branch: 'Megamall', tickets: 107 },
  { branch: 'Cebu', tickets: 96 },
  { branch: 'Davao', tickets: 84 },
  { branch: 'Baguio', tickets: 73 },
  { branch: 'Fairview', tickets: 69 },
  { branch: 'Bacolod', tickets: 61 },
  { branch: 'Iloilo', tickets: 58 },
  { branch: 'Pampanga', tickets: 54 },
];

const technicianWorkloadData = [
  { technician: 'Allan', assigned: 42, closed: 31 },
  { technician: 'Bianca', assigned: 38, closed: 35 },
  { technician: 'Carlo', assigned: 45, closed: 29 },
  { technician: 'Dina', assigned: 33, closed: 28 },
];

const assetStatusData = [
  { name: 'Active', value: 2840, fill: 'var(--chart-1)' },
  { name: 'For Repair', value: 218, fill: 'var(--chart-5)' },
  { name: 'Warranty', value: 412, fill: 'var(--chart-2)' },
  { name: 'Retired', value: 376, fill: 'var(--chart-4)' },
];

const projectStatusData = [
  { status: 'Active', projects: 21 },
  { status: 'Delayed', projects: 6 },
  { status: 'Budget review', projects: 4 },
  { status: 'Completed', projects: 18 },
];

const supportReports = ['Open Tickets', 'Closed Tickets', 'Average Resolution Time', 'SLA Compliance'];
const assetReports = ['Asset Inventory', 'Warranty Status', 'Asset Assignment'];
const reportTickets: (OperationalRecord & { summary: string; sla: string })[] = [
  { ticketNo: 'BPM-240801', module: 'POS', requestor: 'SM San Lazaro', assignedTo: 'Allan Reyes', status: 'Open', priority: 'High', dueDate: 'Aug 05', progress: 34, branchId: 'SM San Lazaro', createdBy: 'branch.ops@example.com', modifiedBy: 'allan.reyes@example.com', modifiedDate: 'Aug 04, 10:20', summary: 'POS receipt printer not responding', sla: 'Tracking' },
  { ticketNo: 'BPM-240802', module: 'Network', requestor: 'SM North EDSA', assignedTo: 'Bianca Cruz', status: 'In Progress', priority: 'Critical', dueDate: 'Aug 04', progress: 68, branchId: 'SM North EDSA', createdBy: 'store.admin@example.com', modifiedBy: 'bianca.cruz@example.com', modifiedDate: 'Aug 04, 11:35', summary: 'Network outage affecting cashier lanes', sla: 'Escalated' },
  { ticketNo: 'BPM-240803', module: 'CCTV', requestor: 'SM Megamall', assignedTo: 'Carlo Lim', status: 'Needs Attention', priority: 'Normal', dueDate: 'Aug 06', progress: 52, branchId: 'SM Megamall', createdBy: 'security.ops@example.com', modifiedBy: 'carlo.lim@example.com', modifiedDate: 'Aug 04, 12:05', summary: 'CCTV playback export request', sla: 'Tracking' },
  { ticketNo: 'BPM-240804', module: 'Hardware', requestor: 'Head Office BPM', assignedTo: 'Dina Ramos', status: 'Resolved', priority: 'Low', dueDate: 'Aug 03', progress: 100, branchId: 'Head Office BPM', createdBy: 'asset.team@example.com', modifiedBy: 'dina.ramos@example.com', modifiedDate: 'Aug 03, 16:30', summary: 'Laptop warranty validation', sla: 'Met' },
];
const projectReports = ['Active Projects', 'Delayed Projects', 'Budget Monitoring'];

const chartConfig = {
  daily: { label: 'Daily', color: 'var(--chart-1)' },
  weekly: { label: 'Weekly', color: 'var(--chart-2)' },
  monthly: { label: 'Monthly', color: 'var(--chart-3)' },
  tickets: { label: 'Tickets', color: 'var(--chart-1)' },
  assigned: { label: 'Assigned', color: 'var(--chart-1)' },
  closed: { label: 'Closed', color: 'var(--chart-2)' },
  projects: { label: 'Projects', color: 'var(--chart-1)' },
} satisfies ChartConfig;

function getReportAccess(role: BspRole | undefined): ReportAccess {
  if (role === 'Branch User') return { scope: 'Own branch reports', detail: 'Branch security applies: User.BranchID = Ticket.BranchID.' };
  if (role === 'Technician') return { scope: 'Assigned ticket reports', detail: 'Technician workload and assigned tickets are prioritized.' };
  if (role === 'Manager') return { scope: 'Regional and company-wide reports', detail: 'Cross-branch KPIs and regional rollups are enabled.' };
  if (role === 'Administrator') return { scope: 'Full reporting access', detail: 'All branches, users, assets, projects, and exports are available.' };
  return { scope: 'Role-based reports', detail: 'Reports are filtered according to BSP permissions.' };
}

function handleExport(type: 'Excel' | 'PDF' | 'Print'): void {
  if (type === 'Print') {
    window.print();
    toast.success('Print dialog opened');
    return;
  }
  toast.success(`${type} export prepared for the filtered report view`);
}

function FilterSelect({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (value: string) => void }) {
  return (
    <div className="space-y-2">
      <span className="text-sm font-medium text-foreground">{label}</span>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full bg-background text-foreground">
          <SelectValue placeholder={`All ${label.toLowerCase()}`} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All {label.toLowerCase()}</SelectItem>
          {options.filter((option: string) => option.length > 0).map((option: string) => (
            <SelectItem key={option} value={option}>{option}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function ReportGroup({ title, reports }: { title: string; reports: string[] }) {
  return (
    <Card className="bg-card text-card-foreground shadow-sm">
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        <CardDescription>Power BI-style saved views</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {reports.map((report: string) => (
          <div key={report} className="flex items-center justify-between rounded-xl border bg-background p-3 text-foreground">
            <span className="text-sm font-medium">{report}</span>
            <Badge variant="secondary">Ready</Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export default function ReportsPage() {
  const { user } = useAuthSession();
  const [dateRange, setDateRange] = useState<DateRange | undefined>({ from: addDays(new Date(), -30), to: new Date() });
  const [filters, setFilters] = useState<FilterState>({ branch: 'all', region: 'all', category: 'all', status: 'all', priority: 'all', technician: 'all', project: 'all' });
  const access = useMemo<ReportAccess>(() => getReportAccess(user?.roleName), [user?.roleName]);

  const resetFilters = (): void => {
    setFilters({ branch: 'all', region: 'all', category: 'all', status: 'all', priority: 'all', technician: 'all', project: 'all' });
    setDateRange({ from: addDays(new Date(), -30), to: new Date() });
    toast.info('Report filters reset');
  };

  const activeFilterCount = Object.values(filters).filter((value: string) => value !== 'all').length + (dateRange?.from ? 1 : 0);
  const selectedBranchLabel = filters.branch.replace(/^SM\s+/u, '');
  const filteredBranchDistribution = filters.branch === 'all'
    ? branchDistributionData
    : branchDistributionData.filter((item: { branch: string; tickets: number }) => item.branch === selectedBranchLabel);
  const dateLabel = dateRange?.from
    ? `${format(dateRange.from, 'MMM d, yyyy')} - ${dateRange.to ? format(dateRange.to, 'MMM d, yyyy') : 'Today'}`
    : 'Select date range';

  const updateFilter = (key: keyof FilterState, value: string): void => {
    setFilters((current: FilterState) => ({ ...current, [key]: value }));
  };

  return (
    <div className="space-y-6">
      <section className="rounded-3xl border bg-card p-5 text-card-foreground shadow-sm lg:p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">Microsoft Fluent dashboard</Badge>
              <Badge variant="outline">{access.scope}</Badge>
            </div>
            <h2 className="mt-4 text-2xl font-semibold tracking-tight">Reports Dashboard</h2>
            <p className="mt-1 text-sm text-muted-foreground">Business Support Portal Analytics & Reporting</p>
            <p className="mt-3 max-w-3xl text-sm text-muted-foreground">{access.detail}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => handleExport('Excel')}><FileSpreadsheet className="h-4 w-4" />Export Excel</Button>
            <Button variant="outline" onClick={() => handleExport('PDF')}><FileText className="h-4 w-4" />Export PDF</Button>
            <Button onClick={() => handleExport('Print')}><Printer className="h-4 w-4" />Print Report</Button>
          </div>
        </div>
      </section>

      <Card className="bg-card text-card-foreground shadow-sm">
        <CardHeader>
          <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
            <div>
              <CardTitle className="text-lg">Filter Panel</CardTitle>
              <CardDescription>Refine reports by operational scope, service attributes, and delivery ownership.</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{activeFilterCount} active</Badge>
              <Button variant="outline" size="sm" onClick={resetFilters}><RotateCcw className="h-4 w-4" />Reset</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <div className="space-y-2">
            <span className="text-sm font-medium text-foreground">Date Range</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn('w-full justify-start text-left font-normal', !dateRange && 'text-muted-foreground')}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateLabel}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="range" selected={dateRange} onSelect={setDateRange} initialFocus />
              </PopoverContent>
            </Popover>
          </div>
          <FilterSelect label="Branch" value={filters.branch} options={filterOptions.branches} onChange={(value: string) => updateFilter('branch', value)} />
          <FilterSelect label="Region" value={filters.region} options={filterOptions.regions} onChange={(value: string) => updateFilter('region', value)} />
          <FilterSelect label="Category" value={filters.category} options={filterOptions.categories} onChange={(value: string) => updateFilter('category', value)} />
          <FilterSelect label="Status" value={filters.status} options={filterOptions.statuses} onChange={(value: string) => updateFilter('status', value)} />
          <FilterSelect label="Priority" value={filters.priority} options={filterOptions.priorities} onChange={(value: string) => updateFilter('priority', value)} />
          <FilterSelect label="Technician" value={filters.technician} options={filterOptions.technicians} onChange={(value: string) => updateFilter('technician', value)} />
          <FilterSelect label="Project" value={filters.project} options={filterOptions.projects} onChange={(value: string) => updateFilter('project', value)} />
        </CardContent>
      </Card>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
        {kpiCards.map(({ icon: Icon, label, value, change }: KpiCard) => (
          <Card key={label} className="bg-card text-card-foreground shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{label}</CardTitle>
              <span className="rounded-xl bg-primary p-2 text-primary-foreground"><Icon className="h-4 w-4" /></span>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-semibold tracking-tight">{value}</div>
              <p className="mt-1 text-xs text-muted-foreground">{change}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <Tabs defaultValue="trend" className="space-y-4">
        <TabsList className="grid h-auto w-full grid-cols-2 lg:w-fit lg:grid-cols-4">
          <TabsTrigger value="trend">Ticket Trend</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="branches">Branches</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
        </TabsList>
        <TabsContent value="trend">
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader><CardTitle>Ticket Trend</CardTitle><CardDescription>Daily, weekly, and monthly ticket movement.</CardDescription></CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-[320px] w-full">
                <AreaChart accessibilityLayer data={ticketTrendData}>
                  <CartesianGrid vertical={false} />
                  <XAxis dataKey="period" tickLine={false} axisLine={false} tickMargin={10} />
                  <YAxis tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area dataKey="monthly" type="monotone" fill="var(--chart-3)" stroke="var(--chart-3)" />
                  <Area dataKey="weekly" type="monotone" fill="var(--chart-2)" stroke="var(--chart-2)" />
                  <Area dataKey="daily" type="monotone" fill="var(--chart-1)" stroke="var(--chart-1)" />
                </AreaChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="categories">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Ticket Categories</CardTitle><CardDescription>POS, Network, CCTV, Hardware, Microsoft 365, and others.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <PieChart accessibilityLayer>
                    <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                    <Pie data={ticketCategoryData} dataKey="value" nameKey="name" innerRadius={58} outerRadius={105}>
                      {ticketCategoryData.map((entry: { name: string; value: number; fill: string }) => <Cell key={entry.name} fill={entry.fill} />)}
                    </Pie>
                  </PieChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Asset Status Distribution</CardTitle><CardDescription>Inventory health and warranty posture.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <PieChart accessibilityLayer>
                    <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                    <Pie data={assetStatusData} dataKey="value" nameKey="name" outerRadius={105}>
                      {assetStatusData.map((entry: { name: string; value: number; fill: string }) => <Cell key={entry.name} fill={entry.fill} />)}
                    </Pie>
                  </PieChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="branches">
          <Card className="bg-card text-card-foreground shadow-sm">
            <CardHeader><CardTitle>Top 10 Branches by Ticket Volume</CardTitle><CardDescription>Branch ticket distribution for the selected period.</CardDescription></CardHeader>
            <CardContent>
              {filteredBranchDistribution.length > 0 ? (
                <ChartContainer config={chartConfig} className="h-[360px] w-full">
                  <BarChart accessibilityLayer data={filteredBranchDistribution} layout="vertical">
                    <CartesianGrid horizontal={false} />
                    <XAxis type="number" tickLine={false} axisLine={false} />
                    <YAxis dataKey="branch" type="category" tickLine={false} axisLine={false} width={90} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="tickets" fill="var(--chart-1)" radius={6} />
                  </BarChart>
                </ChartContainer>
              ) : (
                <Empty className="min-h-[360px] rounded-3xl border border-dashed bg-background text-foreground">
                  <EmptyMedia variant="icon" className="bg-accent text-accent-foreground">
                    <SearchX className="h-6 w-6" />
                  </EmptyMedia>
                  <EmptyHeader>
                    <EmptyTitle>No reports match these filters</EmptyTitle>
                    <EmptyDescription>Try removing the branch filter or reset all filters to restore the full reporting view.</EmptyDescription>
                  </EmptyHeader>
                  <EmptyContent>
                    <Button onClick={resetFilters}><RotateCcw className="h-4 w-4" />Reset filters</Button>
                  </EmptyContent>
                </Empty>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="operations">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Technician Workload</CardTitle><CardDescription>Assigned versus closed workload.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <BarChart accessibilityLayer data={technicianWorkloadData}>
                    <CartesianGrid vertical={false} />
                    <XAxis dataKey="technician" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="assigned" fill="var(--chart-1)" radius={4} />
                    <Bar dataKey="closed" fill="var(--chart-2)" radius={4} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
            <Card className="bg-card text-card-foreground shadow-sm">
              <CardHeader><CardTitle>Project Status Overview</CardTitle><CardDescription>Delivery portfolio health.</CardDescription></CardHeader>
              <CardContent>
                <ChartContainer config={chartConfig} className="h-[300px] w-full">
                  <BarChart accessibilityLayer data={projectStatusData}>
                    <CartesianGrid vertical={false} />
                    <XAxis dataKey="status" tickLine={false} axisLine={false} />
                    <YAxis tickLine={false} axisLine={false} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="projects" fill="var(--chart-3)" radius={4} />
                  </BarChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      <Card className="bg-card text-card-foreground shadow-sm">
        <CardHeader>
          <CardTitle>Ticket Detail Drilldown</CardTitle>
          <CardDescription>Open a drawer for operational context behind the report numbers.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {reportTickets.map((ticket) => (
            <TicketDetailDrawer key={ticket.ticketNo} ticket={ticket}>
              <button type="button" className="w-full rounded-2xl border border-card-outline bg-background p-4 text-left text-foreground transition hover:bg-secondary">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="font-semibold">{ticket.ticketNo} · {ticket.summary}</p>
                    <p className="text-sm text-muted-foreground">{ticket.requestor} · {ticket.assignedTo}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">{ticket.status}</Badge>
                    <Badge variant="outline">{ticket.priority}</Badge>
                  </div>
                </div>
              </button>
            </TicketDetailDrawer>
          ))}
        </CardContent>
      </Card>


      <section className="grid gap-4 lg:grid-cols-3">
        <ReportGroup title="Support Reports" reports={supportReports} />
        <ReportGroup title="Asset Reports" reports={assetReports} />
        <ReportGroup title="Project Reports" reports={projectReports} />
      </section>

      <Card className="bg-card text-card-foreground shadow-sm">
        <CardContent className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="font-medium">Export Component</p>
            <p className="text-sm text-muted-foreground">Exports use the active filters, role access scope, and selected date range.</p>
          </div>
          <Button variant="secondary" onClick={() => handleExport('Excel')}><Download className="h-4 w-4" />Download filtered dataset</Button>
        </CardContent>
      </Card>
    </div>
  );
}
