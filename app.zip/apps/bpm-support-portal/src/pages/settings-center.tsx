import SettingsOverviewPage from '@/pages/settings-overview';

export default SettingsOverviewPage;