import { Link } from 'react-router-dom';
import { ArrowRight, KeyRound, ScrollText, ShieldCheck, SlidersHorizontal, UserRoundCheck, Users } from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

import { InMemoryDataBanner } from '@/generated/components/in-memory-data-banner';
import { HAS_IN_MEMORY_TABLES } from '@/generated/hooks';
import { useBSPAuditLogList } from '@/generated/hooks/use-bspaudit-log';
import { useBSPRoleList } from '@/generated/hooks/use-bsprole';
import { useBSPUserList } from '@/generated/hooks/use-bspuser';
import { useBSPUserRoleAccessList } from '@/generated/hooks/use-bspuser-role-access';
import type { BSPUser } from '@/generated/models/bsp-user-model';

const formatDate = (value?: string): string =>
  value
    ? new Intl.DateTimeFormat('en', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
    : 'No activity yet';

export default function SettingsOverviewPage() {
  const { data: users = [], isLoading: usersLoading } = useBSPUserList();
  const { data: roles = [], isLoading: rolesLoading } = useBSPRoleList();
  const { data: access = [], isLoading: accessLoading } = useBSPUserRoleAccessList();
  const { data: audits = [], isLoading: auditsLoading } = useBSPAuditLogList({ orderBy: ['eventDate desc'] });


  const currentUsers = users.filter((user: BSPUser) => !user.isDeleted);
  const activeUsers = currentUsers.filter((user: BSPUser) => user.accountStatusKey === 'Active').length;
  const inactiveUsers = currentUsers.filter((user: BSPUser) => user.accountStatusKey === 'Inactive').length;
  const activeRoles = roles.filter((role) => role.statusKey === 'Active').length;
  const grantedPermissions = access.filter((permission) => permission.isGranted).length;
  const recentAudits = audits.slice(0, 4);
  const isLoading = usersLoading || rolesLoading || accessLoading || auditsLoading;


  const summaryCards = [
    { label: 'Total accounts', value: currentUsers.length, detail: `${inactiveUsers} inactive`, icon: Users },
    { label: 'Active accounts', value: activeUsers, detail: 'Ready for portal access', icon: UserRoundCheck },
    { label: 'Active roles', value: activeRoles, detail: `${roles.length} roles configured`, icon: ShieldCheck },
    { label: 'Granted permissions', value: grantedPermissions, detail: 'Across role access rules', icon: KeyRound },
  ];

  return (
    <div className="space-y-8">
      <InMemoryDataBanner
        show={HAS_IN_MEMORY_TABLES}
        message="This app uses draft tables for testing. Data entered won't be saved. Contact the app owner to enable storage."
      />

      <section className="overflow-hidden rounded-2xl border border-card-outline-strong bg-card text-card-foreground shadow-card">
        <div className="h-1.5 bg-primary" />
        <div className="grid gap-6 p-6 lg:grid-cols-[1fr_auto] lg:items-center lg:p-8">
          <div className="max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">Administration</Badge>
              <Badge variant="outline">Administration center</Badge>
            </div>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight">Settings overview</h1>
            <p className="mt-2 max-w-xl text-sm text-muted-foreground">
              Monitor access health, review administrative activity, and reach the controls that keep the portal secure.
            </p>
          </div>
          <Button asChild type="button" size="lg">
            <Link to="/settings/user-account-management">
              Manage user accounts
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section aria-labelledby="access-summary-heading">
        <div className="mb-4">
          <h2 id="access-summary-heading" className="text-lg font-semibold tracking-tight">Access at a glance</h2>
          <p className="mt-1 text-sm text-muted-foreground">Current account, role, and permission coverage.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {summaryCards.map(({ label, value, detail, icon: Icon }) => (
            <Card key={label} className="border-card-outline transition-shadow hover:shadow-card">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{label}</p>
                    <p className="mt-2 text-3xl font-semibold tracking-tight">{isLoading ? '—' : value}</p>
                  </div>
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-secondary-foreground">
                    <Icon className="h-5 w-5" />
                  </span>
                </div>
                <p className="mt-4 border-t pt-3 text-xs text-muted-foreground">{detail}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-card-outline-strong">
          <CardHeader>
            <CardTitle>Settings workspaces</CardTitle>
            <CardDescription>Open the focused administration area you need.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl bg-primary p-5 text-primary-foreground">
              <Users className="h-6 w-6" />
              <h3 className="mt-4 font-semibold">User Account Management</h3>
              <p className="mt-2 text-sm">Add users, assign roles, manage permissions, and inspect audit records.</p>
              <Button asChild type="button" variant="secondary" size="sm" className="mt-5">
                <Link to="/settings/user-account-management">Open accounts<ArrowRight className="h-4 w-4" /></Link>
              </Button>
            </div>
            <div className="rounded-xl bg-secondary p-5 text-secondary-foreground">
              <SlidersHorizontal className="h-6 w-6" />
              <h3 className="mt-4 font-semibold">System Settings</h3>
              <p className="mt-2 text-sm">Manage portal security, audit recording, and administrator alerts.</p>
              <Button asChild type="button" variant="outline" size="sm" className="mt-5">
                <Link to="/settings/system">Open settings<ArrowRight className="h-4 w-4" /></Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><ScrollText className="h-5 w-5" />Recent changes</CardTitle>
            <CardDescription>Latest administration activity.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentAudits.length > 0 ? recentAudits.map((audit) => (
              <div key={audit.id} className="border-l-2 border-l-primary py-1 pl-3">
                <div className="flex items-start justify-between gap-3">
                  <p className="text-sm font-semibold">{audit.auditLogName}</p>
                  <Badge variant="outline">{audit.actionKey}</Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{audit.modifiedByName} · {formatDate(audit.eventDate)}</p>
              </div>
            )) : <p className="rounded-xl bg-muted p-4 text-sm text-muted-foreground">No administrative changes have been recorded.</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}