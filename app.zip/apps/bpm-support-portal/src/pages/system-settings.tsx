import { useState } from 'react';
import { BellRing, Database, LockKeyhole, Save, Settings2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';

type ConfigurationCardProps = {
  title: string;
  description: string;
  enabled: boolean;
  enabledLabel: string;
  disabledLabel: string;
  icon: typeof Settings2;
  onChange: (checked: boolean) => void;
};

function ConfigurationCard({ title, description, enabled, enabledLabel, disabledLabel, icon: Icon, onChange }: ConfigurationCardProps) {
  return (
    <Card className="border-l-4 border-l-primary shadow-sm">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Icon className="h-5 w-5" />
          </span>
          <Switch checked={enabled} onCheckedChange={onChange} aria-label={`Toggle ${title.toLowerCase()}`} />
        </div>
        <CardTitle className="pt-3 text-lg">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Badge variant={enabled ? 'default' : 'secondary'}>{enabled ? enabledLabel : disabledLabel}</Badge>
      </CardContent>
    </Card>
  );
}

export default function SystemSettingsPage() {
  const [sessionProtection, setSessionProtection] = useState(true);
  const [auditLogging, setAuditLogging] = useState(true);
  const [adminAlerts, setAdminAlerts] = useState(true);
  const [hasChanges, setHasChanges] = useState(false);

  const updateSetting = (setter: (value: boolean) => void, value: boolean): void => {
    setter(value);
    setHasChanges(true);
  };

  const saveConfiguration = (): void => {
    setHasChanges(false);
    toast.success('System configuration saved.');
  };

  const enabledCount = [sessionProtection, auditLogging, adminAlerts].filter(Boolean).length;

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-2xl border border-card-outline-strong bg-card text-card-foreground shadow-card">
        <div className="h-1.5 bg-primary" />
        <div className="flex flex-col gap-5 p-6 lg:flex-row lg:items-center lg:justify-between lg:p-8">
          <div className="max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">Settings</Badge>
              <Badge variant="outline">{enabledCount}/3 controls enabled</Badge>
            </div>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight">System settings</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Configure portal-wide security, audit recording, and administrator notifications from one page.
            </p>
          </div>
          <Button type="button" size="lg" onClick={saveConfiguration} disabled={!hasChanges}>
            <Save className="h-4 w-4" />
            Save changes
          </Button>
        </div>
      </section>

      <section aria-labelledby="security-settings-heading">
        <div className="mb-4 flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-secondary-foreground">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div>
            <h2 id="security-settings-heading" className="text-lg font-semibold">Portal configuration</h2>
            <p className="text-sm text-muted-foreground">Changes apply across the Business Support Portal.</p>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          <ConfigurationCard
            title="Session protection"
            description="Require an active account and assigned role before allowing portal access."
            enabled={sessionProtection}
            enabledLabel="Enforced"
            disabledLabel="Not enforced"
            icon={LockKeyhole}
            onChange={(checked: boolean) => updateSetting(setSessionProtection, checked)}
          />
          <ConfigurationCard
            title="Audit logging"
            description="Record user, role, permission, and account-status changes for review."
            enabled={auditLogging}
            enabledLabel="Recording"
            disabledLabel="Paused"
            icon={Database}
            onChange={(checked: boolean) => updateSetting(setAuditLogging, checked)}
          />
          <ConfigurationCard
            title="Administrator alerts"
            description="Notify administrators when access or account status is changed."
            enabled={adminAlerts}
            enabledLabel="Enabled"
            disabledLabel="Disabled"
            icon={BellRing}
            onChange={(checked: boolean) => updateSetting(setAdminAlerts, checked)}
          />
        </div>
      </section>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Settings2 className="h-5 w-5" />Configuration summary</CardTitle>
          <CardDescription>Review the effective portal behavior before saving.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl bg-muted p-4 text-muted-foreground"><p className="text-sm font-medium">Access validation</p><p className="mt-1 text-lg font-semibold text-foreground">{sessionProtection ? 'Required' : 'Optional'}</p></div>
          <div className="rounded-xl bg-muted p-4 text-muted-foreground"><p className="text-sm font-medium">Change history</p><p className="mt-1 text-lg font-semibold text-foreground">{auditLogging ? 'Captured' : 'Not captured'}</p></div>
          <div className="rounded-xl bg-muted p-4 text-muted-foreground"><p className="text-sm font-medium">Admin notifications</p><p className="mt-1 text-lg font-semibold text-foreground">{adminAlerts ? 'On' : 'Off'}</p></div>
        </CardContent>
      </Card>
    </div>
  );
}
