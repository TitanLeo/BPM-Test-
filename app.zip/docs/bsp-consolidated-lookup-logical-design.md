# BSP Consolidated Lookup Framework — Logical Design

## 1. Scope and current-state analysis

This document is a design specification only. It does not apply changes to Dataverse.

The current connected Dataverse model contains these existing tables, which must be retained and not recreated:

- BSP User (`bspuser`)
- BSP Role (`bsprole`)
- BSP User Role Access (`bspuser_role_access`)
- BSP Audit Log (`bspaudit_log`)
- Operational Support Record (`operational_support_record`), treated in this design as the existing Operational Support Request table

The model does not currently contain a reusable lookup-type/value framework. Operational Support Record currently stores Priority and Status as required Choice columns. Category and SLA lookups are absent. This design introduces only two tables—BSP Lookup Type and BSP Lookup Value—and recommends four new lookup columns on the existing request table.

No separate Category, Status, Priority, SLA, Store Type, Region, Area, Internet Provider, Request Type, or Asset Type tables should be created.

## 2. Naming assumptions

Replace `new_` below with the actual publisher prefix used by the BSP managed solution. Do not use the default publisher prefix in production.

| Item | Recommendation |
|---|---|
| Publisher prefix | Existing BSP solution publisher prefix |
| Ownership | Organization-owned |
| Change tracking | Enabled |
| Auditing | Enabled on both tables and business-critical columns |
| Activities | Disabled |
| Notes/attachments | Disabled |
| Duplicate detection | Enabled |
| Primary key | Dataverse-generated GUID |
| Deletion behavior | Restrict deletion when referenced; deactivate records instead |

## 3. Table: BSP Lookup Type

### Definition

| Property | Value |
|---|---|
| Display name | BSP Lookup Type |
| Plural display name | BSP Lookup Types |
| Recommended logical name | `new_bsplookuptype` |
| Entity set name | `new_bsplookuptypes` |
| Primary key | `new_bsplookuptypeid` |
| Primary column | Lookup Type Name (`new_lookuptypename`) |
| Purpose | Defines reusable lookup domains such as Category, Status, and Priority |

### Columns

| Display name | Recommended logical name | Dataverse type | Format/length | Requirement | Default | Notes |
|---|---|---|---|---|---|---|
| BSP Lookup Type | `new_bsplookuptypeid` | Unique identifier | GUID | System required | Dataverse-generated | Immutable primary key |
| Lookup Type Name | `new_lookuptypename` | Single line of text | 100 | Business required | None | Primary name; canonical domain name |
| Description | `new_description` | Multiple lines of text | 2,000 | Optional | None | Functional definition and governance notes |
| Active | `new_active` | Yes/No | Yes/No | Business required | Yes | Business-facing active flag; distinct from Dataverse state/status |

### Keys and validation

- Create alternate key `AK_BSPLookupType_Name` on `new_lookuptypename`.
- Treat names as case-insensitively unique.
- Do not rename a type after production use. Deactivate and create a replacement only when semantics materially change.
- Retain standard Dataverse `statecode` and `statuscode`. The custom Active field controls application availability; state/status controls record lifecycle.

### Seed records

| Lookup Type Name | Description | Active |
|---|---|---:|
| Category | Helpdesk issue classification | Yes |
| Status | Support request lifecycle status | Yes |
| Priority | Support request urgency and impact | Yes |
| SLA | Service-level target profile | Yes |
| Store Type | Branch or store classification | Yes |
| Region | Geographic operating region | Yes |
| Area | Operating area within a region | Yes |
| Internet Provider | Branch connectivity provider | Yes |
| Request Type | Type of service request | Yes |
| Asset Type | Supported asset classification | Yes |

## 4. Table: BSP Lookup Value

### Definition

| Property | Value |
|---|---|
| Display name | BSP Lookup Value |
| Plural display name | BSP Lookup Values |
| Recommended logical name | `new_bsplookupvalue` |
| Entity set name | `new_bsplookupvalues` |
| Primary key | `new_bsplookupvalueid` |
| Primary column | Value (`new_value`) |
| Purpose | Stores the governed values belonging to each reusable lookup type |

### Columns

| Display name | Recommended logical name | Dataverse type | Format/length | Requirement | Default | Notes |
|---|---|---|---|---|---|---|
| BSP Lookup Value | `new_bsplookupvalueid` | Unique identifier | GUID | System required | Dataverse-generated | Immutable primary key |
| Value | `new_value` | Single line of text | 200 | Business required | None | Primary name and user-facing label |
| Lookup Type | `new_lookuptypeid` | Lookup | BSP Lookup Type | Business required | None | Parent domain; never store the type as text |
| Code | `new_code` | Single line of text | 50 | Business required | None | Stable integration key; uppercase snake case recommended |
| Sort Order | `new_sortorder` | Whole number | Min 0 | Business required | 100 | Display sequence within a lookup type |
| Active | `new_active` | Yes/No | Yes/No | Business required | Yes | Controls availability in forms and applications |

### Keys and validation

- Create composite alternate key `AK_BSPLookupValue_Type_Code` on `new_lookuptypeid` + `new_code`.
- Also prevent duplicate display values within a type. If supported by the deployment process, add `AK_BSPLookupValue_Type_Value` on `new_lookuptypeid` + `new_value`; otherwise enforce this with a synchronous plug-in or pre-operation validation flow.
- Code is immutable after integrations begin. Labels may be changed for presentation without breaking references.
- Sort Order must be zero or greater.
- A value is selectable only when both its Active flag and its parent type's Active flag are Yes.
- Do not reuse a deactivated code for a different meaning.

## 5. Relationships

### Consolidated lookup hierarchy

| Parent | Child | Type | Child lookup | Required | Delete behavior |
|---|---|---|---|---:|---|
| BSP Lookup Type | BSP Lookup Value | 1:N | `new_lookuptypeid` | Yes | Restrict |

Recommended relationship schema name: `new_bsplookuptype_bsplookupvalue`.

### Operational Support Request relationships

Add four separate lookup columns to the existing Operational Support Record/Request table. All four point to BSP Lookup Value but represent different roles.

| Existing table | New display name | Recommended logical name | Target | Requirement | Allowed parent type | Delete behavior |
|---|---|---|---|---:|---|---|
| Operational Support Record | Category | `new_categoryid` | BSP Lookup Value | Business required | Category | Restrict |
| Operational Support Record | Status Lookup | `new_statuslookupid` | BSP Lookup Value | Business required | Status | Restrict |
| Operational Support Record | Priority Lookup | `new_prioritylookupid` | BSP Lookup Value | Business required | Priority | Restrict |
| Operational Support Record | SLA | `new_slaid` | BSP Lookup Value | Conditional/Business required | SLA | Restrict |

Recommended relationship schema names:

- `new_bsplookupvalue_operationalrequest_category`
- `new_bsplookupvalue_operationalrequest_status`
- `new_bsplookupvalue_operationalrequest_priority`
- `new_bsplookupvalue_operationalrequest_sla`

Set assignment, share, unshare, reparent, merge, and delete cascading to No Cascade or Restrict as applicable. Master-data maintenance must never delete or transfer request records.

### Lookup type enforcement

Dataverse lookup metadata cannot constrain one lookup to records having a particular parent Lookup Type. Enforce the allowed type through all applicable layers:

1. Configure each model-driven form lookup with a filtered view for the expected Lookup Type and Active = Yes.
2. Apply equivalent filters in canvas/custom applications.
3. Add server-side pre-operation validation, preferably a synchronous plug-in, to reject mismatched type references from imports, APIs, flows, or unfiltered forms.
4. Validate that the referenced Lookup Value and its parent Lookup Type are active.

Client-side filtering alone is not sufficient data integrity protection.

## 6. Seed records: BSP Lookup Value

The GUIDs are generated by Dataverse. Upsert seed data using the BSP Lookup Type name to resolve `new_lookuptypeid` and the composite alternate key `(Lookup Type, Code)`.

### Category

| Code | Value | Sort Order | Active |
|---|---|---:|---:|
| `POS_CONCERNS` | POS Concerns | 10 | Yes |
| `CCTV_CONCERNS` | CCTV Concerns | 20 | Yes |
| `OS_APPLICATION` | OS Application | 30 | Yes |
| `ZPIRS_APPLICATION` | ZPIRS Application | 40 | Yes |
| `CRMS_APPLICATION` | CRMS Application | 50 | Yes |
| `PHILCOM_NETWORK` | PHILCOM Network | 60 | Yes |
| `HARDWARE_CONCERNS` | Hardware Concerns | 70 | Yes |
| `ADID_PASSWORD_RESET` | ADID Password Reset | 80 | Yes |
| `MMS_PASSWORD_RESET` | MMS Password Reset | 90 | Yes |
| `SAP_PASSWORD_RESET` | SAP Password Reset | 100 | Yes |
| `UAMF_ACCOUNT` | UAMF Account | 110 | Yes |

### Status

| Code | Value | Sort Order | Active |
|---|---|---:|---:|
| `NEW` | New | 10 | Yes |
| `ASSIGNED` | Assigned | 20 | Yes |
| `IN_PROGRESS` | In Progress | 30 | Yes |
| `WAITING_USER` | Waiting User | 40 | Yes |
| `WAITING_VENDOR` | Waiting Vendor | 50 | Yes |
| `MONITORING` | Monitoring | 60 | Yes |
| `RESOLVED` | Resolved | 70 | Yes |
| `CLOSED` | Closed | 80 | Yes |
| `CANCELLED` | Cancelled | 90 | Yes |
| `REOPENED` | Reopened | 100 | Yes |

### Priority

| Code | Value | Sort Order | Active |
|---|---|---:|---:|
| `CRITICAL` | Critical | 10 | Yes |
| `HIGH` | High | 20 | Yes |
| `MEDIUM` | Medium | 30 | Yes |
| `LOW` | Low | 40 | Yes |

### SLA

No SLA values were specified. Create the SLA type now, but do not invent production SLA records. Seed SLA values after the business owners approve stable codes and labels, for example `CRITICAL_4H` / `Critical — 4-hour resolution`.

A generic lookup value can identify an SLA profile but cannot normalizedly store response hours, resolution hours, calendars, pause conditions, or escalation rules. If those attributes are required, use native Dataverse SLA/SLA Item capabilities or a dedicated BSP SLA Configuration table linked to the SLA Lookup Value. Do not encode changing numeric targets only in the display label.

### Remaining lookup types

Store Type, Region, Area, Internet Provider, Request Type, and Asset Type are seeded as types only because no approved values were supplied. Add their values later through governed upserts using the composite alternate key.

## 7. Existing fields and migration

The existing Operational Support Record table contains required Choice columns named Priority and Status. Do not delete or repurpose them during initial deployment.

Recommended migration:

1. Create and seed the two consolidated lookup tables.
2. Add the four new request lookup columns as optional initially.
3. Backfill Priority Lookup and Status Lookup by mapping existing Choice labels to Lookup Value codes.
4. Backfill Category and SLA from authoritative source data where available; route unmapped data to an exception report rather than creating uncontrolled values.
5. Validate that every active request has valid Category, Status, Priority, and applicable SLA references.
6. Make Category, Status Lookup, and Priority Lookup business required. Make SLA required only if every request must have a policy at creation; otherwise enforce it conditionally.
7. Update forms, views, flows, reports, business rules, integrations, and application queries to use the lookup columns.
8. Freeze the legacy Priority and Status Choice columns from user editing.
9. Retain them temporarily for rollback/report compatibility, then remove them only in a later managed-solution release after dependency analysis.

Do not maintain legacy and lookup fields indefinitely. If temporary synchronization is necessary, define the lookup as authoritative and synchronize one-way to the legacy Choice columns.

## 8. Dataverse implementation recommendations

### Solution and ALM

- Create both tables and all request columns in the existing unmanaged BSP development solution.
- Use the established BSP publisher and prefix.
- Transport schema, views, forms, keys, plug-ins, and seed-data deployment components through managed solutions.
- Use environment variables only for environment-specific configuration, not for lookup master data.
- Upsert reference data by alternate keys in a deployment pipeline or configuration migration package.

### Security

- Organization-own the lookup tables because they are shared reference data.
- Give administrators Create, Write, Append, Append To, Assign, Share, and Delete only as necessary.
- Give ordinary BSP users organization-level Read and no Delete.
- Grant request creators Append To on BSP Lookup Value and appropriate Create/Write privileges on Operational Support Request.
- Prefer deactivation over deletion to preserve historical references.

### Auditing and governance

- Enable auditing on Lookup Type Name, Description, Active, Lookup Type, Code, Value, Sort Order, and Active.
- Define a lookup-data owner and an approval process for new codes.
- Review inactive and duplicate candidates periodically.
- Use views for Active Values by Type, Inactive Values, Duplicate Review, and Unused Values.

### Performance

- Alternate keys provide indexes for deployment and integration upserts.
- Keep lookup type and value text lengths constrained.
- Filter app queries by Lookup Type, Active, and Sort Order.
- Cache low-volatility reference values in the client/query layer, but always enforce integrity server-side.

### Future-proofing

- Add new domains by inserting BSP Lookup Type records rather than creating more tables or global choices.
- Add values without solution metadata changes.
- Use stable Code values in integrations and analytics; use Value for display.
- If future values need domain-specific attributes, create a specialized extension table keyed by BSP Lookup Value rather than adding nullable columns that apply to only one type.
- Region/Area hierarchy is not represented by the requested columns. If dependent geography is required, add an optional Parent Lookup Value self-lookup with server-side same-domain/hierarchy validation, or introduce a dedicated geography model.

## 9. Manual implementation checklist

- [ ] Confirm the BSP publisher prefix and final logical names before creation.
- [ ] Create BSP Lookup Type with organization ownership and auditing.
- [ ] Create BSP Lookup Value with organization ownership and auditing.
- [ ] Add the required 1:N relationship from Type to Value with restricted deletion.
- [ ] Create alternate keys for Type Name and Type + Code.
- [ ] Import the ten Lookup Type records.
- [ ] Import Category, Status, and Priority values by alternate-key upsert.
- [ ] Add Category, Status Lookup, Priority Lookup, and SLA lookups to Operational Support Request as optional.
- [ ] Create filtered views and configure lookup controls.
- [ ] Implement server-side lookup-type and active-state validation.
- [ ] Backfill values and reconcile migration exceptions.
- [ ] Update all dependent forms, flows, integrations, reports, and application code.
- [ ] Apply business-required levels after successful backfill.
- [ ] Deprecate legacy Priority and Status Choice fields through a staged release.
- [ ] Add approved SLA and other domain values when supplied by business owners.
