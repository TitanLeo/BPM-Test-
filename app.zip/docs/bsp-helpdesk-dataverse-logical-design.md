# BSP Helpdesk Dataverse Logical Design

## 1. Scope and assumptions

This document is a logical design for manual implementation in a Microsoft Dataverse solution. It does not modify Dataverse.

Existing tables are retained:

- BSP User (`new_bspuser`)
- BSP Role (`new_bsprole`)
- BSP User Role Access (`new_bspuserroleaccess`)
- BSP Audit Log (`new_bspauditlog`)
- Operational Support Request (currently represented in the connected schema as Operational Support Record, `new_operationalsupportrecord`)

Missing normalized master tables to create:

- BSP Category
- BSP Status
- BSP Priority
- BSP Branch
- BSP SLA

The examples use publisher prefix `new_` because the connected tables currently use that prefix. Replace it only if the target solution uses a different managed publisher prefix.

## 2. Design principles

- Use Dataverse GUID primary keys; do not create manually maintained integer identifiers.
- Use a meaningful text primary name column on every table.
- Use lookups for category, status, priority, branch, SLA, users, and roles.
- Use alternate keys on stable business codes where integrations need deterministic upsert behavior.
- Store mutable presentation attributes such as priority color on master records, not on requests.
- Use organization-owned master tables and user/team-owned transactional tables where row-level security is required.
- Do not cascade-delete master records referenced by requests. Deactivate master records instead.
- Enable auditing on requests, access assignments, SLA definitions, and important master-data columns.
- Use UTC behavior for event timestamps and User Local behavior for user-facing due dates/times unless the business requires time-zone independence.
- Keep Dataverse system Status/Status Reason columns for record lifecycle. BSP Status is the helpdesk workflow state and is intentionally separate.

## 3. Lookup and master tables

### 3.1 BSP Category

| Property | Design |
|---|---|
| Display name | BSP Category |
| Plural display name | BSP Categories |
| Logical name | `new_bspcategory` |
| Ownership | Organization-owned |
| Primary ID | `new_bspcategoryid` (Unique identifier, system generated) |
| Primary column | `new_categoryname` |

| Display name | Logical name | Type | Requirement | Recommendation |
|---|---|---|---|---|
| Category Name | `new_categoryname` | Text, 150 | Business required | Primary name |
| Category Code | `new_categorycode` | Text, 50 | Business required | Alternate key; uppercase stable code |
| Description | `new_description` | Multiline text, 2,000 | Optional | User guidance and scope |
| Is Active | `new_isactive` | Yes/No | Business required | Default Yes |

**Keys and validation**

- Alternate key: `AK_BSPCategory_CategoryCode` on Category Code.
- Do not reuse a category code for a different meaning.
- Deactivate obsolete categories rather than deleting them.

**Seed records**

| Category Code | Category Name | Is Active |
|---|---|---:|
| POS | POS Concerns | Yes |
| CCTV | CCTV Concerns | Yes |
| OSAPP | OS Application | Yes |
| ZPIRS | ZPIRS Application | Yes |
| CRMS | CRMS Application | Yes |
| PHILCOM | PHILCOM Network | Yes |
| HARDWARE | Hardware Concerns | Yes |
| ADID_RESET | ADID Password Reset | Yes |
| MMS_RESET | MMS Password Reset | Yes |
| SAP_RESET | SAP Password Reset | Yes |
| UAMF | UAMF Account | Yes |

### 3.2 BSP Status

| Property | Design |
|---|---|
| Display name | BSP Status |
| Plural display name | BSP Statuses |
| Logical name | `new_bspstatus` |
| Ownership | Organization-owned |
| Primary ID | `new_bspstatusid` |
| Primary column | `new_statusname` |

| Display name | Logical name | Type | Requirement | Recommendation |
|---|---|---|---|---|
| Status Name | `new_statusname` | Text, 100 | Business required | Primary name |
| Display Order | `new_displayorder` | Whole number, min 0 | Business required | Controls UI sequence |
| Is Closed | `new_isclosed` | Yes/No | Business required | Default No; indicates terminal workflow state |

**Keys and validation**

- Alternate key: `AK_BSPStatus_StatusName` on Status Name.
- Use Display Order rather than alphabetical sorting.
- Do not confuse BSP Status with Dataverse Status/Status Reason.

**Seed records**

| Status Name | Display Order | Is Closed |
|---|---:|---:|
| New | 10 | No |
| Assigned | 20 | No |
| In Progress | 30 | No |
| Waiting User | 40 | No |
| Waiting Vendor | 50 | No |
| Monitoring | 60 | No |
| Resolved | 70 | Yes |
| Closed | 80 | Yes |
| Cancelled | 90 | Yes |
| Reopened | 100 | No |

### 3.3 BSP Priority

| Property | Design |
|---|---|
| Display name | BSP Priority |
| Plural display name | BSP Priorities |
| Logical name | `new_bsppriority` |
| Ownership | Organization-owned |
| Primary ID | `new_bsppriorityid` |
| Primary column | `new_priorityname` |

| Display name | Logical name | Type | Requirement | Recommendation |
|---|---|---|---|---|
| Priority Name | `new_priorityname` | Text, 100 | Business required | Primary name |
| Display Order | `new_displayorder` | Whole number, min 0 | Business required | Critical first |
| Color Code | `new_colorcode` | Text, 20 | Business required | Hex configuration value; validate format |

**Keys and validation**

- Alternate key: `AK_BSPPriority_PriorityName` on Priority Name.
- Color Code is presentation metadata only; never use it to determine business behavior.

**Seed records**

| Priority Name | Display Order | Color Code |
|---|---:|---|
| Critical | 10 | `#B42318` |
| High | 20 | `#B54708` |
| Medium | 30 | `#175CD3` |
| Low | 40 | `#475467` |

### 3.4 BSP Branch

| Property | Design |
|---|---|
| Display name | BSP Branch |
| Plural display name | BSP Branches |
| Logical name | `new_bspbranch` |
| Ownership | Organization-owned |
| Primary ID | `new_bspbranchid` |
| Primary column | `new_branchname` |

| Display name | Logical name | Type | Requirement | Recommendation |
|---|---|---|---|---|
| Branch Name | `new_branchname` | Text, 200 | Business required | Primary name |
| Branch Code | `new_branchcode` | Text, 50 | Business required | Alternate key; stable enterprise code |
| Region | `new_region` | Text, 100 | Optional | Consider a Region table only if region metadata/ownership grows |
| Area | `new_area` | Text, 100 | Optional | Consider an Area table only if independently managed |
| Store Type | `new_storetype` | Choice | Optional | Suggested values: Head Office, Mall Store, Standalone Store, Warehouse, Other |
| Internet Provider | `new_internetprovider` | Text, 150 | Optional | Normalize later if providers require contacts/contracts/SLAs |
| Branch Status | `new_branchstatus` | Choice | Business required | Active, Inactive; default Active |

**Keys and validation**

- Alternate key: `AK_BSPBranch_BranchCode` on Branch Code.
- Branch Code must come from the enterprise branch registry where available.
- Do not delete branches with request history; set Branch Status to Inactive.

**Illustrative seed records**

| Branch Code | Branch Name | Region | Area | Store Type | Internet Provider | Status |
|---|---|---|---|---|---|---|
| HO-BPM | Head Office BPM | NCR | Pasay | Head Office | PLDT Enterprise | Active |
| SMSL | SM San Lazaro | NCR | Manila | Mall Store | Globe Business | Active |
| SMNE | SM North EDSA | NCR | Quezon City | Mall Store | PLDT Enterprise | Active |
| SMMEGA | SM Megamall | NCR | Mandaluyong | Mall Store | Globe Business | Active |
| SMCEBU | SM Cebu | Visayas | Cebu City | Mall Store | PLDT Enterprise | Active |

Replace illustrative values with authoritative branch registry data before production import.

### 3.5 BSP SLA

| Property | Design |
|---|---|
| Display name | BSP SLA |
| Plural display name | BSP SLAs |
| Logical name | `new_bspsla` |
| Ownership | Organization-owned |
| Primary ID | `new_bspslaid` |
| Primary column | `new_slaname` |

| Display name | Logical name | Type | Requirement | Recommendation |
|---|---|---|---|---|
| SLA Name | `new_slaname` | Text, 150 | Business required | Primary name, e.g. Critical – 4 Hours |
| Priority | `new_priorityid` | Lookup to BSP Priority | Business required | Required N:1 relationship |
| Response Hours | `new_responsehours` | Decimal, precision 2, min 0 | Business required | Supports 0.25 hours |
| Resolution Hours | `new_resolutionhours` | Decimal, precision 2, min 0 | Business required | Must be >= Response Hours |
| Is Active | `new_isactive` | Yes/No | Business required | Default Yes |

**Keys and validation**

- Recommended alternate key: Priority lookup plus Is Active only if the target environment supports the intended key behavior and historical SLA versions are not needed.
- Preferred production pattern for versioning: add Effective From and Effective To columns, then enforce one effective active SLA per priority through a plug-in or Power Automate validation. Dataverse alternate keys cannot enforce conditional uniqueness by themselves.
- Business rule or server-side validation: Resolution Hours must be greater than or equal to Response Hours.

**Seed records**

| SLA Name | Priority lookup | Response Hours | Resolution Hours | Is Active |
|---|---|---:|---:|---:|
| Critical – 4 Hours | Critical | 0.25 | 4.00 | Yes |
| High – 8 Hours | High | 0.50 | 8.00 | Yes |
| Medium – 48 Hours | Medium | 4.00 | 48.00 | Yes |
| Low – 120 Hours | Low | 24.00 | 120.00 | Yes |

## 4. Changes to existing tables

### 4.1 Operational Support Request

The connected environment currently exposes this as Operational Support Record with logical name `new_operationalsupportrecord`. Keep the deployed logical name to avoid breaking integrations; the display name may be changed to Operational Support Request if desired.

Add or correct these columns manually:

| Display name | Recommended logical name | Type | Requirement | Target |
|---|---|---|---|---|
| Category | `new_categoryid` | Lookup | Business required | BSP Category |
| Request Status | `new_statusid` | Lookup | Business required | BSP Status |
| Priority | `new_priorityid` | Lookup | Business required | BSP Priority |
| Branch | `new_branchid` | Lookup | Business required | BSP Branch |
| Assigned To | `new_assignedtoid` | Lookup | Optional | BSP User |
| Requestor | `new_requestorid` | Lookup | Business required | BSP User |
| Applied SLA | `new_slaid` | Lookup | Business required | BSP SLA |

**Migration note:** Existing `priority` and `status` Choice columns should not be deleted immediately. Rename their display labels to “Priority (Legacy)” and “Status (Legacy),” hide them from new forms/views, migrate values into lookups, update integrations, and remove them only in a later managed-solution release after dependency analysis. Existing Requested By and Assigned To lookup columns may be reused if they already target BSP User correctly.

**Recommended additional transactional columns**

| Display name | Logical name | Type | Requirement | Purpose |
|---|---|---|---|---|
| Ticket Number | `new_ticketnumber` | Autonumber | Business required | Format such as `BSP-{SEQNUM:6}`; candidate alternate key |
| Title | `new_title` | Text, 300 | Business required | Concise request summary |
| Description | `new_description` | Multiline text | Business required | Detailed issue description |
| Created On | System | Date/time | System | Prefer system-created timestamp |
| Response Due | `new_responsedue` | Date/time | Optional/system calculated | Snapshot based on applied SLA |
| Resolution Due | `new_resolutiondue` | Date/time | Optional/system calculated | Snapshot based on applied SLA |
| First Response On | `new_firstresponseon` | Date/time | Optional | SLA measurement |
| Resolved On | `new_resolvedon` | Date/time | Optional | Resolution measurement |
| Closed On | `new_closedon` | Date/time | Optional | Closure measurement |
| Resolution Notes | `new_resolutionnotes` | Multiline text | Optional | Required by business rule when resolving |

Store due-date snapshots on the request. Do not recalculate historical deadlines when an SLA master record changes.

### 4.2 BSP User Role Access

The existing table currently contains Role, Permission, and Is Granted. Add:

| Display name | Logical name | Type | Requirement | Target |
|---|---|---|---|---|
| User | `new_userid` | Lookup | Business required | BSP User |
| Role | Existing `new_roleid` | Lookup | Business required | BSP Role |

Recommended duplicate-prevention key:

- `AK_BSPUserRoleAccess_User_Role_Permission` on User + Role + Permission.

If this table is intended to assign roles to users rather than grant individual permissions, remove Permission and Is Granted in a later redesign and use only User + Role. If it is intended as a permission matrix, split it into two normalized tables: BSP User Role (User + Role) and BSP Role Permission (Role + Permission). The requested design can be retained for compatibility, but the split model is more normalized.

### 4.3 BSP Audit Log

Add:

| Display name | Logical name | Type | Requirement | Target |
|---|---|---|---|---|
| Operational Support Request | `new_operationalsupportrequestid` | Lookup | Optional | Operational Support Request |

Keep Target User optional because some audit events concern users while others concern requests. For high-volume audit history, rely primarily on native Dataverse auditing and retain BSP Audit Log only for business-readable events, integration events, or workflow milestones.

### 4.4 BSP User

No recreation is required. For normalization:

- Replace the current Branch text field with an optional/required lookup to BSP Branch according to workforce rules.
- Keep Email Address as the primary name only if it is immutable in the organization; otherwise add Display Name as the primary name and create an alternate key on normalized email or Entra Object ID.
- Add Entra Object ID as a text column with an alternate key when BSP User maps to Microsoft Entra ID identities.
- The existing direct User Role lookup conflicts with the many-to-many role-access table. Select one authorization model. For multiple roles per user, deprecate the direct User Role lookup after migration and use BSP User Role Access.

### 4.5 BSP Role

No recreation is required. Recommended alternate key: Role Name, provided role names are governed and immutable. Deactivate unused roles instead of deleting them.

## 5. Relationship design

| Parent table | Child table | Lookup on child | Cardinality | Required | Delete behavior |
|---|---|---|---|---:|---|
| BSP Category | Operational Support Request | Category | 1:N | Yes | Restrict |
| BSP Status | Operational Support Request | Request Status | 1:N | Yes | Restrict |
| BSP Priority | Operational Support Request | Priority | 1:N | Yes | Restrict |
| BSP Branch | Operational Support Request | Branch | 1:N | Yes | Restrict |
| BSP User | Operational Support Request | Assigned To | 1:N | No | Remove Link |
| BSP User | Operational Support Request | Requestor | 1:N | Yes | Restrict |
| BSP SLA | Operational Support Request | Applied SLA | 1:N | Yes | Restrict |
| BSP Priority | BSP SLA | Priority | 1:N | Yes | Restrict |
| BSP User | BSP User Role Access | User | 1:N | Yes | Restrict |
| BSP Role | BSP User Role Access | Role | 1:N | Yes | Restrict |
| Operational Support Request | BSP Audit Log | Operational Support Request | 1:N | No | Restrict |
| BSP User | BSP Audit Log | Target User | 1:N | No | Remove Link or Restrict per retention policy |
| BSP Branch | BSP User | Branch | 1:N | Recommended | Restrict |

For Assigned To, Remove Link preserves the request if a BSP User record is removed. In production, deactivation is preferred over deletion.

## 6. Illustrative transactional sample data

Resolve all names below to Dataverse GUIDs during import; never store these labels in lookup columns.

| Ticket Number | Title | Category | Status | Priority | Branch | Assigned To | Requestor | Applied SLA |
|---|---|---|---|---|---|---|---|---|
| BSP-000101 | POS terminal cannot connect | POS Concerns | New | Critical | SM San Lazaro | Unassigned/null | Rhea Santos | Critical – 4 Hours |
| BSP-000102 | New AD account request | UAMF Account | Waiting User | Medium | SM North EDSA | Bianca Cruz | Marco Lim | Medium – 48 Hours |
| BSP-000103 | CCTV playback unavailable | CCTV Concerns | In Progress | High | SM Megamall | Carlo Lim | Nina Uy | High – 8 Hours |
| BSP-000104 | Workstation operating system issue | OS Application | Resolved | Low | Head Office BPM | Dina Ramos | Lara Dizon | Low – 120 Hours |
| BSP-000105 | SAP password reset | SAP Password Reset | Assigned | Medium | SM Cebu | Allan Reyes | Paolo Reyes | Medium – 48 Hours |

Seed BSP User and BSP Role records before importing User Role Access or requests. Use configuration migration, dataflows, or solution-aware deployment tooling with stable alternate keys to resolve lookups.

## 7. Dataverse schema recommendations

### Solution and publisher

- Create all components inside a dedicated unmanaged development solution, for example `BSP Helpdesk Core`.
- Use the same publisher prefix as the existing BSP tables; do not mix prefixes within the domain.
- Deploy downstream as managed solutions with environment variables and connection references where needed.

### Ownership and security

- Make category, status, priority, branch, SLA, and role organization-owned.
- Keep requests user/team-owned if business units, queues, or technicians need row-level access.
- Consider owner teams for helpdesk queues and business-unit security for regional access.
- Use field security profiles for sensitive requester/contact information where applicable.
- Configure least-privilege security roles for requester, technician, senior officer, manager, and administrator personas.

### Keys, duplicate detection, and integration

- Alternate keys: Category Code, Branch Code, Ticket Number, and optionally Role Name/Priority Name/Status Name.
- Normalize codes to uppercase before integration upserts.
- Add duplicate-detection rules for user email/Entra Object ID and branch code.
- Do not use display names as foreign keys in integrations.

### Auditing and retention

- Enable table auditing for Operational Support Request, BSP User Role Access, BSP SLA, and BSP User.
- Enable column auditing for status, priority, assignment, SLA, due dates, resolution, account status, and access grants.
- Define a retention policy for BSP Audit Log; avoid duplicating every native Dataverse audit event.

### Business rules and automation

- Default Status to New for newly created requests.
- Default Priority to Medium unless impact/urgency logic sets another value.
- Resolve Applied SLA from Priority on creation and whenever Priority changes before work begins.
- Snapshot response and resolution deadlines onto the request.
- Require Assigned To when Status becomes Assigned or In Progress.
- Require Resolution Notes and Resolved On when Status becomes Resolved.
- Prevent Closed, Cancelled, or Resolved records from being edited except through approved reopen actions.
- When reopened, set Status to Reopened and preserve the previous resolution timestamps for reporting or create a separate status-history table if full lifecycle analytics are required.
- Use a synchronous plug-in for rules that must be transactionally enforced; use Power Automate for notifications and non-transactional escalation workflows.

### Performance and reporting

- Indexing is managed by Dataverse; alternate keys provide useful indexes for integration lookups.
- Keep frequently filtered columns as native columns, not calculated text.
- Use views filtered by active lookup master records.
- For accurate SLA analytics across schedule hours and holidays, evaluate native Dataverse SLA/KPI instances rather than only decimal-hour calculations.
- Add a dedicated Request Status History child table in a future phase if duration-per-status reporting is required; audit logs alone are not ideal for operational analytics.

## 8. Recommended manual implementation order

1. Create or confirm the solution publisher and prefix.
2. Create BSP Category, BSP Status, BSP Priority, and BSP Branch.
3. Create BSP SLA and its Priority relationship.
4. Add lookup columns to Operational Support Request.
5. Add User to BSP User Role Access and Request lookup to BSP Audit Log.
6. Add Branch lookup and Entra identity fields to BSP User if approved.
7. Import master seed data using alternate keys.
8. Migrate legacy request Choice/text values to lookup GUIDs.
9. Validate referential integrity and required-field completeness.
10. Hide legacy fields from forms and views; update flows, apps, reports, and integrations.
11. Configure security, auditing, business rules, plug-ins, and automation.
12. Deploy as a managed solution and retire legacy fields only after dependency analysis.
