# Business Support Portal (BSP)

Business Support Portal is a Microsoft 365-inspired support workspace for branch operations, OSD helpdesk requests, POS-DATA incidents, document knowledge, reporting, and operational follow-up.

## Users

- Branch Users create tickets, monitor status, add comments, and confirm resolution.
- Technicians review assigned queues, update tickets, add internal notes, and resolve requests.
- Senior Officers manage queues, reassign work, handle escalations, and monitor SLA risk.
- Managers review KPIs, queue health, SLA dashboards, and operational performance.
- Administrators manage configuration, categories, priorities, SLA settings, and users.

## Design direction

The app preserves the BSP Microsoft Fluent UI direction with a responsive, modern card-based layout. MMS uses a high-contrast orange and white corporate palette, compact command surfaces, clear hierarchy, and productivity-focused information density.

## Data source

The connected Dataverse schema includes Operational Support Record, BSP User, BSP Role, BSP User Role Access, BSP Audit Log, and POS-DATA. MMS follows a centralized ticket architecture: Operational Support Record is the connected parent ticket, while the app-owned BSP MMS Ticket Detail child stores category-specific MMS fields through a required lookup. The UI documents recommended parent-table extensions where the connected read-only schema does not yet expose all required fields.

## Key scenarios

- OSD Helpdesk provides Create Ticket, Review Tickets, Help, Requestor Profile, KPI cards, recent activity, quick actions, queue tabs, filters, ticket tables, and a ticket detail workbench.
- Documents includes BSP Copilot assistance for approved knowledge-source guidance.
- POS support uses browser-style tabs inside the POS Module route so POS Monitoring, Inventory, and Deployments switch the full workspace body without separate module routes.
- POS Monitoring reads and writes the connected POS-DATA Dataverse table, including terminal, issue, category, date, support, cause, resolution, and transaction-context fields.
- POS Inventory and Deployments continue to use mock operational data until dedicated Dataverse entities are available.
- MMS Password Resetting is a complete role-based module with a requestor dashboard, structured submission form, searchable ticket list, BPM Personnel workspace, full ticket detail history, KPI and chart guidance, BPMN-style process flow, Dataverse schema, navigation, security matrix, Power Apps recommendations, best practices, and future enhancements.
- Settings uses a dedicated overview page for administration status and recent activity, with the original app-level configuration consolidated into a single System Settings submenu page and User Account Management available as a separate submenu page.