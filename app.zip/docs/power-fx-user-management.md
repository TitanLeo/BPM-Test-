# BSP user management Power Fx reference

Use these formulas after publishing the four draft BSP tables to Dataverse.

## Signed-in account and RBAC

```powerfx
Set(varSignedInEmail, Lower(User().Email));
Set(varBSPUser, LookUp(BSP_Users, Lower('Email Address') = varSignedInEmail && 'Account Status' = 'Account Status (BSP_Users)'.Active && !'Is Deleted'));
Set(varRole, varBSPUser.'User Role');
ClearCollect(colPermissions, Filter(BSP_UserRoleAccess, Role.BSP_Role = varRole.BSP_Role && 'Is Granted'));
Set(varIsAdministrator, varRole.'Role Name' = "Administrator");
```

## Screen visibility

```powerfx
// User and role administration
varIsAdministrator

// Reports for Administrator or Manager
varIsAdministrator || varRole.'Role Name' = "Manager"

// Permission-based control
!IsBlank(LookUp(colPermissions, Permission = PermissionChoices.'User Management'))
```

## Search and filters

```powerfx
Filter(
    BSP_Users,
    !'Is Deleted' &&
    (IsBlank(txtSearch.Text) || StartsWith(Lower('Full Name'), Lower(txtSearch.Text)) || StartsWith(Lower('Email Address'), Lower(txtSearch.Text)) || StartsWith(Lower('Employee ID'), Lower(txtSearch.Text))) &&
    (IsBlank(cmbRole.Selected) || 'User Role'.BSP_Role = cmbRole.Selected.BSP_Role) &&
    (IsBlank(cmbBranch.Selected.Value) || Branch = cmbBranch.Selected.Value)
)
```

## Unique validation and save

```powerfx
If(
    IsBlank(txtEmployeeId.Text) || IsBlank(txtFullName.Text) || IsBlank(txtEmail.Text) || IsBlank(cmbRole.Selected),
    Notify("Complete all required fields.", NotificationType.Error),
    !IsBlank(LookUp(BSP_Users, Lower('Email Address') = Lower(txtEmail.Text) && BSP_User <> varEditingUser.BSP_User)),
    Notify("Email address already exists.", NotificationType.Error),
    !IsBlank(LookUp(BSP_Users, Lower('Employee ID') = Lower(txtEmployeeId.Text) && BSP_User <> varEditingUser.BSP_User)),
    Notify("Employee ID already exists.", NotificationType.Error),
    Patch(BSP_Users, Coalesce(varEditingUser, Defaults(BSP_Users)), frmUser.Updates)
)
```

## Soft delete and audit

```powerfx
If(
    varIsAdministrator,
    Patch(BSP_Users, galUsers.Selected, {'Account Status': 'Account Status (BSP_Users)'.Deleted, 'Is Deleted': true});
    Patch(BSP_AuditLogs, Defaults(BSP_AuditLogs), {'Audit Log Name': "User deleted", Date: Now(), User: galUsers.Selected, Action: ActionChoices.'User Deleted', 'Modified By': User().FullName, 'Old Value': "Active", 'New Value': "Deleted"}),
    Notify("Only Administrators can delete users.", NotificationType.Error)
)
```

## Permission grant or revoke

```powerfx
Patch(
    BSP_UserRoleAccess,
    Coalesce(LookUp(BSP_UserRoleAccess, Role.BSP_Role = varRole.BSP_Role && Permission = ThisItem.Permission), Defaults(BSP_UserRoleAccess)),
    {Role: varRole, Permission: ThisItem.Permission, 'Is Granted': chkGranted.Value, 'Updated Date': Now()}
)
```
